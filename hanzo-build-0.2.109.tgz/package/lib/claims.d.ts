/**
 * What a hanzo.id access token says, read without trusting it for anything the
 * platform does not check again.
 */
/** The token's claims, or null when it is not a JWT. */
export declare function claims(token: string | null): Record<string, unknown> | null;
/**
 * Whether the token says its person administers `org`: owner or admin, read off
 * the token's own `orgs` claim — never the reserved `admin` org, which is
 * platform authority and not what a builder decides anything by. The platform
 * enforces it again; this only decides which controls are offered.
 */
export declare function administers(token: string | null, org: string | null): boolean;
