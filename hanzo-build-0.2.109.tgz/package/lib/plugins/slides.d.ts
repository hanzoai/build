import type { Target } from '../api/call.ts';
import { type Run } from '../api/studio.ts';
import type { Plugin, Prep, Turn } from '../plugin.ts';
/** What a deck's writing step said: its title and its slides' titles. */
export declare function outline(text: string): {
    title: string;
    slides: string[];
};
/** The brief a revision is made from: the deck as it stands, then the change asked for. */
export declare function revision(last: Run, ask: string): string;
/** The answer a made deck is: its outline, the file, and where it is edited. */
export declare function told(r: Run): string;
export declare function deck(turn: Turn, t: Target, signal: AbortSignal): Promise<Prep>;
export declare const slides: Plugin;
