import { type Target } from '../api/call.ts';
import type { Plugin, Prep, Turn } from '../plugin.ts';
/** Searches a plan holds, at least one and at most this many. */
export declare const QUERIES = 5;
export interface Result {
    url: string;
    title: string;
    snippet: string;
}
export interface Source extends Result {
    /** The page as read, cut to `PAGE`, or '' when it could not be read. */
    text: string;
}
/** The searches a plan names, deduplicated and cut; the message itself when the plan named none. */
export declare function plan(said: string, message: string): string[];
/** The results of every search, taken in turn from each so no one search crowds out the rest, each page once. */
export declare function pick(lists: Result[][], n?: number): Result[];
/** A page's markdown as it is quoted: no pictures, no runs of blank lines, no marker, cut. */
export declare function excerpt(markdown: string): string;
/** The leading system turn's part: what was searched, what was read, and how to write the report. */
export declare function brief(queries: string[], sources: Source[], now: Date): string;
/** Research the message: the plan, the searches, the pages, as the system turn's part. */
export declare function research(turn: Turn, t: Target, signal: AbortSignal, now?: Date): Promise<Prep>;
export declare const deep: Plugin;
