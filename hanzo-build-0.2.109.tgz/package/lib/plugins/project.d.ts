import { type Project } from '../api/projects.ts';
import type { Plugin } from '../plugin.ts';
/** The projects a search keeps: those whose name, address or repository holds every word. */
export declare function find(list: readonly Project[], q: string): Project[];
export declare const project: Plugin;
