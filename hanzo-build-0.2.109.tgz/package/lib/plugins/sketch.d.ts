import type { Plugin } from '../plugin.ts';
type Stroke = {
    x: number;
    y: number;
}[];
/** Draw every stroke on white. */
export declare function paint(g: CanvasRenderingContext2D, strokes: readonly Stroke[]): void;
export declare const sketch: Plugin;
export {};
