import { type Target } from '../api/call.ts';
import type { Plugin, Prep, Turn } from '../plugin.ts';
/** Hanzo's model that decodes under a strict schema. */
export declare const DRAFTER = "zen5-flash";
/** The site a brief points at, if it names one. */
export declare const siteOf: (text: string) => string;
export declare function make(turn: Turn, t: Target, signal: AbortSignal): Promise<Prep>;
export declare const designer: Plugin;
