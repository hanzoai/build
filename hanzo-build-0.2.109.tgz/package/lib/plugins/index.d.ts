/**
 * The plugins the composer offers, from `+` › Plugins and by typing `@`: only
 * those that run for this person, each on Hanzo's own services.
 *
 *   Work in a project   the org has a project (GET /v1/project)
 *   Deep research       signed in: web search, page reading and a Hanzo model, as the person
 *   Sketch              always: it draws in the page
 *   Template Creator    an org admin: only an admin writes the org's skills
 *   Presentations       Studio runs its `slides` template (GET /v1/studio/templates)
 *   PDF                 signed in: read and verify in the page; create where Studio runs `document`
 *
 * What is there is read once per platform, org and sign-in, and kept for the page.
 *
 * Deep research IS the Research switch: its row turns `Gear.research` on and
 * off, and `prep` asks it when that is on. Every other plugin that prepares is on
 * while its id is in `Gear.plugins`; one that opens something runs when picked.
 */
import type { Say } from '@hanzo/i18n/react';
import type { Target } from '../api/call.ts';
import type { Gear, GearState } from '../gear.ts';
import type { Composer, Plugin, Prep, Turn } from '../plugin.ts';
import type { Shelf } from '@hanzo/ui/chat';
export { research } from './research.tsx';
export interface Plugins {
    plugins: Plugin[];
    loading: boolean;
    error: string | null;
}
/** Where a plugin of the org's own is built: Customize › Plugins. */
export declare const BUILD: string;
/** What runs for this person, in the menu's order. */
export declare function probe(t: Target): Promise<Plugin[]>;
export declare function usePlugins(t: Target): Plugins;
/** The `+` menu's Plugins shelf, in the words of the caller's `t` (a plugin's name and note are marked where it is written). */
export declare function shelf(p: Plugins, g: GearState, c: Composer, t?: Say): Shelf;
/** The plugins this message asks, in the menu's order. */
export declare const active: (plugins: readonly Plugin[], g: Gear) => Plugin[];
/** Several plugins' preparations as one: system parts and replies in order, files together, the design system one made. */
export declare function merge(preps: readonly Prep[]): Prep;
/**
 * Ask every plugin that is on what the message carries. A plugin that fails
 * fails the message, with its name and its reason: a report asked for and not
 * researched must not arrive looking researched. Its name is said in the
 * caller's `t`; the reason is `say`'s.
 */
export declare function prep(plugins: readonly Plugin[], g: Gear, turn: Turn, c: Composer, signal: AbortSignal, denied?: readonly string[], t?: Say): Promise<Prep>;
