import type { Target } from '../api/call.ts';
import { type Run } from '../api/studio.ts';
import type { Plugin, Prep, Turn } from '../plugin.ts';
/** The most text of all the PDFs in one message that rides it. */
export declare const TEXT = 120000;
export declare const isPdf: (f: {
    name: string;
    type: string;
}) => boolean;
/** One PDF as the model is given it: the report, then its pages, within what is left of `room`. */
export declare function given(file: string, said: string, pages: string[], room: number): string;
/** Read every PDF in the message. */
export declare function study(files: File[]): Promise<Prep>;
/** The answer a made PDF is: its title, and the file. */
export declare function told(r: Run): string;
export declare function create(turn: Turn, t: Target, signal: AbortSignal): Promise<Prep>;
/** The PDF plugin; it makes PDFs only where Studio's document template runs. */
export declare function pdf(makes: boolean): Plugin;
