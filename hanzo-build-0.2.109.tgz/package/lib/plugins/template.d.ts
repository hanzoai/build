import type { Plugin } from '../plugin.ts';
export interface Draft {
    name: string;
    description: string;
    body: string;
}
/** A skill's name from any words: one lowercase segment of letters, digits and hyphens. */
export declare function slug(text: string): string;
/** What a model's draft says, each part the ask's own where the draft has none. */
export declare function drafted(said: string, draft: string): Draft;
/** The SKILL.md a template is saved as: its name and description up front, then the template. */
export declare function document(d: Draft): string;
export declare const template: Plugin;
