import { type SessionStatus } from '@hanzo/ui/chat';
import { type Draft, type Kind, type Schedule } from './api/auto.ts';
export declare const zone: () => string;
/** The lists' words are English, marked (`phrase`), and drawn through `t`. */
export declare const KINDS: readonly {
    id: Kind;
    label: string;
}[];
/** A run's status as the rail's dot draws it, and in words (marked, drawn through `t`). */
export declare const DOT: Record<string, SessionStatus>;
export declare const WORD: Record<string, string>;
export declare const live: (s: string) => boolean;
/** The schedule a kind starts from, keeping whatever of `was` still applies. */
export declare function shaped(kind: Kind, was: Schedule): Schedule;
/** What is wrong with a schedule before it is sent, or '': English, marked (`phrase`), so a screen says it through `t`. */
export declare function unready(s: Schedule): string;
/** A schedule as the platform reads it: an hourly minute in two digits. */
export declare function tidy(d: Draft): Draft;
/** A local time and date for an RFC 3339 instant. */
export declare const local: (iso: string) => string;
/** A run the platform refused for want of a plan: a free org with no credit for the run fee. `PLAN` says so, marked, drawn through `t`. */
export declare const unplanned: (e: unknown) => boolean;
export declare const PLAN: string;
/** When a task runs, chosen: how often, the day and time, and the zone it is read in. */
export declare function When({ s, onChange, disabled }: {
    s: Schedule;
    onChange: (s: Schedule) => void;
    disabled?: boolean;
}): import("react").JSX.Element;
/** One automation: what it does and when, its switch, Run now, and its runs. `new` writes one. */
export declare function Editor({ id }: {
    id: string;
}): import("react").JSX.Element;
