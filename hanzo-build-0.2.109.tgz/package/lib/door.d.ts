import { type Door as Which, type State as Held } from './api/sandbox.ts';
/**
 * `held` is where the run's sandbox is in its life, '' until it has been read. Only
 * a running sandbox has an open door.
 */
export declare function Door({ which, sandbox, held, session }: {
    which: Which;
    sandbox: string;
    held: Held | '';
    session: string;
}): import("react").JSX.Element;
