/**
 * What removing one of the org's projects does, decided before anything is.
 *
 * A project on Projects is a repository the forge holds, and it is one of two
 * things. Hanzo's COPY of a repository on GitHub: removing it drops the link
 * that syncs into it, then the copy, then the project built from it — and the
 * repository on GitHub is never touched. Or the forge's OWN repository, made
 * from a template or created there: removing it deletes the repository and all
 * of its history, which Hanzo knows of nowhere else. A repository GitHub grants
 * that Hanzo never copied has nothing here to remove.
 *
 * Which one it is, is read off what the org's projects are made from (api/work.ts
 * `sources`), and only off what says so of THIS copy: a link that writes into
 * it, GitHub's listing naming it as a repository's forge name, or a project
 * built from that repository on GitHub. A forge repository merely named like a
 * GitHub one is the forge's own and is said to be, since deleting it may be
 * deleting the only history there is.
 *
 * The calls go in that order — link, copy, project — and stop at the first
 * refusal, so what a removal leaves is always the tail of its steps and is said.
 *
 * Pure: the screen asks and the tests ask the same question. Its words take the
 * screen's @hanzo/i18n `t`, English when none is handed.
 */
import type { Say } from '@hanzo/i18n/react';
import type { Link } from './api/links.ts';
import { type Granted, type Held, type Site } from './merge.ts';
/** One call a removal makes. */
export type Step = 
/** DELETE /v1/sync/{id}: GitHub stops syncing into the copy, and the copy stops pushing back. */
{
    kind: 'link';
    id: string;
}
/** DELETE /v1/git/repos/{name}: the repository goes from the forge, history and all. */
 | {
    kind: 'mirror';
    name: string;
}
/** DELETE /v1/project/{slug}: the project built from it goes, and its site stops answering. */
 | {
    kind: 'project';
    slug: string;
};
export interface Removal {
    /** `owner/name` as people know it: GitHub's address for a copy, the org's for the forge's own. */
    repo: string;
    /** `github` for Hanzo's copy of a repository on GitHub; `hanzo` for one whose only copy Hanzo knows of is its own. */
    from: 'github' | 'hanzo';
    /** The calls, in the order they are made. */
    steps: Step[];
    /** What removing it does, in full, for the one question asked before it is done. */
    says: string;
}
/** What the org's projects are made from (api/work.ts `sources`), as far as removing one reads it. */
export interface Made {
    granted: Pick<Granted, 'owner' | 'name' | 'codebase'>[];
    linked: Pick<Link, 'id' | 'owner' | 'name' | 'forge'>[];
    held: Pick<Held, 'org' | 'name'>[];
    sites: Pick<Site, 'slug' | 'repo'>[];
}
/**
 * What removing the forge repository `name` does, or null when the forge does
 * not hold it: there is nothing of its own on Hanzo to remove.
 */
export declare function removal(name: string, made: Made, t?: Say): Removal | null;
/**
 * What is left when step `at` of `r` was refused, said with the refusal `why`:
 * nothing gone when it was the first step, else what went and what is still here.
 */
export declare function stopped(r: Removal, at: number, why: string, t?: Say): string;
