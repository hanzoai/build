import { type SessionStatus } from '@hanzo/ui/chat';
import { type ReactNode } from 'react';
import type { Session } from './api/sessions.ts';
import { type Read } from './data.ts';
import type { Host } from './host.tsx';
/** A run's status, as the rail's dot draws it. Anything else is idle. */
export declare const DOTS: Record<string, SessionStatus>;
/** The org's coding runs, newest first, kept live by the org's feed. */
export declare function useSessions(host: Host): Read<Session[]>;
/**
 * The builder's places, grouped as every rail groups them (nav.tsx), then the
 * runs. `children` sit between the places and the runs — where a host lists its
 * own. `onPick` fires after a move, so a host that draws its rail as a drawer
 * on a phone can close it.
 */
export declare function DevSection({ host, onPick, label, children, }: {
    host: Host;
    onPick?: () => void;
    /** The runs' heading; absent, "Runs" in the reader's language. */
    label?: string;
    children?: ReactNode;
}): import("react").JSX.Element;
