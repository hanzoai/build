/**
 * The projects an organization works on and their issues, merged.
 *
 * A project is a repository: granted by the org's GitHub connection, mirrored
 * onto the forge, or made there. The same repository arrives from several
 * sources and is one row. An issue is read from the forge and from the task
 * service's mirror of GitHub; the same issue (the same link) is one row with
 * every source that carried it named.
 *
 * Which project an issue is for is the issue's own repository — the GitHub
 * address its mirror records, or the forge repository it is filed on — and
 * never the board it sits on: a board's key is not a repository.
 *
 * Pure: every function here takes rows and answers rows, so the screens and the
 * tests share one reading of what is the same, what belongs where, and what
 * comes first.
 */
export type Source = 'github' | 'forge' | 'linear' | 'agent' | 'board';
export interface Project {
    /** `owner/name`, lower case: the one address every source is matched on. */
    key: string;
    owner: string;
    name: string;
    description: string;
    /** Null when no source said. */
    private: boolean | null;
    /** The default branch, or '' when no source said. */
    branch: string;
    /** RFC 3339: the latest push, update or issue any source reports, or ''. */
    activity: string;
    /** Open issues, or null when the work could not be read. */
    issues: number | null;
    /** Open pull requests on the forge, or null when the work could not be read. */
    pulls: number | null;
    /** Granted by the org's GitHub connection. */
    linked: boolean;
    /** On the forge: mirrored from GitHub, or made there. */
    mirrored: boolean;
    /** The forge's own name for it, which is what a run and an environment name; '' when it is not known to be there. */
    forge: string;
    /** RFC 3339: when its link last synced, or ''. */
    synced: string;
    /** Its link's state: `synced`, `conflict`, `pending`, `paused`, `linked` when its forge copy could not be read; '' with no link. */
    status: string;
    /** The org's project (GET /v1/project) that builds from it, by slug, or ''. */
    slug: string;
    /** The name GitHub's listing says it takes on the forge once brought there, or ''. */
    codebase: string;
    /** Its page on GitHub, or ''. */
    url: string;
}
export interface Issue {
    /** What makes two rows the same issue: its link, else its handle on its board, else its id. */
    key: string;
    /** `owner/name` of the repository it is filed on, once known; '' until then. */
    repo: string;
    /** The forge repository a forge row is filed on, by name; ''. */
    forge: string;
    /** What an index row says its repository is, unchecked: a run's repo, or a Linear team's key. Resolved, never used raw. */
    hint: string;
    number: number;
    title: string;
    body: string;
    state: 'open' | 'closed';
    labels: string[];
    assignees: string[];
    /** The issue's own page, https only, or ''. */
    url: string;
    sources: Source[];
    /** RFC 3339, or ''. */
    updated: string;
    /** RFC 3339: when it was opened, or ''. */
    created: string;
    /** What the task service files it as: `issue`, `pr`, `task`, `bug`, … */
    kind: string;
    /** The board's column for it as the task service names it: `backlog`, `todo`, `in_progress`, `done`, `canceled`, or its own word. */
    status: string;
    /** `none` unless the board says otherwise. */
    priority: string;
    /** A pull request, not an issue. */
    pull: boolean;
    /** The board it was read from. Shown, filtered on, never resolved as a repository. */
    board: string;
}
/** `owner/name` as one key, whatever case either source used. */
export declare const keyOf: (owner: string, name: string) => string;
/**
 * An issue's link as one key: https only, no query or fragment, no trailing
 * slash, lower case. The same issue read twice has the same key.
 */
export declare function canon(url: string): string;
/** The repository and number a GitHub or forge issue link names, or null. */
export declare function parse(url: string): {
    repo: string;
    number: number;
    pull: boolean;
} | null;
/** Whether every word of `q` is somewhere in `text`. */
export declare function matches(q: string, ...text: string[]): boolean;
/** A repository GitHub's listing grants, in the fields a project takes from it. */
export interface Granted {
    owner: string;
    name: string;
    private: boolean;
    default_branch: string;
    pushed_at: string;
    codebase: string;
}
/** A repository the forge lists, in the fields a project takes from it. */
export interface Held {
    org: string;
    name: string;
    description: string;
    branch: string;
    public: boolean;
    updated: string;
}
/** A repository linked from GitHub (GET /v1/sync), in the fields a project takes from it. */
export interface Linked {
    owner: string;
    name: string;
    forge: string;
    synced: string;
    status: string;
    branch: string;
}
/** One of the org's projects (GET /v1/project) that builds from a repository. */
export interface Site {
    slug: string;
    /** Its clone address. */
    repo: string;
    branch: string;
    /** RFC 3339, or ''. */
    updated: string;
}
/** The account and repository an https clone address names, and whether the host is GitHub. */
export declare function addressOf(url: string): {
    owner: string;
    name: string;
    github: boolean;
} | null;
/**
 * The project an issue is for, or null. Its GitHub address first, then the
 * forge repository it is filed on, then what an index row says — matched
 * against the org's own projects, an `owner/name` exactly, a bare name only when
 * one project answers to it. A board's key is never consulted.
 */
export declare function place(i: Pick<Issue, 'repo' | 'forge' | 'hint'>, list: Project[]): Project | null;
/** Whether a clone address is the forge's own. */
export declare function forgeHost(url: string): boolean;
/** What the org's projects are assembled from. */
export interface Parts {
    /** GitHub's grants to the org's connection: empty for anyone it does not answer. */
    granted?: Granted[];
    /** The repositories linked from GitHub, each with its forge copy. */
    linked?: Linked[];
    /** The forge's repositories. */
    held?: Held[];
    /** The org's projects that build from a repository. */
    sites?: Site[];
    /** Every issue and pull request, or null when they were not read. */
    work?: Issue[] | null;
}
/**
 * Every project the org works on, one row per repository: the repositories it
 * linked from GitHub, GitHub's grants, the forge's repositories and the ones its
 * issues are filed on, and the org's projects that build from one — each with
 * its open work counted from `work` (null counts when the work was not read).
 *
 * A forge repository is the GitHub one it copies when a link targets it, when
 * GitHub names it as that repository's `codebase`, or when it sits in a forge
 * namespace named like the GitHub owner (an issue's link says which namespace).
 */
export declare function assemble({ granted, linked, held, sites, work }: Parts): Project[];
/** Each issue with the project it is for named as its `repo`, where one answers. */
export declare function attach(list: Issue[], projects: Project[]): Issue[];
/** Most recent activity first; the unknown last; the address breaks a tie, so the order never shuffles. */
export declare function byActivity(a: Project, b: Project): number;
export interface ProjectFilter {
    q?: string;
    /** One owner, or '' for every one. */
    owner?: string;
    /** Only those with an open issue or pull request. */
    open?: boolean;
}
export declare function pickProjects(list: Project[], f?: ProjectFilter): Project[];
/** The owners named, once each whatever the case, in name order. */
export declare function owners(...names: string[][]): string[];
/**
 * One row per issue. The same issue read from several sources is the row the
 * most recently updated one describes, with every source named and every label
 * and assignee any of them carries.
 */
export declare function issues(...lists: Issue[][]): Issue[];
/** Every label and assignee the list carries, for its filters, in name order. */
export declare function facets(list: Issue[]): {
    labels: string[];
    assignees: string[];
};
/**
 * Where a run on issue `i` works, on project `p`: where the issue lives, so the
 * run's pull request is opened beside it. A GitHub issue's run works on GitHub
 * (a linked project's forge copy is the forge's own repository, and a pull
 * request there would not reach GitHub's issue); a forge issue's on the forge.
 * Any other issue (a Linear or a board's row) works wherever the project can be
 * worked on: its forge copy, else GitHub. Null when the project is neither.
 */
export declare function home(i: Pick<Issue, 'sources'>, p: Pick<Project, 'linked' | 'forge'>): 'github' | 'forge' | null;
/**
 * The number a run on `p` closes for issue `i`, or 0: the issue's own number,
 * when the run works where the issue lives. A board's or Linear's number closes
 * nothing, and neither does a GitHub issue run on the forge, or the reverse.
 */
export declare function closes(i: Pick<Issue, 'sources' | 'number'>, p: Pick<Project, 'linked' | 'forge'>): number;
/** How a person refers to an issue: `#N` where N is the repository's own number, else the board's handle. */
export declare function handle(i: Pick<Issue, 'sources' | 'number' | 'board'>): string;
/**
 * What New's composer holds for an issue: its title and handle, its link, and
 * its body — the ask a person would write. `#N` only when the run closes N; any
 * other number is the board's (`LINEAR-5`), so the agent cannot mistake it for
 * an issue on the repository it works on.
 */
export declare function ask(i: Pick<Issue, 'title' | 'number' | 'url' | 'body' | 'board' | 'sources'>, closing?: number): string;
