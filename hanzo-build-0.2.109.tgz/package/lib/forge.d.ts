import type { Screen } from './route.ts';
export declare function Forge({ screen }: {
    screen: Exclude<Screen, 'artifacts' | 'templates'>;
}): import("react").JSX.Element;
