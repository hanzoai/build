import { type Target } from './call.ts';
export type Status = 'running' | 'paused' | 'done' | 'error' | 'stopped' | string;
export interface Session {
    id: string;
    title: string;
    status: Status;
    agent: string;
    actor: string;
    repo: string;
    project: string;
    target: string;
    /** What sort of run: 'coding' for a coding run. */
    kind: string;
    /** The branch the run started from, or ''. */
    base: string;
    /** The branch the run pushes to — the only one it may write. */
    branch: string;
    /** 'sandbox', or the id of the org's machine it runs on. */
    environment: string;
    /** 'build' or 'plan', as the coding service recorded it; '' for other runs. */
    mode: string;
    /** The pull request the run proposed, or ''. */
    pr: string;
    /** The sandbox the run leased, once it has one. It is gone when the run ends. */
    sandbox: string;
    /** The org the run is in, which the public build route is addressed by. */
    org: string;
    /** Whether its story is open to the public build route. Only a run that names a project can be. */
    published: boolean;
    events: number;
    createdAt: string;
    updatedAt: string;
    endedAt: string;
}
export interface Event {
    id: string;
    sessionId: string;
    seq: number;
    kind: string;
    actor: string;
    payload: unknown;
    createdAt: string;
}
export interface Detail extends Session {
    recent: Event[];
}
export declare function session(raw: unknown): Session;
export declare function event(raw: unknown): Event;
/**
 * How long runs in one mode took, in whole minutes: the median and the ninetieth
 * percentile of the finished ones. Null under three, which is too few to say.
 */
export declare function took(runs: Session[], mode: string): [number, number] | null;
export interface ListQuery {
    kind?: string;
    project?: string;
    /** running, paused, done or error: the four the platform filters on. */
    status?: string;
    limit?: number;
    /** The `next` of the page before. */
    after?: string;
}
export interface Page {
    sessions: Session[];
    /** The cursor for the page after this one, or '' on the last. */
    next: string;
}
export declare function page(t: Target, q?: ListQuery): Promise<Page>;
export declare function list(t: Target, q?: ListQuery): Promise<Session[]>;
export declare function get(t: Target, id: string): Promise<Detail>;
export declare function message(t: Target, id: string, text: string): Promise<void>;
export declare function stop(t: Target, id: string, why?: string): Promise<void>;
export declare function pause(t: Target, id: string): Promise<void>;
export declare function resume(t: Target, id: string): Promise<void>;
/** A new title, up to the platform's 512 characters. */
export declare function rename(t: Target, id: string, title: string): Promise<Session>;
/**
 * Open the run's story to the public build route, or close it. The platform
 * refuses to open one that names no project, because that route is keyed on
 * the org and the project.
 */
export declare function publish(t: Target, id: string, on: boolean): Promise<Session>;
/** Where anyone can read a published run's story: the public build route, by org and project. '' without both. */
export declare const story: (t: Target, org: string | null, project: string) => string;
export interface Watch {
    session?: (s: Session) => void;
    event?: (e: Event) => void;
    /** Each (re)connect. The first is 0; a later one means frames may have been missed. */
    open?: (attempt: number) => void;
}
/**
 * Follow one run's tree until `signal` aborts. Reconnects with a capped backoff;
 * a refusal (401/403) ends it, because retrying a no is not recovery.
 */
export declare function watch(t: Target, root: string, on: Watch, signal: AbortSignal): Promise<void>;
