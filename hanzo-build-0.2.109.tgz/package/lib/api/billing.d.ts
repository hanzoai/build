import { type Target } from './call.ts';
/** `$1,234.56` from whole cents; whole dollars drop the cents. */
export declare function money(cents: number, currency?: string): string;
/** Whole cents from what a person typed as dollars — `25`, `$25.50` — or null. */
export declare function cents(typed: string): number | null;
export interface Plan {
    id: string;
    name: string;
    description: string;
    /** personal, team, enterprise, … */
    category: string;
    /** Per month, billed monthly. 0 is free. */
    monthly: number;
    /** Per month, billed yearly; 0 when the plan has no yearly price. */
    yearly: number;
    currency: string;
    perSeat: boolean;
    /** Priced by talking to sales; nothing to buy here. */
    sales: boolean;
    popular: boolean;
    features: string[];
}
export declare function plan(raw: unknown): Plan;
export declare function plans(t: Target): Promise<Plan[]>;
export interface Subscription {
    id: string;
    plan: string;
    name: string;
    /** Per period, per seat. */
    price: number;
    interval: string;
    currency: string;
    seats: number;
    /** trialing, active, past_due, canceled, unpaid. */
    status: string;
    /** RFC 3339: paid through, and renews or ends then. */
    ends: string;
    /** Ends at `ends` rather than renewing. */
    ending: boolean;
    /** The saved card a renewal charges, or ''. */
    method: string;
}
export declare function subscription(raw: unknown): Subscription;
/** The plan the org is on, or null for none (the free tier). */
export declare function current(list: Subscription[]): Subscription | null;
export declare function subscriptions(t: Target): Promise<Subscription[]>;
export interface Purchase {
    plan: string;
    /** month | year */
    interval: 'month' | 'year';
    /** The saved card that pays. */
    method: string;
}
/** Buy a plan. No amount is sent: the catalog prices it, and the platform charges that. */
export declare function subscribe(t: Target, p: Purchase): Promise<{
    subscription: string;
    charged: number;
}>;
/** End a plan when its paid period does, not before. */
export declare function cancel(t: Target, id: string): Promise<Subscription>;
export declare function reactivate(t: Target, id: string): Promise<Subscription>;
export interface Address {
    name?: string;
    line1?: string;
    line2?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
}
export interface Method {
    id: string;
    type: string;
    brand: string;
    last4: string;
    /** `MM/YY`, or ''. */
    expires: string;
    default: boolean;
    /** What the platform calls it when it is not a card. */
    name: string;
    billingAddress?: Address;
}
export declare function method(raw: unknown): Method;
/** Formats a billing address as a readable line: `Acme Inc · 123 Main St · San Francisco CA 94105 · US`. */
export declare function formatAddress(a?: Address): string;
/** How a saved method reads in a row: `Visa •••• 4242`. */
export declare function label(m: Method): string;
export declare function methods(t: Target): Promise<Method[]>;
/** The card a charge uses: the default, or the newest. */
export declare function chosen(list: Method[]): Method | null;
/** Save a card from the single-use token the processor's form returned, optionally with billing info. */
export declare function save(t: Target, token: string, billingAddress?: Address): Promise<Method>;
export declare function updateMethod(t: Target, id: string, what: {
    billingAddress?: Address;
}): Promise<Method>;
export declare function detach(t: Target, id: string): Promise<void>;
export declare function makeDefault(t: Target, id: string): Promise<Method>;
export interface Processor {
    /** `square`, or '' where none is configured. */
    provider: string;
    application: string;
    location: string;
    /** `production` charges real cards; anything else is the sandbox. */
    environment: string;
    live: boolean;
}
export declare function processor(t: Target): Promise<Processor>;
export interface Line {
    description: string;
    amount: number;
}
export interface Invoice {
    id: string;
    /** `INV-0042`, or '' for a draft. */
    number: string;
    date: string;
    status: string;
    currency: string;
    subtotal: number;
    tax: number;
    discount: number;
    credit: number;
    paid: number;
    due: number;
    /** What the invoice comes to before credit is applied. */
    total: number;
    start: string;
    end: string;
    lines: Line[];
}
export declare function invoice(raw: unknown): Invoice;
export declare function invoices(t: Target): Promise<Invoice[]>;
/** The invoice as a PDF, read with the caller's bearer. */
export declare function pdf(t: Target, id: string): Promise<Blob>;
/** What the org can still spend from its prepaid balance, in cents. */
export declare function balance(t: Target): Promise<number>;
/** Granted credit the org can spend, in US cents. */
export declare function credit(t: Target): Promise<number>;
/** One grant of credit, spent, lapsed and voided included: the ledger, not the spendable figure. */
export interface Grant {
    id: string;
    name: string;
    amount: number;
    remaining: number;
    currency: string;
    /** RFC 3339, or '' for one that does not lapse. */
    expires: string;
    active: boolean;
}
export declare function grants(t: Target): Promise<Grant[]>;
/** The rung an organization is served as (`max-20x`, '' with none) and the tier class it is served under (`pro`). */
export interface Tier {
    plan: string;
    tier: string;
}
export declare function tier(t: Target): Promise<Tier>;
/** Auto-reload: top the balance up by `amount` whenever it falls below `threshold`, charging the card on file. */
export interface Recharge {
    enabled: boolean;
    threshold: number;
    amount: number;
    currency: string;
    /** RFC 3339 of the last reload, or ''. */
    last: string;
}
/** The rule as stored; one never set reads as off. */
export declare function recharge(t: Target): Promise<Recharge>;
/** Arm or disarm the rule. Turning it on needs a card on file, and the platform says so when there is none. */
export declare function arm(t: Target, rule: {
    enabled: boolean;
    threshold: number;
    amount: number;
}): Promise<Recharge>;
/** Charge a saved card and add the amount to the balance; answers the balance after. */
export declare function topup(t: Target, amount: number, card: string): Promise<number>;
export interface Window {
    /** hour, day, week or month. */
    span: string;
    /** Requests the plan includes in this span; 0 is no bound. */
    limit: number;
    used: number;
    /** RFC 3339. */
    resets: string;
}
export interface Month {
    plan: string;
    /** `2026-09`. */
    period: string;
    /** Spend the plan includes this month, and how much of it is used. */
    included: number;
    used: number;
    overage: number;
    windows: Window[];
}
export declare function month(t: Target): Promise<Month>;
export interface Spend {
    /** Whether the ledger answered; false means the zeros are not measurements. */
    known: boolean;
    /** Month to date. */
    total: number;
    categories: {
        name: string;
        cents: number;
    }[];
}
export declare function spend(t: Target): Promise<Spend>;
/** The pool every free user shares, as its vendor accounts last said. */
export interface Pool {
    /** available, busy or exhausted. */
    state: string;
    /** RFC 3339: when the pool refills, where the platform says; ''. */
    resets: string;
}
/**
 * What the caller has left of the Free plan: limited usage, from a pool shared
 * by all free users. `pooled` is false for a paid plan, whose usage is its spend.
 */
export interface Allowance {
    plan: string;
    /** Requests allowed in `window`; 0 is no bound. */
    limit: number;
    used: number;
    spent: boolean;
    /** hour or day. */
    window: string;
    /** RFC 3339. */
    resets: string;
    pooled: boolean;
    /** Absent when the platform could not read it. */
    pool: Pool | null;
}
export declare function allowance(t: Target): Promise<Allowance>;
export interface Cap {
    id: string;
    title: string;
    /** The ceiling for the calendar month, in cents; 0 bounds no spend. */
    threshold: number;
    /** Refuses spend past the ceiling, rather than only warning. */
    enforce: boolean;
    project: string;
    service: string;
    /** Spent this month against it, or null when the platform could not read it. */
    spent: number | null;
    resets: string;
}
export declare function cap(raw: unknown): Cap;
export declare function caps(t: Target): Promise<Cap[]>;
/** The org-wide monthly cap: no project, no service, a ceiling. */
export declare function monthly(list: Cap[]): Cap | null;
/** Set the org's monthly cap: change the one there is, or open one that refuses spend past it. */
export declare function limit(t: Target, list: Cap[], threshold: number): Promise<Cap>;
export declare function lift(t: Target, id: string): Promise<void>;
