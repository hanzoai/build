import type { Say } from '@hanzo/i18n/react';
import { type Target } from './call.ts';
export type State = 'none' | 'proposed' | 'ready';
export interface Proposal {
    install: string;
    start: string;
    /** Variables the agent found the codebase reads. Some may not be set yet. */
    secrets: string[];
    /** What the setup agent found and checked, in its own words. */
    note: string;
}
export interface Environment {
    repo: string;
    install: string;
    start: string;
    /** The names set on this codebase. Values are never answered. */
    secrets: string[];
    state: State;
    /** The setup run that produced the proposal, or ''. */
    session: string;
    proposal: Proposal | null;
    updated: string;
}
export declare function environment(raw: unknown, repo?: string): Environment;
/**
 * Whether a codebase still waits to be set up: nothing proposed and nothing ever
 * saved. Skip & save keeps an empty environment, which the platform answers as
 * state `none` with the time it was saved (apps/environment `view`), so the
 * time is what tells a choice made from one never made.
 */
export declare const unset: (e: Environment) => boolean;
/**
 * What a refused save or setup run says to the person who pressed it: what is
 * wrong and what to do, in the reader's words rather than the platform's, and
 * in the language of the `t` handed (English without one).
 */
export declare function plain(e: unknown, repo: string, act: 'save' | 'start' | 'run', t?: Say): string;
export declare function environments(t: Target): Promise<Environment[]>;
export declare function read(t: Target, repo: string): Promise<Environment>;
export declare function save(t: Target, repo: string, scripts: {
    install: string;
    start: string;
}): Promise<Environment>;
export declare function forget(t: Target, repo: string): Promise<void>;
/** An environment variable name the run can export, and not one of its own. */
export declare const NAME: RegExp;
/** Why a secret name cannot be set, in the words of the `t` handed, or '' when it can. */
export declare function refuse(name: string, t?: Say): string;
export declare function setSecret(t: Target, repo: string, name: string, value: string): Promise<Environment>;
export declare function removeSecret(t: Target, repo: string, name: string): Promise<Environment>;
/**
 * What a setup run is asked. The first line is the run's title, the steps are
 * its checklist, and the platform puts its own instructions ahead of both.
 */
export declare const SETUP: string;
