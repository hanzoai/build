import { type Target } from './call.ts';
export declare const KINDS: readonly ['secret', 'publishable'];
export type Kind = (typeof KINDS)[number];
export interface Key {
    id: string;
    name: string;
    type: Kind;
    /** The recognizable head, never enough to use the key. */
    prefix: string;
    /** The whole key: a publishable key's only. */
    key: string;
    /** active, expired, revoked or disabled. */
    status: string;
    /** `kind:name` entries; none reaches whatever its holder does. */
    limit: string[];
    /** When it was made, as IAM records it. */
    created: string;
}
export interface Minted {
    id: string;
    name: string;
    type: Kind;
    /** The key itself. A secret one is never readable again. */
    key: string;
    limit: string[];
}
export declare function keys(t: Target): Promise<Key[]>;
/** A `kind:name` limit: a lowercase kind, a colon, and a name or `*`. */
export declare const LIMIT: RegExp;
/** The limits a person typed, split on commas and spaces; throws on the first that is not one. */
export declare function limits(raw: string): string[];
/** Create a new key beside the ones held. The answer is the only time a secret key is shown. */
export declare function mint(t: Target, type: Kind, name?: string, limit?: string[]): Promise<Minted>;
/** Revoke exactly one key, by id. Every other key keeps working. */
export declare function revoke(t: Target, id: string): Promise<void>;
