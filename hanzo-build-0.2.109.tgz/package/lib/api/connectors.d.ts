import { type Target } from './call.ts';
export interface Server {
    /** The server's id in the org, and the prefix of every tool it brings. */
    id: string;
    name: string;
    url: string;
    /** The header the sealed secret is sent in, or ''. */
    header: string;
    /** Whether a secret is sealed for it. */
    secret: boolean;
    /** The catalog listing it was added from, or '' for a URL typed in. */
    listing: string;
    created: number;
    /** False when no admin put it in place, so no run carries it; true, or unsaid by an older platform. */
    admitted: boolean;
}
export interface Remote {
    transport: string;
    url: string;
}
export interface Package {
    registry: string;
    identifier: string;
    runtime: string;
    version: string;
}
export interface Listing {
    id: string;
    /** The publisher's reverse-DNS name, `com.stripe/mcp`. */
    name: string;
    title: string;
    description: string;
    vendor: string;
    version: string;
    logo: string;
    featured: boolean;
    official: boolean;
    transports: string[];
    remotes: Remote[];
    packages: Package[];
    repo: string;
    site: string;
}
export interface Page {
    listings: Listing[];
    total: number;
    offset: number;
}
export declare function server(raw: unknown): Server;
export declare function listing(raw: unknown): Listing;
/** What a listing is called on screen. */
export declare const titleOf: (l: Listing) => string;
/** Whether a listing can be added here and now: the platform dials its streamable-HTTP remote. */
export declare const ready: (l: Listing) => boolean;
/** A server's tools among the plane's, by the prefix its id gives them. */
export declare const owns: (s: Server, toolName: string) => boolean;
export declare function servers(t: Target): Promise<Server[]>;
export interface Adding {
    /** Required with a URL; a listing takes its own title when this is empty. */
    name?: string;
    url?: string;
    listing?: string;
    header?: string;
    secret?: string;
}
/** Why a server cannot be added as it stands, or '' when it can. English, marked (`phrase`): a screen says it through `t`. */
export declare function refuse(a: Adding): string;
export declare function add(t: Target, a: Adding): Promise<Server>;
export declare function remove(t: Target, id: string): Promise<void>;
/** A page of the shelf, featured first, then by name. */
export declare function shelf(t: Target, q?: {
    text?: string;
    limit?: number;
    offset?: number;
}): Promise<Page>;
export declare function one(t: Target, id: string): Promise<Listing>;
