import type { Say } from '@hanzo/i18n/react';
/** Where the platform is and who is asking. The host supplies it. */
export interface Target {
    /** The platform origin, no trailing slash: calls are `${api}/v1/…`. */
    api: string;
    /** The signed-in person's bearer, or null for nobody. */
    token: () => string | null;
    /** The org every call is scoped to, sent as `X-Org-Id`. */
    org: string | null;
}
/** A refusal: the status, and the platform's own sentence for it. */
export declare class Refusal extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
/**
 * A sentence this client wrote with something of the moment in it (a file's
 * name, an address), thrown where no `t` is at hand: its message is the
 * English, filled, and a screen says it from its source and values.
 */
export declare class Sentence extends Error {
    readonly source: string;
    readonly values: Readonly<Record<string, string | number>>;
    constructor(source: string, values?: Readonly<Record<string, string | number>>);
}
/**
 * An error's own sentence, as the screen that caught it says it: one this
 * client wrote, in the reader's language; the platform's, which is no key, as given.
 */
export declare function told(e: unknown, t?: Say): string;
export type Query = Record<string, string | number | boolean | null | undefined>;
/** `?a=1&b=2` from the defined, non-empty entries of `q`, or ''. */
export declare function query(q?: Query): string;
/** The headers every call carries: the bearer and the org, when there are ones. */
export declare function headers(t: Target, extra?: HeadersInit): Headers;
/** The sentence a refusal carries, whichever envelope it arrived in. */
export declare function reason(res: Response): Promise<string>;
/** A path segment, escaped. Ids and names from a row never compose a path raw. */
export declare const seg: (s: string) => string;
/**
 * One JSON call. Throws `Refusal` on any non-2xx, with the platform's reason, or
 * the status when it gave none. A 204 answers `undefined`.
 */
export declare function call<T>(t: Target, method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE', path: string, body?: unknown, init?: {
    signal?: AbortSignal;
}): Promise<T>;
/**
 * The `{status, msg, data}` envelope IAM and the model service answer with. A
 * refusal there is `status: "error"` with its sentence in `msg`, whatever the
 * HTTP status was — often 200 — so it is read here and thrown like any other.
 */
export declare function unwrap(raw: unknown): unknown;
