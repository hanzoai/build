import { type Target } from './call.ts';
export interface Endpoint {
    id: string;
    url: string;
    /** Subject patterns; empty is every event. */
    events: string[];
    description: string;
    /** active | disabled */
    status: string;
    /** The signing secret: present only in the answer to a create. */
    secret: string;
    created: string;
    /** Settled in the last seven days, and how many of those failed. */
    deliveries: number;
    failures: number;
}
export declare function endpoint(raw: unknown): Endpoint;
export declare function endpoints(t: Target): Promise<Endpoint[]>;
/** The patterns in what a person typed: comma or space separated. */
export declare function patterns(typed: string): string[];
export interface Draft {
    url: string;
    events: string[];
    description: string;
}
/** Why a draft cannot be sent, or ''. The platform refuses the same things. English, marked (`phrase`): a screen says it through `t`. */
export declare function refuse(d: Draft): string;
export declare function add(t: Target, d: Draft): Promise<Endpoint>;
export declare function remove(t: Target, id: string): Promise<void>;
export interface Trial {
    delivered: boolean;
    /** 0 when the endpoint never answered. */
    status: number;
    ms: number;
    error: string;
}
export declare function test(t: Target, id: string): Promise<Trial>;
export interface Attempt {
    subject: string;
    /** ok | retrying | failed */
    status: string;
    code: number;
    attempt: number;
    error: string;
    at: string;
}
export declare function deliveries(t: Target, id: string, limit?: number): Promise<Attempt[]>;
