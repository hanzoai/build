/**
 * The signed-in person's own settings, as the platform keeps them for every
 * Hanzo surface.
 *
 *   GET   /v1/pref → {prefs: {…}, updatedAt}   an empty document for someone who saved nothing
 *   PATCH /v1/pref   {key: value | null}        a shallow merge; null deletes the key
 *
 * The document is one object shared by every surface, keyed per person and per
 * org. This reads only the keys the builder owns and writes only those, so a
 * key another surface saved is left as it was. A value this version does not
 * recognise reads as unset rather than as a choice.
 */
import { type Kept } from '../suggest.ts';
import { type Target } from './call.ts';
export type Theme = 'system' | 'light' | 'dark';
export type Text = 'small' | 'medium' | 'large';
export type Motion = 'system' | 'reduced';
/**
 * Where and how a new run starts when New has no choice of its own kept. The
 * model and effort are not here: they are the one choice Chat and Dev share,
 * kept in the browser (mind.tsx).
 */
export interface Code {
    mode?: 'build' | 'plan';
    /** A machine's id, or '' for the sandbox. */
    place?: string;
}
/** The side panel beside Chat and Dev, once for both. */
export interface Side {
    /** How wide it is drawn, px, while the middle column shows. */
    width?: number;
}
export interface Prefs {
    theme?: Theme;
    text?: Text;
    motion?: Motion;
    /** The dictation language, as voice.ts names it. */
    language?: string;
    /** What Hanzo calls the person. */
    callName?: string;
    /** What best describes their work. */
    work?: string;
    /** What every coding run is told about how they like to work. */
    instructions?: string;
    code?: Code;
    side?: Side;
    /** The suggestions under the composer: when made, from what, the rows, and those dismissed (suggest.ts). */
    suggest?: Kept;
}
/** A change: a key set to a value, or to null to delete it. */
export type Patch = {
    [K in keyof Prefs]?: Prefs[K] | null;
};
export declare function code(raw: unknown): Code | undefined;
export declare function side(raw: unknown): Side | undefined;
/** The builder's keys from a whole preference document. */
export declare function prefs(raw: unknown): Prefs;
/** What a document reads as once `patch` is merged into it — the platform's own rule. */
export declare function merge(base: Prefs, patch: Patch): Prefs;
export declare function read(t: Target): Promise<Prefs>;
export declare function save(t: Target, patch: Patch): Promise<Prefs>;
