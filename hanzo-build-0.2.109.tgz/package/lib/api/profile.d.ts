import { type Target } from './call.ts';
export interface Profile {
    displayName: string;
    avatar: string;
}
/** Save the name the person is shown by. An empty name is refused here. */
export declare function rename(t: Target, name: string): Promise<Profile>;
/** The formats the platform keeps a photo in; it decides by the bytes, this only filters the picker. */
export declare const PHOTO = "image/png,image/jpeg,image/gif,image/webp";
/** Store a new photo and answer its address. */
export declare function photo(t: Target, file: Blob): Promise<string>;
