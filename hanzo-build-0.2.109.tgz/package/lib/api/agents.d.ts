import { type Target } from './call.ts';
export type Period = 'day' | 'week' | 'month';
export declare const PERIODS: readonly Period[];
export interface Agent {
    id: string;
    name: string;
    model: string;
    description: string;
    /** Only a single agent's read carries it; the list withholds it. */
    instructions: string;
    tools: string[];
    status: string;
    runs: number;
    /** Micro-USD per period, per run, and spent this period. */
    cap: number;
    task: number;
    spent: number;
    period: Period | '';
    /** Its picture: an https link or a data URL; '' draws its emoji or initial. */
    avatar: string;
    emoji: string;
}
export interface Preset {
    id: string;
    title: string;
    prompt: string;
}
/** The fields a person edits. Money is in dollars here and micro-USD on the wire. */
export interface Draft {
    name: string;
    description: string;
    model: string;
    instructions: string;
    tools: string[];
    cap: string;
    task: string;
    period: Period;
    /** Sent on create only: an https link or a data URL. */
    avatar: string;
}
/** An agent's name, as the handler takes it. */
export declare const NAME: RegExp;
/** The most instructions the handler keeps. */
export declare const MAX: number;
/** Every tool the fleet's MCP server serves. */
export declare const ALL = "*";
export declare const micros: (dollars: string) => number;
export declare const dollars: (m: number) => string;
export declare function agent(raw: unknown): Agent;
/** A draft of an agent as it stands, to edit. */
export declare function draft(a: Agent): Draft;
export declare const EMPTY: Draft;
/** Why a draft cannot be saved as it stands, or '' when it can: English, marked (`phrase`), so a screen says it through `t`. */
export declare function refuse(d: Draft): string;
export declare function agents(t: Target): Promise<Agent[]>;
export declare function one(t: Target, ref: string): Promise<Agent>;
/** One run of an agent, as its profile lists it: ok or error, what it was given and what it said. */
export interface Run {
    id: string;
    status: string;
    model: string;
    input: string;
    output: string;
    error: string;
    ms: number;
    at: string;
}
export declare function run(raw: unknown): Run;
/** An agent with its instructions and its 20 latest runs, newest first (`recentRuns`). */
export declare function profile(t: Target, ref: string): Promise<{
    agent: Agent;
    runs: Run[];
}>;
/** An agent to start from: a default agent, a persona or a preset. */
export interface Cast {
    /** The name it is made under. */
    name: string;
    /** What Browse calls it. */
    title: string;
    description: string;
    /** What Browse lists it under. */
    category: string;
    model: string;
    instructions: string;
    /** Reads the instructions, where they are a file the host serves. */
    read?: () => Promise<string>;
    /** Its face, an address of the host. */
    avatar?: string;
    tools?: string[];
}
/** What an agent made from a template may spend until its owner says otherwise, in dollars: each month, and one run. */
export declare const CAST_CAP = "10";
export declare const CAST_TASK = "1";
/**
 * A name the API takes: accents dropped, any other run of characters a dash,
 * from a letter or digit, up to 64. "Spärck Jones" is Sparck-Jones.
 */
export declare const handle: (name: string) => string;
/** `name`, or `name-2`, `name-3`… : the first the org has no agent called, in any case. */
export declare function free(name: string, have: readonly {
    name: string;
}[]): string;
/** An address of the page as an https link the API keeps, or '' (a page served over http has none). */
export declare const link: (at: string | undefined, base: string) => string;
/**
 * Make the org's own agent from a template: under the first name the org has
 * free (read now, so it is never one that exists), with its instructions read
 * and its face linked. The template is not touched.
 */
export declare function use(t: Target, c: Cast, base: string): Promise<Agent>;
/** Anyone as a template: their name, who they are, and writing of theirs to take the voice from. */
export declare function person(name: string, about: string, writing: string, avatar?: string): Cast;
export declare function create(t: Target, d: Draft): Promise<Agent>;
/** The fields that differ from `was`, and nothing else: an omitted field keeps its value. */
export declare function changes(was: Agent, d: Draft): Record<string, unknown>;
export declare function update(t: Target, was: Agent, d: Draft): Promise<Agent>;
export declare function remove(t: Target, ref: string): Promise<void>;
/** The presets that make a working agent. */
export declare function presets(t: Target): Promise<Preset[]>;
/** A preset as a template. */
export declare function fromPreset(p: Preset): Cast;
