import { type Target } from './call.ts';
export declare const KIND_IDS: readonly ['image', 'video', 'audio', 'document', 'slides', 'type', 'model', 'code', 'file'];
export type Kind = (typeof KIND_IDS)[number];
/** The kinds a reader narrows to, in the order the Library lists them, '' being all; each label English and marked (`phrase`), drawn through `t`. */
export declare const KINDS: readonly {
    id: Kind | '';
    label: string;
}[];
export declare const SOURCES: readonly ['chat', 'dev', 'studio', 'workflow'];
export type Source = (typeof SOURCES)[number];
export type Scope = 'all' | 'mine' | 'shared';
/** A product, as a person names it: Chat, Dev and Studio are names, and Workflow a word, marked (`phrase`). */
export declare const SOURCE: Record<Source, string>;
export interface Item {
    id: string;
    kind: Kind;
    source: Source;
    name: string;
    mime: string;
    bytes: number;
    width: number;
    height: number;
    seconds: number;
    pages: number;
    /** The subject that made it. */
    owner: string;
    /** The reader made it. */
    mine: boolean;
    /** Its owner shared it with the org. */
    shared: boolean;
    project: string;
    /** What made it: a conversation, a Dev run, a Studio run, an automation's run. */
    ref: string;
    /** The app path back to what made it, or '' for none. */
    origin: string;
    /** The original, to open in place. */
    url: string;
    /** The original, as a download. */
    download: string;
    /** A still that shows it, or ''. An image is its own. */
    preview: string;
    expires: string;
    created: string;
    updated: string;
}
/** What a list is narrowed to. */
export interface Filter {
    kind?: Kind | '';
    source?: Source | '';
    ref?: string;
    project?: string;
    q?: string;
    /** RFC 3339 bounds on when an item was made. */
    since?: string;
    until?: string;
    scope?: Scope;
    limit?: number;
    cursor?: string;
}
export interface Page {
    data: Item[];
    /** The cursor of the next page, or '' at the end. */
    next: string;
}
/** An app path back to what made an item: under this origin, never another's. */
export declare const inApp: (v: unknown) => string;
/** One item as the platform answers it, or null for a row with no id. */
export declare function item(raw: unknown): Item | null;
export declare function items(t: Target, f?: Filter, init?: {
    signal?: AbortSignal;
}): Promise<Page>;
export declare function get(t: Target, id: string): Promise<Item>;
/** What an upload says about where a thing came from. */
export interface Made {
    source: Source;
    kind?: Kind;
    ref?: string;
    origin?: string;
    project?: string;
    /** The same owner, source and key answer the item already made. */
    key?: string;
    width?: number;
    height?: number;
    seconds?: number;
    pages?: number;
}
/** The largest thing an inline upload carries; larger files up to `MAX` reserve a signed PUT. */
export declare const INLINE: number;
/** The largest thing one upload carries (2 GiB). */
export declare const MAX: number;
/** Bytes as base64, in chunks a call stack holds. */
export declare function base64(bytes: Uint8Array): string;
/** Keep a file in the Library. */
export declare function upload(t: Target, file: {
    name: string;
    type: string;
    bytes?: Uint8Array;
    blob?: Blob;
}, made: Made): Promise<Item>;
export interface Change {
    name?: string;
    shared?: boolean;
    project?: string;
    commit?: boolean;
}
export declare function change(t: Target, id: string, c: Change): Promise<Item>;
export declare function remove(t: Target, id: string): Promise<void>;
/** A size the way a person reads it. */
export declare function size(bytes: number): string;
/** The day an instant falls on, as a section of the Library: Today, Yesterday (English, marked), then the month. */
export declare function day(iso: string, now?: Date): string;
/** Items under the day each was made, in the order given (newest first). */
export declare function days(list: Item[], now?: Date): {
    label: string;
    rows: Item[];
}[];
