/**
 * A repository's files at one revision, from the platform's native git.
 *
 *   GET /v1/git/repos/{name}/tree?ref=&path=   one directory, dirs first
 *   GET /v1/git/repos/{name}/blob?ref=&path=   one file; binary is base64,
 *                                              past 1 MiB it is truncated with no content
 *
 * A run pushes its branch to the forge, not here, so a run's files are read
 * through the run (changes.ts); these read a codebase as the platform holds it.
 */
import { type Target } from './call.ts';
export interface Entry {
    name: string;
    path: string;
    dir: boolean;
    size: number;
}
export interface Blob {
    path: string;
    /** Text, or '' when the file is binary or past the view cap. */
    text: string;
    binary: boolean;
    truncated: boolean;
    size: number;
}
export declare function tree(t: Target, repo: string, ref: string, path?: string): Promise<Entry[]>;
/** A tree answer's entries. A run's branch on the forge answers in the same shape. */
export declare function entries(raw: unknown): Entry[];
export declare function blob(t: Target, repo: string, ref: string, path: string): Promise<Blob>;
/** A blob answer. A run's branch on the forge answers in the same shape. */
export declare function file(raw: unknown, path: string): Blob;
