import { type Target } from './call.ts';
import { type Item } from './library.ts';
export interface Run {
    id: string;
    /** queued, running, succeeded, failed or cancelled. */
    status: string;
    title: string;
    /** What the run's writing step said, when its product is words. */
    text: string;
    outputs: Item[];
    /** Why it failed, in the platform's words, or ''. */
    error: string;
}
export interface Start {
    template: string;
    input: Record<string, unknown>;
    title?: string;
    parent?: string;
    /** A brand (design system) the run reads as brand.* — its palette, type and voice. */
    brand?: string;
}
/**
 * A design system: one of Studio's brands, the one store for them. Its tokens
 * are CSS custom properties (--background, --primary, --font-sans, --radius-md,
 * …, the form Studio's renderer reads), with `--component-*` and `--voice-*` as
 * quoted lines a model follows (design.ts `tokensOf`).
 *
 *   GET  /v1/studio/brands        {data: [brand]}   the ones you may read
 *   GET  /v1/studio/brands/{id}   one
 *   POST /v1/studio/brands        {name, tokens, shared?} → brand
 */
export interface Brand {
    id: string;
    name: string;
    tokens: Record<string, unknown>;
}
export declare function brandOf(raw: unknown): Brand;
export declare function brands(t: Target, init?: {
    signal?: AbortSignal;
}): Promise<Brand[]>;
export declare function brand(t: Target, id: string, init?: {
    signal?: AbortSignal;
}): Promise<Brand>;
export declare function keepBrand(t: Target, b: {
    name: string;
    tokens: Record<string, unknown>;
}, signal?: AbortSignal): Promise<Brand>;
export declare function run(raw: unknown): Run;
/** A run that has ended, one way or the other. */
export declare const ended: (r: Run) => boolean;
/** The ids of the templates this org may run. */
export declare function templates(t: Target, init?: {
    signal?: AbortSignal;
}): Promise<string[]>;
/**
 * Start a run and wait for it to end. Aborted, the run is cancelled so its
 * reservation is released; a run that fails is thrown with its reason.
 */
export declare function make(t: Target, s: Start, signal?: AbortSignal): Promise<Run>;
