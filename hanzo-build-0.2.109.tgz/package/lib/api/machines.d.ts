import { type Target } from './call.ts';
export declare const KINDS: readonly ['laptop', 'gpu', 'cloud', 'cluster', 'machine'];
export type Kind = (typeof KINDS)[number];
export interface GPU {
    vendor?: string;
    model?: string;
    memory?: number;
}
export interface MachineSpec {
    os?: string;
    arch?: string;
    cpus?: number;
    memory?: number;
    gpus?: GPU[];
}
export interface MachineMetrics {
    load1?: number;
    load5?: number;
    load15?: number;
    memUsed?: number;
    memFree?: number;
    gpuUtil?: number;
    cpuUtil?: number;
    cpuTemp?: number;
    gpuTemp?: number;
    gpuPower?: number;
    gpuPowerLimit?: number;
    gpuMemUsed?: number;
    gpuMemTotal?: number;
    diskUsed?: number;
    diskTotal?: number;
    diskRead?: number;
    diskWrite?: number;
    netRx?: number;
    netTx?: number;
    model?: string;
    decode?: number;
    prefill?: number;
    ttft?: number;
    running?: number;
    waiting?: number;
    at?: number;
}
export interface Machine {
    /** `tgt_…` */
    id: string;
    label: string;
    /** laptop | gpu | cloud | cluster | machine */
    kind: string;
    /** online | offline | draining, as the platform judges it from the last heartbeat. */
    status: string;
    /** "10 vCPU / 122G / 1× GB10", when the machine reported one. */
    capacity: string;
    /** The hostname its runs report, or '' for one addressed by id only. */
    host: string;
    /** The org's runs mapped to it, and how many of those are running now. */
    sessions: number;
    running: number;
    /** When it last beat, RFC 3339, or '' when it never has. */
    seen: string;
    serving?: boolean;
    createdAt?: string;
    updatedAt?: string;
    spec?: MachineSpec;
    metrics?: MachineMetrics;
}
export declare function formatBytes(bytes?: number): string;
export declare function formatPercent(fraction?: number): string;
export declare function formatRelative(isoDate?: string): string;
export declare function specSummary(m: Machine): string;
export declare function machine(raw: unknown): Machine;
export declare function machines(t: Target): Promise<Machine[]>;
/**
 * Register a machine by hand. One left unnamed takes its hostname, the name `hanzo
 * link` gives it; `hanzo link` on a machine with this hostname takes the row over.
 */
export declare function add(t: Target, what: {
    label: string;
    kind: Kind;
    host?: string;
    capacity?: string;
}): Promise<Machine>;
/**
 * A machine's status as a person reads it. The platform reports a hand-registered
 * machine at its registered status until a heartbeat arrives, so `online` holds only
 * once one has; before that it is `not seen yet`, and nothing is there to take a run.
 */
export declare function state(m: Machine): string;
/** Rename a machine, or drain it (`draining`) and bring it back (`online`). */
export declare function change(t: Target, id: string, what: {
    label?: string;
    status?: 'online' | 'draining';
    capacity?: string;
    kind?: Kind;
    host?: string;
}): Promise<Machine>;
export declare function remove(t: Target, id: string): Promise<void>;
/**
 * Mint the machine's claim key, answered this once: only its hash is kept, and
 * minting again ends the key before it. A runner on the machine sends it as
 * `X-Target-Key` when it claims the runs sent there.
 */
export declare function key(t: Target, id: string): Promise<string>;
