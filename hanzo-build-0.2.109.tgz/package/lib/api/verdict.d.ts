import { type Target } from './call.ts';
export type Verdict = 'up' | 'down' | null;
export declare function verdict(t: Target, session: string, project: string, v: Verdict): Promise<void>;
