import { type Target } from './call.ts';
export interface Codebase {
    org: string;
    name: string;
    description: string;
    /** HEAD's branch, or 'main' when the forge did not say. */
    branch: string;
    public: boolean;
    /** The https remote `git clone` takes, or ''. */
    clone: string;
    updated: string;
    branches: string[];
}
/** What the composer chip stores. `forge` marks a choice made from this list. */
export interface ForgeRepo {
    owner: string;
    name: string;
    full_name: string;
    private: boolean;
    default_branch: string;
    pushed_at: string;
    installation_id: number;
    forge: true;
    clone: string;
}
export declare function codebase(raw: unknown, org?: string): Codebase | null;
/** A chip row remembered as a forge codebase, when the list had not seen it yet. */
export declare function chosen(r: {
    owner: string;
    name: string;
    full_name?: string;
    private?: boolean;
    default_branch?: string;
}): ForgeRepo;
/** The chip's row for a codebase the forge listed. */
export declare function asRepo(c: Codebase): ForgeRepo;
/** Provision an empty repository. The name is the handle and the last path segment. */
export declare function create(t: Target, name: string, description?: string): Promise<Codebase>;
export declare function codebases(t: Target, q?: string): Promise<Codebase[]>;
/** One codebase, so the branch chip can list what HEAD can point at. */
export declare function one(t: Target, name: string): Promise<Codebase | null>;
/**
 * Delete a codebase from the forge, and its history with it. Nothing else goes:
 * a link that syncs into it, or a project built from it, is dropped on its own.
 */
export declare function remove(t: Target, name: string): Promise<void>;
