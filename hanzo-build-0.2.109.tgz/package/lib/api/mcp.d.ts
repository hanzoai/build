import { type Target } from './call.ts';
export interface Native {
    name: string;
    description: string;
    ops: string[];
}
/** The servers in one tools/list answer. A missing tool array is a refusal. */
export declare function nativesOf(body: unknown): Native[];
/** Every native server the fleet MCP server is serving. */
export declare function natives(t: Target): Promise<Native[]>;
