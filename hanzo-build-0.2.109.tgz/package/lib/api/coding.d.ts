import type { Say } from '@hanzo/i18n/react';
import { type Target } from './call.ts';
export type Mode = 'build' | 'plan' | 'setup';
/** Why this mode cannot run where it is sent, in the words of the `t` handed (English without one), or '' when it can. */
export declare const unhonoured: (mode: Mode | undefined, target?: string, t?: Say) => string;
export interface Ask {
    /** The task, in the words you would use with a colleague. */
    prompt: string;
    /**
     * The repository: its name in the caller's org, or `owner/name` as a run's
     * record states it, which the engine resolves as it did for that run.
     * Omitted starts something new.
     */
    repo?: string;
    /** The branch to start from. Omitted takes the repository's default. */
    base?: string;
    /** One of the org's machines. Omitted is the sandbox. */
    targetId?: string;
    /** The project slug the run works on. */
    project?: string;
    /** An earlier run's session to continue from, on the branch it pushed. */
    after?: string;
    mode?: Mode;
    /** The model the agent thinks with, by the id GET /v1/models lists; Enso is sent as itself. */
    model?: string;
    effort?: string;
    /** The number of the issue on `repo` this run resolves: its pull request says `Closes #<n>`. */
    issue?: number;
}
export interface Run {
    session: string;
    repo: string;
    branch: string;
    routed: boolean;
    target: string;
}
/**
 * The request body: only what was asked, with no empty strings sent as values.
 * A run in the sandbox asks for one with a desktop, so its Desktop tab has a
 * screen to show; a machine is whatever it is.
 */
export declare function body(ask: Ask): Record<string, string | number | boolean>;
export declare function start(t: Target, ask: Ask): Promise<Run>;
/**
 * New words for a sandbox run that is working. The run takes its task on its
 * command line and reads nothing after (apps/coding steer.go), so the platform
 * stops it with its work kept on its branch and starts a follow-up from there
 * with the words; the follow-up's session arrives on this run's own stream as
 * its `followed` status (turn.ts `followed`).
 */
export declare function steer(t: Target, session: string, text: string): Promise<void>;
/** A run a follow-up continues, as its record states it. */
export interface Earlier {
    id: string;
    title: string;
    /** `owner/name`, as the record states it. */
    repo: string;
    /** The branch it started from, or '' for the repository's default. */
    base: string;
    /** 'sandbox', or the id of the machine it ran on. */
    environment: string;
    project: string;
    mode: string;
    /** Its work is on its own branch (turn.ts `settled`). */
    pushed: boolean;
}
/**
 * The earlier run's ask, without the codebase its title leads with (`universe:
 * add the widget`), or the `new project:` the platform titles a run that made its
 * codebase with (apps/coding start.go).
 */
export declare function headline(title: string, repo: string): string;
/**
 * A new run continuing an earlier one in its mode: what the person said, and
 * which run it follows, because the new run's agent reads nothing else. With
 * nothing said it goes on with the earlier ask, in the words the platform uses
 * when it carries a paused run on (apps/coding steer.go followUp).
 */
export declare function followUp(e: Earlier, said: string): Ask;
/** A build of what a plan run answered: its ask as the title, and the plan to carry out. */
export declare function approve(e: Earlier, plan: string): Ask;
/**
 * The same ask again, where the earlier run worked and in its mode: what a failed
 * run's Try again starts. `ask` is the person's words as the run recorded them;
 * with none recorded, its title's.
 */
export declare function retry(e: Earlier, ask: string): Ask;
/** What a run left: a changed file, the whole change as a patch, or a link. */
export type Kind = 'file' | 'patch' | 'preview' | 'pull' | 'deploy';
export interface Artifact {
    /** A changed file's path in the workspace, `changes.patch`, or a link's name. */
    name: string;
    kind: Kind;
    /** A stored artifact's length in bytes; 0 for a link. */
    size: number;
    /** Where a link points: a preview's host, a pull request, a deployment. */
    url: string;
    /** A preview's port in the run's sandbox. */
    port: number;
}
export interface Left {
    /** When the artifacts were saved, or '' while the run has saved none. */
    saved: string;
    artifacts: Artifact[];
}
/** What a run left, kept after its sandbox is gone. */
export declare function artifacts(t: Target, session: string): Promise<Left>;
/** One stored artifact's bytes. */
export declare function artifact(t: Target, session: string, name: string): Promise<Blob>;
