import type { Target } from './call.ts';
export interface Place {
    /** `tgt_…`, or '' for the sandbox. */
    id: string;
    label: string;
    /** laptop | gpu | cloud | … as the platform names it; 'sandbox' for the sandbox. */
    kind: string;
    /** online | offline | draining | not seen yet, as machines.ts `state` reads it; the sandbox is always online. */
    status: string;
    /** "10 vCPU / 122G / 1× GB10", when the machine reported one. */
    capacity: string;
}
/** The sandbox, named in English and marked (`phrase`): a screen draws its label through `t`. */
export declare const SANDBOX: Place;
export declare function places(t: Target): Promise<Place[]>;
/** Whether a run sent here now would be taken. */
export declare const ready: (p: Place) => boolean;
