import { type Target } from './call.ts';
export interface Memory {
    /** `<owner>/<name>`, what a delete names. */
    id: string;
    content: string;
    /** user, fact, … as the platform files it. */
    kind: string;
    /** When it was last written, as the platform wrote it. */
    updated: string;
}
export declare function memoryOf(raw: unknown): Memory | null;
export declare function memories(t: Target, limit?: number): Promise<Memory[]>;
export declare function remember(t: Target, content: string): Promise<Memory | null>;
export declare function forget(t: Target, id: string): Promise<void>;
