/**
 * Server-Sent Events, read off a fetch body.
 *
 * `EventSource` cannot send an Authorization header, and the session stream
 * refuses a request without a principal, so the stream is read as a plain
 * response body and parsed here. The parser is pure: bytes in, frames and the
 * unfinished tail out, so it is tested without a network.
 *
 * Per the spec a frame ends at a blank line; `event:` names it (default
 * `message`), `data:` lines join with a newline, and a line starting `:` is a
 * comment — the platform's 25-second `: ping` keep-alive.
 */
export interface Frame {
    event: string;
    data: string;
    id: string;
}
/** Split `buffer` into complete frames and the tail that has not ended yet. */
export declare function parse(buffer: string): {
    frames: Frame[];
    rest: string;
};
/** Read `body` to its end, calling `on` for each frame. */
export declare function read(body: ReadableStream<Uint8Array>, on: (f: Frame) => void, signal?: AbortSignal): Promise<void>;
