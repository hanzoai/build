import type { Say } from '@hanzo/i18n/react';
import { type Target } from './call.ts';
import { type Source } from './library.ts';
export type { Source };
export type Kind = 'manual' | 'once' | 'hourly' | 'daily' | 'weekdays' | 'weekly' | 'cron';
export type Permissions = 'ask' | 'auto';
/** When it runs, in the person's own words and zone. */
export interface Schedule {
    kind: Kind;
    /** HH:MM, 24-hour, for daily, weekdays and weekly; 00:MM for hourly; YYYY-MM-DDTHH:MM for once, absent to run now. */
    at?: string;
    /** mon … sun, for weekly. */
    day?: string;
    /** Five fields, for cron. */
    cron?: string;
    /** An IANA zone; the platform reads an absent one as UTC. */
    tz?: string;
}
/** What an automation is: what the editor holds and the platform keeps. */
export interface Draft {
    name: string;
    instructions: string;
    /** A model id, or null for Enso, the default. */
    model: string | null;
    schedule: Schedule;
    permissions: Permissions;
    notify: boolean;
    /** The connected accounts each run's answer is posted to: x, linkedin, facebook. */
    postTo: string[];
    enabled: boolean;
    /** The product that made it: chat, dev, studio or workflow. */
    source: Source;
}
export interface Last {
    id: string;
    status: string;
    at: string;
    summary: string;
}
export interface Automation extends Draft {
    id: string;
    project: string | null;
    /** Named and not yet told what to do: it never runs until its instructions are saved. */
    draft: boolean;
    /** When it runs next, RFC 3339, or null when it runs only when asked or is off. */
    next: string | null;
    last: Last | null;
    created: string;
    updated: string;
}
/** Where one post went: its link, or the platform's reason it did not go. */
export interface Posted {
    to: string;
    url: string;
    error: string;
}
/** One run: succeeded, failed, running, queued, review (a post waiting for you), skipped or refused. */
export interface Run {
    id: string;
    status: string;
    at: string;
    finished: string | null;
    summary: string;
    /** The Dev run it started, or null when it started none. */
    session: string | null;
    /** The post its agent wrote, for an automation that posts. */
    draft: string;
    posts: Posted[];
    /** The Library items it made. */
    outputs: string[];
}
/** One automation as the platform answers it, or null for a row with no id. */
export declare function read(raw: unknown): Automation | null;
export declare function automations(t: Target): Promise<Automation[]>;
export declare function automation(t: Target, id: string): Promise<Automation>;
export declare function create(t: Target, d: Draft): Promise<Automation>;
/** What changed between two drafts, field by field: what a save sends. */
export declare function changes(was: Draft, now: Draft): Partial<Draft>;
/** Change an automation. A change to anything but `enabled` makes the caller the person it runs as. */
export declare function save(t: Target, id: string, change: Partial<Draft>): Promise<Automation>;
export declare function remove(t: Target, id: string): Promise<void>;
/** Start one run now. While one is going, the platform records this start as skipped. */
export declare function start(t: Target, id: string): Promise<{
    id: string;
    status: string;
}>;
export declare function runs(t: Target, id: string): Promise<Run[]>;
/** Post a held post to the automation's accounts, or discard it. */
export declare function review(t: Target, id: string, runId: string, post: boolean): Promise<Run>;
/** A schedule the way a person says it, in the words of the `t` handed (English without one). */
export declare function words(s: Schedule, t?: Say): string;
/** A ready-made automation to start a new one from. Its schedule names no zone: the page fills in the person's. */
export interface Starter {
    key: string;
    name: string;
    description: string;
    instructions: string;
    schedule: Schedule;
}
/** The starters, from GET /v1/auto/templates. */
export declare function starters(t: Target): Promise<Starter[]>;
/** What a person's words mean as a schedule: the schedule, how the platform says it back, and its next run. */
export interface Parsed {
    schedule: Schedule;
    says: string;
    /** RFC 3339, or null for one that runs only when asked. */
    next: string | null;
}
/** A schedule from a person's own words ("every monday at 9am"), read in `tz`. */
export declare function cron(t: Target, text: string, tz: string, init?: {
    signal?: AbortSignal;
}): Promise<Parsed>;
/** What a job is doing, in the five words every product shares. */
export type State = 'scheduled' | 'running' | 'succeeded' | 'failed' | 'cancelled';
export declare const STATES: readonly State[];
/** One run of anything that runs without its person watching. */
export interface Job {
    id: string;
    product: Source;
    kind: string;
    title: string;
    state: State;
    /** The product's own word for it: queued, review, skipped… */
    status: string;
    /** 0 to 1, or null when the product does not say. */
    progress: number | null;
    automation: string | null;
    /** The Dev run it started, whose transcript is its log. */
    session: string | null;
    ref: string;
    origin: string;
    summary: string;
    error: string;
    /** The Library items it made. */
    outputs: string[];
    /** Cents, or null while unknown. */
    cost: number | null;
    started: string;
    finished: string | null;
    updated: string;
}
/** One job as the platform answers it, or null for a row with no id. */
export declare function job(raw: unknown): Job | null;
export interface JobFilter {
    product?: Source | '';
    state?: State | '';
    limit?: number;
}
export declare function jobs(t: Target, f?: JobFilter): Promise<Job[]>;
export declare function one(t: Target, id: string): Promise<Job>;
/** What the events stream says: a job or an automation, as it stands now. */
export type Heard = {
    kind: 'job';
    job: Job;
} | {
    kind: 'automation';
    automation: Automation;
};
/** One frame of /v1/auto/events, or null for one this page does not read. */
export declare function heard(event: string, data: string): Heard | null;
/**
 * Read /v1/auto/events until `signal` ends it or the stream closes, calling `on`
 * for each job and automation it names. A fetch, because EventSource cannot
 * carry the bearer.
 */
export declare function events(t: Target, on: (h: Heard) => void, signal: AbortSignal, opened?: () => void): Promise<void>;
