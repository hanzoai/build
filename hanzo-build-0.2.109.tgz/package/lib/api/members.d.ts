import { type Target } from './call.ts';
export type Role = 'owner' | 'admin' | 'member';
export interface Member {
    /** `<homeOrg>/<username>`, IAM's id for the person. */
    user: string;
    /** The username alone. */
    name: string;
    role: Role;
    since: string;
}
export declare function member(raw: unknown): Member;
/** The org's people, owners first. Grants to a team or narrowed to one project are not the org's roster. */
export declare function roster(t: Target, org: string): Promise<Member[]>;
export interface Invitation {
    owner: string;
    name: string;
    email: string;
    /** What the invitee enters when they sign up. */
    code: string;
    /** How many may join with it, and how many have. */
    seats: number;
    used: number;
    /** `Active` is redeemable; anything else is not. */
    state: string;
    created: string;
}
export declare function invitation(raw: unknown): Invitation;
export declare function invitations(t: Target, org: string): Promise<Invitation[]>;
/** An address that can receive an invitation. */
export declare const EMAIL: RegExp;
/** Invite one address into the org: one seat, redeemable now, pinned to that address. */
export declare function invite(t: Target, org: string, email: string): Promise<Invitation>;
export declare function revoke(t: Target, i: Pick<Invitation, 'owner' | 'name'>): Promise<void>;
/** The org's own logo address as IAM holds it, or '' when it has none. */
export declare function logo(t: Target, org: string): Promise<string>;
