/**
 * The person's Chat conversations, as the agent service keeps them (the list
 * @hanzo/ai `threads.list` and @hanzo/rooms read).
 *
 *   GET /v1/agents/chat/conversations → {conversations: [{id, title, updatedAt, pinned, archived}]}
 *
 * Pinned first, then most recently spoken in; archived ones are left out. Only
 * the caller's own: another member's conversations are never listed.
 */
import { type Target } from './call.ts';
export interface Conversation {
    id: string;
    /** Taken from the opening message until renamed. */
    title: string;
    /** RFC 3339: when it was last spoken in, or ''. */
    updated: string;
    pinned: boolean;
}
export declare function conversation(raw: unknown): Conversation | null;
export declare function conversations(t: Target, signal?: AbortSignal): Promise<Conversation[]>;
