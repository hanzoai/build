/**
 * What a run changed, read from the forge it pushed to, as the person asking,
 * and its pull request merged there.
 *
 *   GET  /v1/agent/coding/{session}/changes     commits base..head, each file's patch, the pull request
 *   GET  /v1/agent/coding/{session}/tree?path=  one directory at the run's branch (its base until it pushes)
 *   GET  /v1/agent/coding/{session}/blob?path=  one file there, in /v1/git's blob shape
 *   POST /v1/agent/coding/{session}/merge       → {number, url, state, base}; 409 with the forge's reason
 *
 * Before the run pushes, changes answers empty, not 404.
 */
import { type Target } from './call.ts';
import { type Blob, type Entry } from './git.ts';
export interface Commit {
    sha: string;
    /** The first line. */
    message: string;
    author: string;
    date: string;
}
export interface Change {
    path: string;
    /** The old path of a rename, or ''. */
    from: string;
    status: 'added' | 'modified' | 'deleted' | 'renamed';
    additions: number;
    deletions: number;
    /** The file's unified diff hunks, or '' for a binary file. */
    patch: string;
    truncated: boolean;
}
export interface Review {
    author: string;
    state: string;
    body: string;
    at: string;
}
export interface Pull {
    number: number;
    url: string;
    title: string;
    state: 'open' | 'closed' | 'merged';
    /** Null when the forge has not worked it out. */
    mergeable: boolean | null;
    reviews: Review[];
}
export interface Changes {
    repo: string;
    base: string;
    head: string;
    commits: Commit[];
    files: Change[];
    pull: Pull | null;
}
export declare function changes(raw: unknown): Changes;
export declare function read(t: Target, session: string): Promise<Changes>;
export declare function tree(t: Target, session: string, path?: string): Promise<Entry[]>;
export declare function blob(t: Target, session: string, path: string): Promise<Blob>;
/** A pull request after its merge. */
export interface Merged {
    number: number;
    url: string;
    /** `merged`. */
    state: string;
    /** The branch it was merged into. */
    base: string;
}
/**
 * Merge the run's pull request into its base, at the commit the forge holds
 * now: a push after that is refused, not merged unseen. One already merged
 * answers as it is; a conflict, a closed pull request or a rule on the base is
 * a 409 carrying the forge's reason. Nothing is forced.
 */
export declare function merge(t: Target, session: string): Promise<Merged>;
