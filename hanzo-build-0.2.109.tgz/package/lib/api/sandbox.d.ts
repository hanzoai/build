import { type Target } from './call.ts';
export type Door = 'screen' | 'terminal';
/** Where a sandbox is in its life. */
export type State = 'pending' | 'running' | 'parked' | 'error' | 'gone';
export interface Box {
    id: string;
    state: State;
    /** When its lease ends, or a parked sandbox is retired; 0 when unknown. Unix ms. */
    ends: number;
    /** Why it could not come up, with state `error`. */
    error: string;
}
/** The sandbox as it stands. One the caller no longer holds is gone. */
export declare function sandbox(t: Target, id: string): Promise<Box>;
/** Park it: its pod stops, its disk and working tree stay. */
export declare function park(t: Target, id: string): Promise<Box>;
/** Give it a pod again, under the same id and tree. */
export declare function wake(t: Target, id: string): Promise<Box>;
/** A shell's tmux session name: the sandbox reattaches to it when the door opens again. */
export declare const NAME: RegExp;
/** Where to frame one door, with a fresh ticket in its address. */
export declare function door(t: Target, id: string, which: Door, session?: string): Promise<string>;
export interface Port {
    port: number;
    host: string;
}
/** What listens in the sandbox, ascending. */
export declare function ports(t: Target, id: string): Promise<Port[]>;
/**
 * An address that opens one port in a browser: its own origin, with a single-use
 * ticket that sets the preview's cookie and lands on its root.
 */
export declare function preview(t: Target, id: string, port: number): Promise<string>;
export interface Node {
    /** The resolved path inside the sandbox. */
    path: string;
    dir: boolean;
    /** A directory's entries, bare names, sorted. */
    names: string[];
    /** A file's text, or '' when it is binary or past the view cap. */
    text: string;
    binary: boolean;
    truncated: boolean;
}
/** One path in the sandbox, relative to its working directory. */
export declare function read(t: Target, sandbox: string, path: string): Promise<Node>;
