/**
 * The work an organization does: its projects, their issues, and its boards.
 *
 *   GET /v1/provider/github/repos?q=&owner=&limit=&after=   what the GitHub connection grants, most recently pushed first
 *   GET /v1/provider/github/installations                    the GitHub accounts it grants them from
 *   GET /v1/git/repos                                        the forge's repositories
 *   GET /v1/task/board                                       every issue and pull request: the forge's, and the task index's
 *   GET /v1/task/projects                                    the boards
 *   GET /v1/task/projects/{key}/issues                       one board's
 *
 * A project is a repository, so the list is those sources merged (merge.ts) and
 * not a second copy of them. An issue row from the board is read for what it
 * is: a forge issue names its forge repository and links to its page; a GitHub
 * issue the index mirrors names its address only in `extRef`
 * (`github:<owner>/<name>#<n>`), and its `number` there is the board's, not
 * GitHub's; any other index row's `repo` is what its writer said — a run's
 * repository, or a Linear team's key — and is resolved, never used raw.
 *
 * Creating, renaming and deleting a board are forge operations. This surface
 * reads the work and opens a run against it.
 */
import { type Target } from './call.ts';
import { type Repo } from './github.ts';
import { type Held, type Issue, type Site } from '../merge.ts';
import { type Link } from './links.ts';
export interface Board {
    id: string;
    key: string;
    name: string;
    description: string;
}
export declare function board(raw: unknown): Board | null;
/** One board row as an issue: what it is, where it lives, and which repository it says it is for. */
export declare function work(raw: unknown): Issue | null;
export declare function boards(t: Target, signal?: AbortSignal): Promise<Board[]>;
/** Every issue and pull request the org has, from the forge and the task index, each once. */
export declare function everything(t: Target, signal?: AbortSignal): Promise<Issue[]>;
/** The rows a list of projects is assembled from (merge.ts `assemble`), and which sources did not answer. */
export interface Sources {
    /** GitHub's grants to the org's connection, every page read so far: empty for anyone it does not answer. */
    hub: Repo[];
    /** The repositories linked from GitHub, each with the id dropping its link takes. */
    linked: Link[];
    /** The forge's repositories. */
    held: Held[];
    /** The org's projects that build from a repository. */
    sites: Site[];
    /** The GitHub accounts the org's connection grants from, for the owner filter. */
    owners: string[];
    /** GitHub's cursor for its next page, or ''. */
    next: string;
    /** GitHub accounts the connection could not read. */
    unread: string[];
    /** Sources that did not answer, as a reader names them. */
    missing: string[];
}
/**
 * What `missing` calls each source. A reader that cannot stand without one — a
 * removal that missed a link would leave a copy that comes back — asks by these.
 */
export declare const UNREAD: {
    readonly hub: 'GitHub';
    readonly linked: 'the linked repositories';
    readonly forge: 'the forge';
    readonly sites: 'the projects';
};
export interface SourceQuery {
    /** Searched by GitHub; the rest are searched where they are drawn. */
    q?: string;
    /** One GitHub account. */
    owner?: string;
    /** GitHub's cursor: read only GitHub's page after it. */
    after?: string;
}
/**
 * What the org's projects are made from, each read on its own: the links (GET
 * /v1/sync), the forge's repositories, the org's projects, and GitHub's grants
 * — searched and paged by GitHub, and empty for an operator with no GitHub of
 * their own, which is why it is never the only source. One that fails leaves the
 * others standing and is named in `missing`. A next page reads GitHub alone.
 */
export declare function sources(t: Target, p?: SourceQuery, signal?: AbortSignal): Promise<Sources>;
/** A repository a run and an environment can address on the forge, by the name its copy has there. */
export interface Home {
    /** The forge name: what a run's `repo` and `/v1/environment/{repo}` take. */
    name: string;
    /** `owner/name` as people know it: GitHub's address for a linked one, the org's for one made on the forge. */
    label: string;
    branch: string;
}
export interface Homes {
    homes: Home[];
    /** Both sources answered, so a name missing from `homes` is not the org's. */
    whole: boolean;
}
/**
 * Every repository on the forge a run can work on: the forge's own and every
 * linked repository's copy (GET /v1/git/repos does not list an estate's copies;
 * GET /v1/sync does). Throws only when neither answered.
 */
export declare function homes(t: Target, signal?: AbortSignal): Promise<Homes>;
