import { type Target } from './call.ts';
export interface Connector {
    id: string;
    name: string;
    /** Whether this deployment can connect it at all. */
    available: boolean;
    connected: boolean;
    /** The connected account's own name: the Slack workspace, the GitHub login. */
    account: string;
    since: string;
    /** Why it cannot be connected here, when it cannot. */
    note: string;
}
export declare function connector(raw: unknown, id?: string): Connector;
export declare function read(t: Target, id: string): Promise<Connector>;
/**
 * The social accounts an organization connects. An automation posts text to
 * the ones that take it; Instagram and TikTok take only images and video, and
 * say so. `needs` is what connecting waits on while Hanzo's app with the
 * platform is not set up. Its sentences are English and marked (`phrase`):
 * a screen draws them through `t`.
 */
export declare const SOCIAL: readonly {
    id: string;
    name: string;
    posts: boolean;
    needs: string;
    takes?: string;
}[];
/** The provider's consent page for this org; its return lands on `back` when that is a Hanzo app page. */
export declare function authorize(t: Target, id: string, back?: string): Promise<string>;
/**
 * Forget the org's connection to a provider: every account, or the one `account`
 * names (a GitHub login). For GitHub the platform also removes its App from an
 * account no other org uses, so connecting that account again is a fresh install.
 */
export declare function disconnect(t: Target, id: string, account?: string): Promise<void>;
export interface Channel {
    id: string;
    name: string;
    private: boolean;
    /** Whether Hanzo has joined it. */
    member: boolean;
}
export interface Channels {
    channels: Channel[];
    next: string;
}
export declare function channels(t: Target, cursor?: string): Promise<Channels>;
