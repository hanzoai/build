import { type Target } from './call.ts';
import { type Tool } from './tools.ts';
/** An org's own skill. */
export interface Skill {
    /** Derived from the name, and what a delete addresses. */
    id: string;
    name: string;
    description: string;
    /** The SKILL.md body. */
    content: string;
    /** When it was last written, Unix seconds. */
    created: number;
    /** The repository it was read from, or '' for one written here. */
    source: string;
    /** False when no admin wrote it, so no run carries it; true, or unsaid by an older platform. */
    admitted: boolean;
}
/** One skill of the brand's catalogue. */
export interface Entry {
    name: string;
    description: string;
    /** The product it belongs to. */
    product: string;
}
export interface Catalogue {
    skills: Entry[];
    products: {
        name: string;
        count: number;
    }[];
}
/** A skill's name: one lowercase path segment, as the handler takes it. */
export declare const NAME: RegExp;
/** The most SKILL.md the handler keeps. */
export declare const MAX: number;
/** The tool name a skill is switched on by. */
export declare const tool: (name: string) => string;
/** The skill a tool name switches, or '' when it is not a skill's. */
export declare const nameOf: (tool: string) => string;
export declare function skill(raw: unknown): Skill;
export declare function catalogue(raw: unknown): Catalogue;
/** The org's skills that are on, brand and own. */
export declare function active(t: Target): Promise<Tool[]>;
export declare function authored(t: Target): Promise<Skill[]>;
/** Why a skill cannot be written as it stands, or '' when it can. English, marked (`phrase`): a screen says it through `t`. */
export declare function refuse(s: {
    name: string;
    content: string;
}): string;
export declare function write(t: Target, s: {
    name: string;
    description: string;
    content: string;
}): Promise<Skill>;
export declare function remove(t: Target, id: string): Promise<void>;
export declare function brand(t: Target): Promise<Catalogue>;
/** One catalogue skill's SKILL.md. */
export declare function document(t: Target, name: string): Promise<string>;
