/**
 * The plan's usage, as the gate counts it.
 *
 *   GET /v1/ai/limits   the plan, its request windows and each class it includes, as shares
 *   PUT /v1/ai/limits   {creditsAfterAllowance}: keep using a model on credits once the
 *                       plan's included usage of it is spent; answers the limits after it
 *
 * The shape is cloud's `aiLimits` (apps/ai/limits_ops.go): `plan` is the rung the
 * caller is served as, `free` with none; `session` and `day` bound every request
 * the plan covers; `classes.premium` (third-party frontier models) and
 * `classes.ours` (Hanzo's) are each the billing period's share used, with a
 * shorter `window` where the plan sets one. Never a dollar, a count or a cap.
 *
 * Only an org admin may change how a pooled org wallet pays (403 otherwise).
 */
import { type Share, type State } from '../plan.ts';
import { type Target } from './call.ts';
export type Class = 'premium' | 'ours';
export declare const CLASSES: readonly Class[];
/** A class's billing period, who pays for its next request, and its short window. */
export interface Allowance extends Share {
    /** plan, prepaid, credits, or none. */
    paying: string;
    window: Share | null;
}
/** A way past a limit, in the order the server sends them. */
export interface Action {
    /** upgrade and topup are pages (`url`); credits is the choice above; switch names a model. */
    kind: 'upgrade' | 'topup' | 'credits' | 'switch';
    label: string;
    url: string;
    plan: string;
    model: string;
}
/** One model whose share of the plan is used for now, answered by its fallback in chat. */
export interface Paused {
    model: string;
    fallback: string;
    resets: string;
}
export interface Limits {
    /** The rung served (`max-20x`); `free` where no plan counts. */
    plan: string;
    /** The billing period, RFC 3339; '' with no plan. */
    start: string;
    end: string;
    /** The worst class's state. */
    state: State;
    session: Share | null;
    day: Share | null;
    classes: Partial<Record<Class, Allowance>>;
    /** Present in limited mode: why, and in which classes. */
    limited: {
        reason: string;
        classes: Class[];
        message: string;
    } | null;
    actions: Action[];
    /** The plan that raises these limits, '' at the top. */
    upgrade: string;
    /** Whether the payer keeps using a model on credits once the plan's usage of it is spent. */
    credits: boolean;
    paused: Paused[];
}
/** The body of `GET /v1/ai/limits`, read field by field: what is not there is not drawn. */
export declare function parse(raw: unknown): Limits;
export declare function limits(t: Target): Promise<Limits>;
/** Turn on or off paying from credits once the plan's included usage runs out; answers the limits after. */
export declare function allow(t: Target, on: boolean): Promise<Limits>;
