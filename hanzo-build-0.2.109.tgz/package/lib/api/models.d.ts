/**
 * The models a run can be routed through, from the platform's own catalog.
 *
 *   GET /v1/models → {data: [{id, class, family, …}]}
 *
 * Read by `@hanzo/ui/models` `parseModels`, so a model's class and family are
 * the gateway's fields, never guessed from its id. `ENSO` is the router: it
 * picks a model per step, which is why it is the default, and a run that names
 * it names no model at all.
 */
import { type ModelCatalogEntry } from '@hanzo/ui/models/catalog';
import { type Target } from './call.ts';
export { ENSO } from '@hanzo/ui/models/catalog';
export type Model = ModelCatalogEntry;
export declare function models(t: Target): Promise<Model[]>;
/** The payer's plan usage, as `GET /v1/ai/limits` answers it: what a picker marks paused. */
export declare function limits(t: Target, signal?: AbortSignal): Promise<unknown>;
