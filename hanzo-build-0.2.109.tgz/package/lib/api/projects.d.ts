import { type Target } from './call.ts';
export interface Project {
    slug: string;
    name: string;
    /** The clone URL, or '' for a project with no repository. */
    repo: string;
    /** The branch pushes to which rebuild it, or ''. */
    branch: string;
    /**
     * Where it stands: `building` while a project that has never served is being
     * published, `live` once it serves, `error` when its build failed. A live
     * project stays `live` while it is built again.
     */
    status: string;
    /** The deployed address, or '' when nothing has shipped. */
    live: string;
    /** `public` or `private`, or '' when the platform did not say. */
    visibility: '' | Visibility;
    /** The catalog template's slug, or `<org>/<slug>` of the published project, this was taken from; '' for neither. */
    forked: string;
    /** Unix seconds; 0 when unknown. A deploy does not move `updated`. */
    created: number;
    updated: number;
}
export type Visibility = 'public' | 'private';
/** An address the preview may frame: https, or http on loopback when the builder is local too. */
export declare function safe(url: string, local?: boolean): string;
export declare function project(raw: unknown): Project;
export declare function projects(t: Target): Promise<Project[]>;
/**
 * Change a project's name, who can see it, or the repository it builds from;
 * what is not sent is left as it is.
 *
 * `repo` is the repository's address as a person gives it (../address.ts) and
 * the branch whose pushes rebuild it — left out, the platform takes `main`. It
 * is a GitHub repository, by any address GitHub hands out, and goes as its https
 * clone address; any other is refused before anything is sent. The platform may
 * still refuse to move a site that a repository in another account would serve
 * from elsewhere (409), and says why.
 */
export declare function change(t: Target, slug: string, what: {
    name?: string;
    visibility?: Visibility;
    repo?: {
        url: string;
        branch?: string;
    };
}): Promise<Project>;
/** Delete a project. Its site stops answering and its slug is free again. */
export declare function remove(t: Target, slug: string): Promise<void>;
/** One attempt to put a project on its address, as the platform recorded it. */
export interface Deployment {
    id: string;
    /** Counts the project's deployments from 1. */
    version: number;
    /** `building`, `live` or `error`, as the platform said. */
    status: string;
    /** The revision that was built, or ''. */
    commit: string;
    /** What happened, in words: the build's own note, or on a failure why it failed. */
    message: string;
    /** Unix seconds; 0 when unknown. */
    created: number;
    updated: number;
}
export declare function deployment(raw: unknown): Deployment;
/** A project's deployments, newest first: the first says how its latest build went. */
export declare function deployments(t: Target, slug: string): Promise<Deployment[]>;
/** The repository name a project's clone URL names — the last path segment, without `.git`. */
export declare function name(clone: string): string;
/** A starter from the public catalog. */
export interface Template {
    slug: string;
    title: string;
    category: string;
    description: string;
    framework: string;
    /** The repository the starter is cut from. */
    source: string;
    /** The starter's own live page, or '' when it has none the preview may frame. */
    demo: string;
}
/** The public catalog. It is reference content: no bearer, no org. */
export declare function templates(t: Target): Promise<Template[]>;
/**
 * Take a copy of a starter: a project whose repository is the starter's own,
 * so what opens is that template rather than a model's imitation of it. In an
 * org whose code is in a workspace the platform made, the copy is published at
 * once, and answers `building` until it is `live` or its build failed.
 */
export declare function fork(t: Target, slug: string): Promise<Project>;
/** `owner/name` from a clone URL — its last two path segments, without `.git`. */
export declare function address(clone: string): string;
/**
 * Whether a run worked on this project's repository. A run's record can be
 * moved into any project of the org, so a project shows only the runs on its
 * own code — their branch is what Files, Code and Publish read.
 */
export declare function ours(runRepo: string, projectClone: string): boolean;
