import { type Target } from './call.ts';
/** Where a tool comes from, in the order the platform ranks them. */
export declare const SOURCES: readonly ['connector', 'function', 'zap-service', 'agent', 'skill', 'mcp'];
export type Source = (typeof SOURCES)[number];
export interface Tool {
    name: string;
    source: Source;
    description: string;
    activated: boolean;
}
export declare function toolOf(raw: unknown): Tool | null;
export declare function tools(t: Target): Promise<Tool[]>;
/** Switch every tool in `names` on (or off), and answer the org's activated set. */
export declare function activate(t: Target, names: string[], on: boolean): Promise<string[]>;
