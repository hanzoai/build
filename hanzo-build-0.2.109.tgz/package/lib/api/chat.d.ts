/**
 * One completion from Hanzo's own models, asked with the person's own bearer so
 * it is attributed to them and metered as theirs.
 *
 *   POST /v1/chat/completions   {model, messages, max_tokens} → {choices: [{message: {content}}]}
 */
import { type Target } from './call.ts';
/** The quick model a plugin thinks with: planning a search, drafting a template. */
export declare const QUICK = "enso-flash";
export declare function ask(t: Target, system: string, user: string, signal?: AbortSignal, tokens?: number): Promise<string>;
/** The first JSON object in a model's answer, or null: a model may talk around it. */
export declare function json(said: string): Record<string, unknown> | null;
