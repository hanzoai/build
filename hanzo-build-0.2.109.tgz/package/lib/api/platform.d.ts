/**
 * Adding a repository to a project, which is how a project is published.
 *
 *   POST /v1/platform/apps {repo, ref, name, partOf, mode, tag?}
 *     → 202 {app, build?: {id, job, image, status}, declaration: {mode, ref, review, live, …}, notice?}
 *   GET  /v1/platform/builds → {builds: [{id, repo, commit, status, startedAt, duration}]}
 *
 * The declaration is a values file in universe. `branch` (the default) opens a
 * review and deploys nothing; `commit` writes main and CD applies it — and it
 * refuses to name an image that is not built yet, so publishing to main is two
 * calls: build on a branch, then commit that tag once the build is green. An
 * org admin gets both; anyone else gets the review link.
 *
 * A repository in the org's own code workspace is its project's site instead:
 * built in a sandbox and served at the project's address when the build
 * finishes. That answer is `declaration.live` with a `notice` saying so, and no
 * review; its build is on the same board, building, succeeded or failed.
 */
import { type Target } from './call.ts';
export interface Declare {
    /** The https clone URL. */
    repo: string;
    /** Branch, tag or sha to build. */
    ref: string;
    /** The app's name: a DNS-1123 label. */
    name: string;
    /** The project it joins. */
    project: string;
    mode: 'branch' | 'commit';
    /** Release an image an earlier call built, instead of building. */
    tag?: string;
}
export interface Declared {
    build: {
        id: string;
        job: string;
        image: string;
        status: string;
    } | null;
    mode: string;
    /** Where the declaration landed: main for a commit, the review branch otherwise. */
    ref: string;
    /** The pull request to open for a branch write, or ''. */
    review: string;
    /** Whether anything can deploy from this write. */
    live: boolean;
    /** What the platform says of this write in a sentence, or ''. */
    notice: string;
}
export interface Build {
    id: string;
    repo: string;
    commit: string;
    status: string;
    startedAt: string;
    duration: string;
}
/** A DNS-1123 label from anything: what an app may be named. */
export declare function label(s: string): string;
/** An https address, or '' — a review link is shown as a link only when it is one. */
export declare const https: (url: string) => string;
export declare function body(d: Declare): Record<string, string>;
export declare function declare(t: Target, d: Declare): Promise<Declared>;
export declare function builds(t: Target): Promise<Build[]>;
/** The clone URL for a GitHub repository. */
export declare const clone: (fullName: string) => string;
