import type { Say } from '@hanzo/i18n/react';
import type { Event } from './sessions.ts';
/** The payload as an object. A live frame may carry it as a JSON string. */
export declare function decode(payload: unknown): Record<string, unknown> | string | null;
/**
 * Whether an error is a model vendor's own words: a provider's name, its rate
 * headers, a key, or the JSON body it answers with. Those never reach the run
 * page — they say whose model it was and nothing a person can act on — so the
 * run says its plain line alone.
 */
export declare function vendor(error: string): boolean;
/** An error as the run page may show it: its own words, or the plain line when they are a vendor's. */
export declare const scrub: (error: string, t?: Say) => string;
/**
 * A run's error as one plain line with what to do, never the log it came from:
 * that goes in the Error step beside it (cards), unless it is a vendor's.
 */
export declare function plain(error: string, t?: Say): string;
/**
 * One event's sentence, or '' when it says nothing a person needs. `mode` is
 * the run's, from its record: a plan run's final status says the plan.
 */
export declare function said(e: Pick<Event, 'kind' | 'payload'>, mode?: string, t?: Say): string;
/** One line of the shell: a command the run started, or output that followed it. */
export interface ShellLine {
    role: 'cmd' | 'out';
    text: string;
}
/**
 * The shell beside the transcript. A tool call is the command; a log line, and
 * any stdout or stderr the payload carried, is the output. Status stays in the
 * transcript. Each line is capped so a payload that carried a file body cannot
 * fill the pane.
 */
export declare function shell(events: Pick<Event, 'kind' | 'payload' | 'seq'>[]): ShellLine[];
/** A step the run named. Done is a step whose status has settled. */
export interface StepLine {
    name: string;
    done: boolean;
}
/**
 * Tool calls, in the order they were first named. A later status for the same
 * step wins, and a run's steps follow one another, so a step another has
 * followed is over. `exit` is not a step: it is how the sandbox says one command
 * in it ended (apps/sandbox work.go).
 */
export declare function steps(events: Pick<Event, 'kind' | 'payload' | 'seq'>[]): StepLine[];
export interface Outcome {
    /** The last lifecycle status the run narrated, or ''. */
    status: string;
    /**
     * That the pull request could not be opened, as narrated, or ''. Shown as a
     * fact only — its text comes from an event any member can write, so it is
     * never put on screen as the reason.
     */
    problem: string;
    /**
     * The place in the run (its `seq`) of the latest status that said its work
     * went live on its project's site, or 0. It is the cue to read the project
     * again; the address shown is the project's own, never one an event names.
     */
    published: number;
}
/**
 * What the run narrated about how it ended, latest winning. Status text only:
 * the branch and the pull request are read from the run's record (`pull`).
 */
export declare function outcome(events: Pick<Event, 'kind' | 'payload' | 'seq'>[]): Outcome;
/** Why the run failed, as its last status says it, or '' when that status is not a failure. */
export declare function failure(events: Pick<Event, 'kind' | 'payload' | 'seq'>[], t?: Say): string;
/** The turns, ordered and deduped: a recorded read and the live feed overlap. */
export declare function merge<T extends Pick<Event, 'id' | 'seq'>>(...lists: T[][]): T[];
/** The actor, short enough to label a block: `hanzo/2d4d67ab`, not the whole subject. */
export declare function who(actor: string): string;
/**
 * A pull request address the builder will draw as a link: https, on GitHub or
 * the platform's own git, shaped like a pull request, and IN THE RUN'S OWN
 * REPOSITORY (`repo`, `owner/name`). Anything else is ''. Read from the run's
 * record, which the coding service writes — never from an event, which any
 * member of the org can append — and bound to the repository, because a record
 * can be moved into a project it did not work on.
 */
export declare function pull(url: string, repo: string): {
    href: string;
    label: string;
};
/** How a card's work went. One still running once the run has ended was cut off. */
export type Ran = 'running' | 'done' | 'error' | 'cancelled';
/**
 * One piece of the transcript, drawn by what it is.
 *
 *   said   prose: the agent's messages (markdown), or a person's steering words
 *   think  the agent's reasoning, folded until opened
 *   shell  a command the agent ran, and what it printed
 *   edit   files the agent changed; the diff is the run's Git tab
 *   step   a step of the run itself (lease, clone, install, push), or a tool the agent called
 *   todo   the agent's plan, as a checklist it ticks
 *   note   a lifecycle line: started, pushed, stopped
 *   plan   a plan run's answer, which can be approved into a build
 */
export type Card = {
    kind: 'said';
    key: string;
    who: 'person' | 'agent';
    text: string;
} | {
    kind: 'think';
    key: string;
    text: string;
} | {
    kind: 'shell';
    key: string;
    command: string;
    output: string;
    ran: Ran;
} | {
    kind: 'edit';
    key: string;
    files: string[];
    ran: Ran;
} | {
    kind: 'step';
    key: string;
    name: string;
    detail: string;
    output: string;
    ran: Ran;
} | {
    kind: 'todo';
    key: string;
    items: {
        text: string;
        done: boolean;
    }[];
} | {
    kind: 'note';
    key: string;
    text: string;
} | {
    kind: 'plan';
    key: string;
    text: string;
};
/**
 * A run's events, as the cards its transcript draws. `mode` is the run's, from
 * its record: a plan's final status is its plan, and nothing else draws a plan.
 *
 * The run's own steps arrive as `tool-call` {step, message, status}. The agent
 * narrates itself as `event` lines: an item is started, updated and completed
 * under one id, and its card is drawn once and kept current. Ids count from zero
 * in each agent process, so an id is the agent's within the thread it started. A
 * turn that fails is one plain line with the detail folded beneath it, drawn once
 * however many times it is said; an `error` on its own is the agent retrying and
 * is drawn only if the turn then fails. The final status carries the agent's
 * answer, drawn once. `log` is never drawn here.
 */
export declare function cards(events: Pick<Event, 'kind' | 'payload' | 'seq'>[], mode?: string, t?: Say): Card[];
/** The plan a plan run answered with, from its final status, or ''. */
export declare function answer(events: Pick<Event, 'kind' | 'payload' | 'seq'>[]): string;
export interface Settled {
    /** The run has said how it ended, or that it paused: its work is where it will stay. */
    settled: boolean;
    /** That work is on the run's own branch, which a follow-up can start from. */
    pushed: boolean;
}
/**
 * Whether the run has kept its work yet, and whether that work is on its
 * branch. A stop or a pause commits and pushes AFTER it is asked, and says so
 * in its status (apps/coding coding.go interrupted): until then a follow-up
 * would clone a branch the push has not reached.
 */
export declare function settled(events: Pick<Event, 'kind' | 'payload' | 'seq'>[]): Settled;
/** The session of the run that carried this one on (its `followed` status), or ''. */
export declare function followed(events: Pick<Event, 'kind' | 'payload' | 'seq'>[]): string;
