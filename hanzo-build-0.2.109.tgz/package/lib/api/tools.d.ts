/**
 * The org's tool plane: every tool it can reach, and which of them are on.
 *
 *   GET /v1/tool?source=&activated=true   {tools: [{name, source, description, activated, dispatchable}]}
 *   GET /v1/tool/activation               {enabled: [name]}
 *   PUT /v1/tool/activation               {activate: [name], deactivate: [name]} → {enabled: [name]}
 *
 * A tool is on per org. On is what puts a skill's SKILL.md in an agent's prompt
 * and what lets an MCP server's tool be called; a tool that is off is listed and
 * refused at call time. Any member of the org may switch one — the handler asks
 * for the org and nothing more.
 */
import { type Target } from './call.ts';
export interface Tool {
    /** The flat, fleet-wide name: `skill_<name>`, `<server id>_<tool>`, `agent_<name>`… */
    name: string;
    /** connector, function, zap-service, agent, skill or mcp. */
    source: string;
    description: string;
    activated: boolean;
}
export declare const names: (v: unknown) => string[];
export declare function tool(raw: unknown): Tool;
/** The tools in one listing, whichever of the plane's two envelopes it came in. */
export declare function toolsOf(raw: unknown): Tool[];
/** Every tool the org reaches, narrowed to one source and to the ones that are on when asked. */
export declare function tools(t: Target, q?: {
    source?: string;
    activated?: boolean;
}): Promise<Tool[]>;
/** The names that are on. */
export declare function enabled(t: Target): Promise<string[]>;
/** Switch names on and off; answers every name that is on afterwards. */
export declare function toggle(t: Target, on: string[], off?: string[]): Promise<string[]>;
