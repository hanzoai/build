import { type Target } from './call.ts';
export interface Repo {
    owner: string;
    name: string;
    /** `owner/name`. */
    full_name: string;
    private: boolean;
    default_branch: string;
    /** RFC 3339, or '' when GitHub did not say. */
    pushed_at: string;
    /** The App installation that grants access, or 0 for the person's own grant. */
    installation_id: number;
    /** The name it takes on the forge once brought there: `owner_name`, folded. */
    codebase: string;
}
export interface Repos {
    repos: Repo[];
    next: string;
    /** How many repositories match, across every page. */
    total: number;
    /** The installations that could not be read: a short list is then not the whole one. */
    unread: string[];
    /** Whether this answer is the person's OWN GitHub. */
    connected: boolean;
}
export interface Branch {
    name: string;
    /** The sha it points at, or ''. */
    commit: string;
    default: boolean;
}
export interface Branches {
    branches: Branch[];
    next: string;
    total: number;
}
export interface Connection {
    /** Whether this deployment can connect anyone at all. */
    configured: boolean;
    connected: boolean;
    /** The GitHub login, when connected. */
    login: string;
}
export declare function repo(raw: unknown): Repo;
export declare function branch(raw: unknown): Branch;
export interface RepoQuery {
    q?: string;
    owner?: string;
    limit?: number;
    after?: string;
}
export declare function repos(t: Target, p?: RepoQuery, signal?: AbortSignal): Promise<Repos>;
export interface BranchQuery {
    q?: string;
    limit?: number;
    after?: string;
}
export declare function branches(t: Target, owner: string, name: string, p?: BranchQuery, signal?: AbortSignal): Promise<Branches>;
export declare function connection(t: Target): Promise<Connection>;
/**
 * Where to send the person to authorize the platform's GitHub App — github.com
 * only. `back` is the page GitHub's return lands on; the platform keeps it only
 * when it is a Hanzo app page.
 */
export declare function connect(t: Target, back?: string): Promise<string>;
/** Finish the connect GitHub's return handed this page as `grant`. */
export declare function complete(t: Target, grant: string): Promise<Connection>;
export declare function disconnect(t: Target): Promise<void>;
/**
 * Said on the window when this page changes the GitHub connection (a connect
 * finished, a link or an App account let go), so every surface showing it
 * reads it again: Projects' line, Settings' Integrations, and the Hanzo app's
 * Quick setup (@hanzo/app Setup), which says it too. A name the two packages
 * agree on, so neither imports the other.
 */
export declare const CHANGED = "hanzo:github";
/** Say the GitHub connection changed. */
export declare function changed(): void;
/** Run `again` each time the GitHub connection changed; the answer stops it. */
export declare function heard(again: () => void): () => void;
/** A GitHub account the platform's App is installed on, as this org sees it. */
export interface Installation {
    login: string;
    /** `Organization` or `User`. */
    type: string;
    /** `all` or `selected` repositories. */
    grant: string;
    /** This org has bound it, and GitHub still has the App installed there. */
    connected: boolean;
}
/** The accounts this org has bound the App on. An org admin adds one through `/v1/provider/github/connect`. */
export declare function installations(t: Target): Promise<Installation[]>;
/**
 * Whether this page reaches GitHub at all, and as whom: the person's own
 * connection first, else the accounts the org has bound the App on. An org that
 * installed the App (onboarding's Connect GitHub) has its repositories to sync
 * without the person connecting their own, so it reads as connected too.
 */
export declare function linked(me: Connection, installed: Installation[]): Connection;
/** One repository the GitHub connection grants this organization. */
export interface Grant {
    owner: string;
    name: string;
    /** `owner/name`, the selector the importer accepts. */
    fullName: string;
    private: boolean;
    branch: string;
    /** The name it takes on the forge once brought there. */
    codebase: string;
    /** On the forge: linked and landed, or held there under its codebase name. */
    imported: boolean;
    /** `synced`, `conflict`, `pending`, `paused`, or '' while it is not linked. */
    status: string;
}
export interface Grants {
    repos: Grant[];
    /** Accounts the connection could not read. */
    unread: string[];
}
export interface Account {
    name: string;
    count: number;
    /** Named as unread and carrying no repositories. */
    blocked: boolean;
}
/**
 * One row of GET /v1/provider/github/repos (apps/provider github_index.go
 * repoView): `owner`, `name`, `full_name`, `private`, `default_branch`,
 * `pushed_at`, `installation_id`, `codebase`. Whether it is on the forge is not
 * in the row — `codebase` is the name it would take, not a sign it has — so
 * `imported` is decided by `grants` from the links and the forge.
 */
export declare function grant(raw: unknown): Grant | null;
/** Accounts the grant names, plus any account that could not be read. */
export declare function accounts(g: Grants): Account[];
/**
 * Every repository the GitHub connection grants, every page, with whether the
 * forge already has it: a link that has landed (GET /v1/sync, its `native`
 * state), or a forge repository under its codebase name (GET /v1/git/repos).
 */
export declare function grants(t: Target, signal?: AbortSignal): Promise<Grants>;
/** What an import queued: how many, and the name each takes on the forge, by `owner/name`. */
export interface Queued {
    queued: number;
    codebases: Record<string, string>;
}
/** Queue a mirror of the named repositories onto the forge. The names are `owner/name`. */
export declare function bring(t: Target, repos: string[]): Promise<Queued>;
/** What one issue sync did. */
export interface Synced {
    repos: number;
    issues: number;
    created: number;
    updated: number;
    failed: number;
    /** The pass stopped at its budget; syncing again continues where it stopped. */
    truncated: boolean;
}
/**
 * Mirror GitHub issues onto the board — open and closed, so a closed one reads as
 * closed here too. `repo` (`name` or `owner/name`) syncs one project; empty syncs
 * every repository the connection grants. Idempotent: a second sync updates and
 * never duplicates, and the App's webhook keeps them live afterwards.
 */
export declare function syncIssues(t: Target, repo?: string): Promise<Synced>;
