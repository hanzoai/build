import { type Target } from './call.ts';
export interface Plugin {
    /** What a delete addresses. */
    id: string;
    name: string;
    /** The connectors provider whose credential it reads, or ''. */
    provider: string;
    /** The TypeScript as written or generated. */
    source: string;
    /** When it was last built, Unix seconds. */
    built: number;
}
export interface Mount {
    name: string;
    enabled: boolean;
    prefixes: string[];
}
export interface Built {
    plugin: Plugin;
    /** The size of the bundle the runtime executes. */
    bytes: number;
    /** Whether a model wrote the source from a spec. */
    generated: boolean;
}
/** A plugin's name: one lowercase path segment, the id it runs by. */
export declare const NAME: RegExp;
export declare function plugin(raw: unknown): Plugin;
export declare function authored(t: Target): Promise<Plugin[]>;
export declare function mounted(t: Target): Promise<Mount[]>;
export interface Build {
    name: string;
    provider: string;
    /** Exactly one of the two carries text. */
    source: string;
    spec: string;
}
/** Why a plugin cannot be built as it stands, or '' when it can. English, marked (`phrase`): a screen says it through `t`. */
export declare function refuse(b: Build): string;
export declare function build(t: Target, b: Build): Promise<Built>;
export declare function remove(t: Target, id: string): Promise<void>;
