export declare function Run({ id }: {
    id: string;
}): import("react").JSX.Element;
