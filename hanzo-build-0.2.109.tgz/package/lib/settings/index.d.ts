import { type Section } from '../route.ts';
export declare function Settings({ section }: {
    section: Section;
}): import("react").JSX.Element;
