import type { Section } from '../route.ts';
export type Group = 'Settings' | 'Code' | 'Organization';
export declare const GROUPS: readonly Group[];
export declare const LIST: readonly {
    id: Section;
    label: string;
    group: Group;
}[];
/** A part's label as a list draws it: none for the first part, or where the part's first row already says it (Code). */
export declare const heading: (g: Group) => string;
