import { type Target } from '../api/call.ts';
/** What the credits section says first, on every surface: English, marked (`phrase`), drawn through `t`. */
export declare const SEPARATE: string;
export declare function Credits({ target, admin, add, onCard }: {
    target: Target;
    admin: boolean;
    add?: string;
    onCard?: () => void;
}): import("react").JSX.Element;
