export declare function Capabilities(): import("react").JSX.Element;
