import { type Say } from '@hanzo/i18n/react';
/** A status as a line says it. Code's place list says it the same way. */
export declare const said: (status: string, t: Say) => string;
export declare function Machines(): import("react").JSX.Element;
