export declare function Billing(): import("react").JSX.Element;
