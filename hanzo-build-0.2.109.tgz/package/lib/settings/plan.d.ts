import { type Target } from '../api/call.ts';
import { type Standing } from '../standing.ts';
/** The view, once read. */
export declare function Reading({ s, target, onPlans, onBilling, now, }: {
    s: Standing;
    target: Target;
    onPlans?: () => void;
    onBilling: () => void;
    now?: number;
}): import("react").JSX.Element;
/** The plan's usage, read as `target`. */
export declare function Plan({ target, onPlans, onBilling, now }: {
    target: Target;
    onPlans?: () => void;
    onBilling: () => void;
    now?: number;
}): import("react").JSX.Element;
