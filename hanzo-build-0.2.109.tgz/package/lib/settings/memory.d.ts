export declare function Memory(): import("react").JSX.Element;
