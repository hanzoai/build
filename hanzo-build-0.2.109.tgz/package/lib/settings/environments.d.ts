export declare function Environments(): import("react").JSX.Element;
