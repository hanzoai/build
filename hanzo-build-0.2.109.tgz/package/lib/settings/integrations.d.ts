import { type Connector } from '../api/provider.ts';
export declare function Integrations(): import("react").JSX.Element;
/**
 * The named social connectors, by id: whether each can be connected here and
 * whether it is. One that could not be read is left out, and its row reads on
 * as "Reading…" rather than taking the others with it.
 */
export declare function useSocial(signed: boolean, ids: readonly string[]): import("../data.ts").Read<Record<string, Connector>>;
