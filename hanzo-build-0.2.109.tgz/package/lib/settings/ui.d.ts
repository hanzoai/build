import type { ReactNode } from 'react';
/** A section's title, what it is for, and its one action. */
export declare function Heading({ title, detail, action }: {
    title: string;
    detail?: string;
    action?: ReactNode;
}): import("react").JSX.Element;
/** A group inside a section: a small title over what it holds. */
export declare function Group({ title, detail, action, children }: {
    title: string;
    detail?: string;
    action?: ReactNode;
    children: ReactNode;
}): import("react").JSX.Element;
/** A bordered list. Its rows draw their own dividers. */
export declare function Card({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
/** One row of a Card: what it is, a line about it, and what can be done to it. */
export declare function Row({ title, detail, leading, trailing, first, mono, }: {
    title: string;
    detail?: string;
    leading?: ReactNode;
    trailing?: ReactNode;
    first?: boolean;
    mono?: boolean;
}): import("react").JSX.Element;
/** A labelled control, with a line under it when there is more to say. */
export declare function Field({ label, hint, children }: {
    label: string;
    hint?: string;
    children: ReactNode;
}): import("react").JSX.Element;
/** The quiet line for empty, loading, signed-out and refused. */
export declare function Soft({ children }: {
    children: string;
}): import("react").JSX.Element;
/** `Sep 27, 2026` from an RFC 3339 instant, or '' when there is none. UTC, the calendar the platform bills and resets on. */
export declare function day(iso: string): string;
/** A credential the platform answers once: the value to copy, what it is, and what its copy control says. */
export declare function Once({ value, label, copy, children }: {
    value: string;
    label: string;
    copy: string;
    children?: ReactNode;
}): import("react").JSX.Element;
/** What the last action did, said once, where it was done. */
export declare function Note({ children }: {
    children: string;
}): import("react").JSX.Element | null;
