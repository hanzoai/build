export declare function Code(): import("react").JSX.Element;
