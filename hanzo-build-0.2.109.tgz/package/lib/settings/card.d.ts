import { type Method } from '../api/billing.ts';
/** The part of Square's Web Payments SDK this uses. */
interface Field {
    attach(el: HTMLElement): Promise<void>;
    tokenize(): Promise<{
        status: string;
        token?: string;
        errors?: {
            message?: string;
        }[];
    }>;
    destroy(): Promise<void>;
}
interface Sdk {
    payments(application: string, location: string): {
        card(options?: object): Promise<Field>;
    };
}
declare global {
    interface Window {
        Square?: Sdk;
    }
}
/** Anything but production loads the sandbox SDK, so a misread setting never arms real charges. */
export declare const sdk: (environment: string) => string;
export declare function AddCard({ open, onOpenChange, onSaved }: {
    open: boolean;
    onOpenChange: (o: boolean) => void;
    onSaved: (m: Method) => void;
}): import("react").JSX.Element;
export {};
