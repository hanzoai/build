/**
 * The sections of Settings, in the order the page lists them. A section is one
 * file under settings/ and one entry here; the route grammar names every
 * section there can be (route.ts SECTIONS), and this lists the ones built.
 */
import type { ReactNode } from 'react';
import type { Section } from '../route.ts';
import { type Group } from './list.ts';
export { GROUPS, type Group } from './list.ts';
export interface Entry {
    id: Section;
    label: string;
    group: Group;
    body: () => ReactNode;
}
export declare const ENTRIES: Entry[];
