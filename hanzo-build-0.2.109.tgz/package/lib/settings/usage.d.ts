export declare function Usage(): import("react").JSX.Element;
