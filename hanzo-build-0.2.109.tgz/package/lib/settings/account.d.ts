/** What a person may say they work on, each label English and marked (`phrase`), drawn through `t`. */
export declare const WORK: {
    id: string;
    label: string;
}[];
export declare function Account(): import("react").JSX.Element;
