export declare function General(): import("react").JSX.Element;
