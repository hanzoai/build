export declare function Sync(): import("react").JSX.Element;
