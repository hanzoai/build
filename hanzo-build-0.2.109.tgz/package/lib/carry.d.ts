import { type ReactNode } from 'react';
import { type Target } from './api/call.ts';
import { type GearState, type Mode } from './gear.ts';
import type { Composer, Prep, Turn } from './plugin.ts';
import type { Carried, Modes, Shelf } from '@hanzo/ui/chat';
/** What the surface lends the plugins: its draft, its files, its way about. */
export type Lent = Omit<Composer, 'target' | 'show'>;
export interface Carry {
    gear: GearState;
    skills: Shelf;
    /** The design systems (Studio brands): attach one, or make one by chat. */
    design: Shelf;
    /** The plugins that run for this person (`@` lists the same). */
    plugins: Shelf;
    /** A dialog a plugin opened, for the surface to draw; null when none is. */
    dialog: ReactNode;
    /** Whether a plugin that prepares a message is on. */
    preparing: boolean;
    /** What the plugins that are on add to the message about to go. */
    prep: (turn: Omit<Turn, 'design'>, signal: AbortSignal) => Promise<Prep>;
    /** The chips after `+`: the skills on, Research, and Plan. */
    on: Carried[];
    /** The mode pill: this surface's modes, the conversation's choice among them. */
    mode: Modes<Mode>;
    /** Whether `what` may run: in Manual the person is asked (once, always in this conversation, or not); else yes. */
    allow: (what: Asked) => Promise<boolean>;
    /** The words the gear adds to every message, '' when none. */
    text: string;
}
/** What Manual asks about: a plugin, or a Dev run. `id` is what "always" remembers. */
export interface Asked {
    id: string;
    name: string;
    note: string;
}
/**
 * The conversation `key` names (`''` for one not begun), for target `t`.
 * `customize(tab)` opens Dev's Customize on that tab; `modes` are the ones this
 * surface offers (a choice it does not offer reads as Auto).
 */
export declare function useCarry(t: Target, key: string, customize: (tab: 'skills') => void, lent: Lent, modes?: readonly Mode[]): Carry;
