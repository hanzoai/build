import { type ReactNode } from 'react';
import type { Target } from './api/call.ts';
/** A fenced block an answer wrote out. */
export interface Artifact {
    /** The name it was given, or what it is: `index.html`, `html block`. */
    name: string;
    body: string;
    /** What a browser should take it as. */
    mime: string;
}
export interface RedoAction {
    mode: 'retry' | 'think' | 'web' | 'prompt';
    prompt?: string;
}
/** Every fenced block in `text`, in order. */
export declare function artifacts(text: string): Artifact[];
/** Whether a browser draws it as a page or a picture rather than as source. */
export declare const renders: (a: Artifact) => boolean;
/** The artifact worth opening first: the last page or picture, else the last block. */
export declare function lead(list: readonly Artifact[]): Artifact | null;
/** An address for an artifact's own bytes, typed so a browser renders it. */
export declare const blob: (a: Artifact) => string;
/** Markdown as a sentence a voice can read: code said as code, marks dropped. */
export declare function speakable(raw: string): string;
/** Reads `text` aloud, calls `done` when it stops for any reason, and answers the way to stop it. */
export type Listen = (text: string, done: () => void) => () => void;
/** A reader on the platform's voice (`/v1/audio/speech`), one reply at a time on the page. */
export declare function speaker(t: Target): Listen;
/** Copy, Rate/Vote, Listen, Share, Redo, Branch and Open under an answer; `children` follow them. */
export declare function Reply({ text, title, listen, onOpen, onRedo, onBranch, onRate, timestamp, children, }: {
    text: string;
    title?: string;
    listen?: Listen;
    onOpen?: () => void;
    onRedo?: (action: RedoAction) => void;
    onBranch?: () => void;
    onRate?: (vote: 'up' | 'down') => void;
    timestamp?: string;
    children?: ReactNode;
}): import("react").JSX.Element;
/** Which model answered, where the gateway says it was not the one asked for or a router. */
export declare function Served(_props: {
    served: string;
    asked?: string;
}): null;
