/** `just now`, `5m ago`, `3h ago`, `4d ago`, else the date, for an RFC 3339 instant; `—` for none. */
export declare function ago(iso: string): string;
