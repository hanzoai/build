import { type Model } from './api/models.ts';
/**
 * What a run starts on with nothing picked on this screen: Enso when Enso is
 * kept — the router serves every ask whether or not a catalog lists it — else
 * the kept model while the catalog still offers it (or has not answered yet),
 * else the catalog's own default for a conversation, else Enso. Never '' — an
 * empty chooser reads "Choose a model" and the run would name nothing on purpose.
 */
export declare function standing(kept: string, catalog: readonly Model[]): string;
export declare function usePick(kept: string, keep: (id: string) => void, catalog: readonly Model[]): readonly [string, (id: string) => void];
