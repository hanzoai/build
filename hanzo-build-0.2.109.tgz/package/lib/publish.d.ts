export interface Source {
    /** The https clone URL. */
    repo: string;
    /** What to call it: `owner/name` or a project's name. */
    title: string;
    ref: string;
    /** The app name to declare. */
    name: string;
    /** The project to add it to, when there already is one. */
    project?: string;
}
export declare function Publish({ source, onClose, onLive }: {
    source: Source | null;
    onClose: () => void;
    onLive?: () => void;
}): import("react").JSX.Element | null;
