import type { Read } from './data.ts';
import { type Standing } from './standing.ts';
import { type Label } from './plan.ts';
/** The ink a share is said in: quiet until it is close, and the one red when it is used. */
export declare const INK: {
    readonly ok: '$soft';
    readonly near: '$yellow10';
    readonly limited: '$red10';
};
/** A plan's name with its rung beside it, small: `Max` `20x`. A family's name is a name; Free and the like are words. */
export declare function Title({ label, size }: {
    label: Label;
    size?: '$3' | '$5' | '$6';
}): import("react").JSX.Element;
/** The standing, drawn: what `Meter` shows once it has read. */
export declare function Reading({ s, onPlans, onBilling, now }: {
    s: Standing;
    onPlans: () => void;
    onBilling: () => void;
    now?: number;
}): import("react").JSX.Element;
/**
 * The block an account menu leads with: `read` is `useStanding`, asked while
 * the menu is open. `onPlans` opens the plans and `onBilling` the page credits
 * live on; the host says where each is.
 */
export declare function Meter({ read, onPlans, onBilling }: {
    read: Read<Standing | null>;
    onPlans: () => void;
    onBilling: () => void;
}): import("react").JSX.Element;
