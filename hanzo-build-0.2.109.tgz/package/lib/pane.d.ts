/**
 * How a pane is cut: a card floating on the host's ground, read from
 * @hanzo/design's `--pane-*` tokens. Each falls back to the design value the
 * token names, so a host that sets none still draws a pane.
 *
 *   pane   fill, corner, edge, lens and drop, as gui props
 *   gap    the gutter between two panes, and the width of the edge in it
 */
export declare const pane: {
    readonly bg: 'var(--pane-fill, var(--sheet-1))';
    readonly rounded: 'var(--pane-round, var(--radius-xl))';
    readonly borderWidth: 1;
    readonly borderColor: 'var(--pane-edge, var(--white-08))';
    readonly backdropFilter: 'var(--pane-blur, blur(20px) saturate(1.8))';
    readonly boxShadow: 'var(--shadow-sheet-2)';
};
export declare const gap = "var(--pane-gap, var(--space-2))";
