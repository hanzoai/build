export declare function Git({ session, title, live }: {
    session: string;
    title: string;
    live: boolean;
}): import("react").JSX.Element;
/**
 * Merge for a run's pull request, shown while it is open: `POST …/merge` lands
 * the run's branch in its base at the commit the forge holds now. One press is
 * one merge — pressed again while it is out, nothing more is sent — and a
 * refusal says the forge's reason. `onMerged` reads the run again, which is
 * what closes the button: the pull request reads merged.
 */
export declare function Merge({ session, open, onMerged }: {
    session: string;
    open: boolean;
    onMerged: () => void;
}): import("react").JSX.Element | null;
/** A unified diff's lines, coloured by what each does: the Git tab's, and a transcript's edit card's. */
export declare function Patch({ text }: {
    text: string;
}): import("react").JSX.Element;
