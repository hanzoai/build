import type { RailSession } from '@hanzo/ui/chat';
export declare function Find({ open, onOpenChange, recents, onOpen, }: {
    open: boolean;
    onOpenChange: (o: boolean) => void;
    recents: RailSession[];
    onOpen: (id: string) => void;
}): import("react").JSX.Element;
