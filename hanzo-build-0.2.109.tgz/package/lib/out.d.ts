/**
 * A link out of the builder: a new tab, no handle back to this page, no
 * referrer. Only ever handed an https address the caller has already checked.
 * `away` is the same for an address that has to be minted first.
 */
import type { ReactNode } from 'react';
export declare function Out({ href, label, children }: {
    href: string;
    label?: string;
    children: ReactNode;
}): import("react").JSX.Element;
/**
 * Opens a tab for an address that takes a moment to mint: the tab opens now, while
 * the press still counts, and goes to the address once it comes. A refusal closes it.
 */
export declare function away(url: Promise<string>): Promise<void>;
