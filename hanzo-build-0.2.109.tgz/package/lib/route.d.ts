/**
 * The builder's addresses, under whatever path the host mounts it at.
 *
 *   ''              the empty state: a new run
 *   sess_<32 hex>   one run
 *   -/<screen>      a builder screen
 *   -/artifacts/<kind>      the Library narrowed to one kind (image, video, document, …)
 *   -/automations/<id>      one automation's editor and runs; `new` writes one
 *   -/settings[/<section>]  a section of Settings
 *   -/customize[/<tab>]     agents, skills, connectors and plugins: what the agent brings to a run
 *   -/customize/agents/<name>  one agent's profile
 *   -/plans                 the plans an organization can be on
 *   <org>/<repo>    a repository's workspace: a project is a repository on the forge
 *   <slug>          a deployed site's workspace (Artifacts)
 *
 * Unambiguous by construction: a project slug is `^[a-z0-9]([a-z0-9-]{0,38}[a-z0-9])?$`,
 * so it can hold neither the `_` a session id carries nor start with `-`, and a
 * repository is the one address with two segments, each starting with a letter
 * or a digit. Anything else is not an address here and reads as the empty state.
 *
 * A host whose address bar shows real paths writes a route with `href` and
 * reads one back with `parse` (hanzo.ai/dev/<href>):
 *
 *   ''                            New
 *   /run/<id>                     one run
 *   /projects/<org>/<repo>        a repository's workspace
 *   /projects/<slug>              a deployed site's workspace
 *   /machines · /environments     the rail's own words for -/settings/machines and -/settings/environments
 *   /<rest>                       every other address, its `-/` dropped: /projects, /customize/connectors, /settings/usage
 */
export type Screen = 'artifacts' | 'templates' | 'projects' | 'issues' | 'automations' | 'sync' | 'mcp' | 'plans';
/** Settings, one section each. Every setting the builder has lives on this page, none elsewhere. */
export declare const SECTIONS: readonly ['general', 'account', 'privacy', 'billing', 'usage', 'capabilities', 'memory', 'code', 'environments', 'machines', 'keys', 'members', 'integrations', 'notifications'];
export type Section = (typeof SECTIONS)[number];
/** Customize, one tab each: what the agent brings to a run, yours and to discover. Agents first. */
export declare const TABS: readonly ['agents', 'skills', 'connectors', 'plugins'];
export type Tab = (typeof TABS)[number];
export type Route = {
    kind: 'new';
} | {
    kind: 'run';
    id: string;
} | {
    kind: 'screen';
    screen: Screen;
    of?: Of;
} | {
    kind: 'settings';
    section: Section;
} | {
    kind: 'customize';
    tab: Tab;
} | {
    kind: 'agent';
    name: string;
} | {
    kind: 'project';
    slug: string;
} | {
    kind: 'repo';
    org: string;
    name: string;
} | {
    kind: 'automation';
    id: string;
};
/** The kinds the Library narrows to by address (api/library.ts KIND_IDS, plus `sites`). */
export declare const OF: readonly ['image', 'video', 'audio', 'document', 'slides', 'type', 'model', 'code', 'file', 'sites'];
export type Of = (typeof OF)[number];
export declare const SESSION: RegExp;
export declare const SLUG: RegExp;
/** An organization or a repository name on the forge (api/codebases.ts `NAME`). */
export declare const NAME: RegExp;
/** An automation's id, or `new` for one not yet written. */
export declare const AUTOMATION: RegExp;
export declare function route(path: string): Route;
/** Every route that names no record, for a host that writes a page per address ahead of time. */
export declare const PLACES: readonly Route[];
/** A route as a real path under the host's mount: '' for New, `/run/<id>`, `/projects/<org>/<repo>`, `/projects/<slug>`, else its path without `-/`. */
export declare function href(r: Route): string;
/** The route a real path under the mount names — the inverse of `href`. A query or fragment is not part of it. */
export declare function parse(address: string): Route;
/** The path for a route — the inverse of `route`. */
export declare function path(r: Route): string;
