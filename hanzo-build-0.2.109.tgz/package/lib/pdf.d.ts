/**
 * A PDF, read where it is: its text page by page, and what its structure says
 * about it — version, pages, metadata, encryption, how often it was revised
 * after it was written, and whether each signature still covers the bytes it
 * signed. Nothing leaves the browser.
 *
 * Text comes out of each page's content streams (and the forms they draw),
 * decoded with each font's ToUnicode map: Flate is undone by the platform's own
 * `DecompressionStream`, objects packed into object streams are unpacked, and a
 * font without a map is read as single-byte Latin. What it cannot read it says
 * it cannot: an encrypted file, a page that is only pictures (a scan needs OCR),
 * a stream in a filter other than Flate.
 *
 * A signature is checked for integrity, not trust: that its byte range starts at
 * the first byte, frames exactly its own signature, and reaches the end of the
 * file (or how many bytes were added after it), and that the digest the
 * signature carries (CMS `messageDigest`) is the digest of those bytes. Whether
 * the signer's certificate is trusted is not decided here.
 */
/** A name (`/Type`), a string's bytes, an indirect reference, an operator in a content stream. */
export declare class Name {
    readonly n: string;
    constructor(n: string);
}
export declare class Str {
    readonly s: string;
    constructor(s: string);
}
export declare class Ref {
    readonly n: number;
    constructor(n: number);
}
export declare class Op {
    readonly o: string;
    constructor(o: string);
}
export type Dict = Map<string, Value>;
export type Value = number | boolean | null | Name | Str | Ref | Op | Value[] | Dict;
/** The largest file read. */
export declare const LARGEST: number;
/** Bytes as a string of the same length, one char per byte. */
export declare function latin(b: Uint8Array): string;
/** A cursor over PDF syntax: the objects of a file, or the operators of a content stream. */
export declare class Lexer {
    readonly src: string;
    at: number;
    constructor(src: string, at?: number);
    skip(): void;
    /** The next value, or undefined at the end. */
    next(): Value | undefined;
    private literal;
}
interface Obj {
    value: Value;
    /** A stream's bytes as stored, still encoded. */
    data?: Uint8Array;
}
export interface Doc {
    bytes: Uint8Array;
    src: string;
    objects: Map<number, Obj>;
}
export declare function resolve(doc: Doc, v: Value | undefined, depth?: number): Value | undefined;
/** Undo a stream's filters: Flate, ASCII85 and hex, in the order named. Null for one it cannot undo. */
export declare function decode(doc: Doc, o: Obj): Promise<Uint8Array | null>;
/** ASCII85, as PDF writes it: `z` for four zeros, ending at `~>`. */
export declare function a85(s: string): Uint8Array;
export declare function inflate(data: Uint8Array): Promise<Uint8Array | null>;
/** Every object in the file, a later definition of a number winning, and those packed in object streams. */
export declare function open(bytes: Uint8Array): Promise<Doc>;
/** The pages in reading order, each with the resources it inherits. */
export declare function pages(doc: Doc): {
    page: Dict;
    resources: Dict;
}[];
/** A font as text reads it: how many bytes a code takes, what each code says, and how far it moves the pen. */
export interface Font {
    width: number;
    map: Map<number, string> | null;
    /** Each code's advance, in thousandths of an em; a code not listed advances `dw`. */
    advance: Map<number, number>;
    dw: number;
}
/** A ToUnicode CMap: its code width and its map. */
export declare function cmap(s: string, width: number): Pick<Font, 'width' | 'map'>;
/** A simple font's /Differences as text, where each glyph name says what it is. */
export declare function differences(v: Value | undefined): Map<number, string> | null;
/** The codes a string holds, `width` bytes each. */
export declare function codes(s: string, width: number): number[];
/** What one code says in a font. A two-byte font with no map says nothing: its codes are glyph numbers. */
export declare function say(code: number, f: Pick<Font, 'width' | 'map'> | undefined): string;
/** Each page's text, in reading order. */
export declare function text(doc: Doc): Promise<string[]>;
/** A PDF text string: UTF-16 or UTF-8 with its mark, else one byte a character. */
export declare function words(s: Str | Value | undefined): string;
/** A PDF date (`D:20261020113000-07'00'`) as a person reads it, or the string as it was. */
export declare function date(s: string): string;
export interface Signature {
    /** Who the signature dictionary names, or ''. */
    name: string;
    reason: string;
    location: string;
    time: string;
    /** Its SubFilter: adbe.pkcs7.detached, ETSI.CAdES.detached, … */
    filter: string;
    /** The byte range starts at the first byte and frames exactly the signature's own bytes. */
    framed: boolean;
    /** Bytes in the file after the end of what was signed; 0 when the signature covers the whole file. */
    after: number;
    /** The digest the signature carries matches the signed bytes; null when it was not checked. */
    intact: boolean | null;
    /** The digest that was checked, `SHA-256`, or why none was. */
    digest: string;
}
export interface Check {
    version: string;
    pages: number;
    encrypted: boolean;
    /** How many times it was saved: 1 is as first written, each incremental update adds one. */
    saves: number;
    info: Record<string, string>;
    /** What is wrong with its structure, in words; empty when nothing is. */
    problems: string[];
    signatures: Signature[];
}
/** The digest a CMS signature says it signed: the value of its messageDigest attribute, or ''. */
export declare function claimed(der: string): string;
/** What the file's structure says about it. */
export declare function check(doc: Doc): Promise<Check>;
export interface Read {
    check: Check;
    /** Each page's text; empty when the file is encrypted. */
    text: string[];
}
/** Read a PDF: its structure, and its text when it is not encrypted. */
export declare function read(bytes: Uint8Array): Promise<Read>;
/** What a read found, in words a model is given. */
export declare function report(file: string, r: Read): string;
export {};
