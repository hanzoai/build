import { type Attached } from './tools.tsx';
/** One vocabulary for the mode, on New and in a workspace: English, marked (`phrase`), drawn through `t`. */
export declare const MODES: readonly [{
    readonly id: 'build';
    readonly label: string;
    readonly hint: string;
}, {
    readonly id: 'plan';
    readonly label: string;
    readonly hint: string;
}];
/**
 * What was typed here and not sent, kept in this tab.
 *
 * Signing in leaves the page for hanzo.id and comes back (app/enter.ts), and the
 * sentence is still in the composer after. A draft its person SENT while signed
 * out is sent on the return: pressing Send was the ask, and the sign-in stood
 * between it and the run. Only this page writes `sent`, so no link can start a
 * run on somebody's behalf — an address carrying words only fills the composer.
 *
 * sessionStorage, because a draft belongs to the tab it was typed in and not to
 * the next person at this browser; a browser that refuses storage keeps it for
 * the life of the page, as before.
 */
export interface Unsent {
    draft: string;
    files: Attached[];
    sent?: boolean;
}
/** Hold what New has unsent, or forget it once there is nothing. */
export declare function hold(u: Unsent): void;
export declare function Landing({ onStarted }: {
    onStarted: (session: string) => void;
}): import("react").JSX.Element;
