import { type Verdict } from '@hanzo/ui/agents';
import { type ReactNode } from 'react';
import type { Card } from './api/turn.ts';
import { type Artifact, type Listen } from './reply.tsx';
export interface QueuedMessage {
    id: string;
    text: string;
}
export type TranscriptView = 'normal' | 'thinking' | 'verbose';
export declare function Transcript({ cards, live, empty, header, onApprove, approving, onVerdict, onOpen, onDiff, listen, end, view, queued, onSendQueued, }: {
    cards: Card[];
    /** The run is still working: a card still running shows it; otherwise it was cut off. */
    live: boolean;
    empty: ReactNode;
    header?: ReactNode;
    /** Build what a plan says. Absent, a plan has no button. */
    onApprove?: (plan: string) => void;
    approving?: boolean;
    /** Record a verdict on what the agent said; throws when it did not land. */
    onVerdict: (v: Verdict) => Promise<void>;
    /** Open what an answer wrote in the side panel. */
    onOpen?: (a: Artifact) => void;
    /** Open the run's diff in the side panel. */
    onDiff?: () => void;
    /** Read an answer aloud. */
    listen?: Listen;
    /** After the last card: how the run ended, when it ended on an error. */
    end?: ReactNode;
    /** How much of the agent's internal reasoning and tool output is unfolded by default. */
    view?: TranscriptView;
    /** Messages queued with Ctrl+Enter while the run works, waiting to be sent. */
    queued?: QueuedMessage[];
    /** Send a queued message immediately. */
    onSendQueued?: (id: string) => void;
}): import("react").JSX.Element;
