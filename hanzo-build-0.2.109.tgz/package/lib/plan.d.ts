import type { Say } from '@hanzo/i18n/react';
export interface Label {
    /** The family: `Max`. */
    name: string;
    /** The rung inside it, drawn small beside the name: `20x`; '' for none. */
    tag: string;
}
/**
 * A plan as a person reads it, from the slug billing serves (`max-20x`) and the
 * tier class beside it (`pro`). Null where neither names a plan: no slug and a
 * free or trial tier, which is no plan at all.
 */
export declare function label(slug?: string | null, tier?: string | null): Label | null;
/** A label as a sentence says it: `Max 20x`. */
export declare const said: (l: Label | null) => string;
export type State = 'ok' | 'near' | 'limited';
/** One window, as a share used. */
export interface Share {
    /** Used, 0 to 100. */
    percent: number;
    state: State;
    /** When it starts over, RFC 3339; '' for a session not running, which starts with the next request. */
    resets: string;
}
/**
 * One window off the wire, or null for a window that bounds nothing. The
 * server states a window's state only when the plan sets it a limit
 * (limits_ops.go `window`), so a window with no state is unbounded and not drawn.
 */
export declare function share(v: unknown): Share | null;
/** Which meter an account reads. */
export type Kind = 'plan' | 'free' | 'credits';
/**
 * The meter for a plan slug (billing's or the limits', `free` or '' for none),
 * the prepaid balance in cents (null where it could not be read) and the tier
 * class billing serves the account under: a paid plan's windows — a rung, or a
 * paid class with no rung (a plan recorded outside checkout, a partner org) —
 * and with no plan, the balance where there is money in it, else the free
 * allowance.
 */
export declare function kind(plan: string | null | undefined, balance: number | null, tier?: string | null): Kind;
/**
 * When something starts over, as a sentence says it: a time for within a day
 * (`5:00 PM`), else a date (`Nov 1`), periods ending on UTC days. '' for none.
 */
export declare function when(iso: string, now?: number): string;
/**
 * What a reader whose plan's included usage is used is told: the plan, which
 * models, and when they come back — `Your Max 20x plan’s included premium model
 * usage is used until 5:00 PM.` In the language of `t`.
 */
export declare function spent(l: Label | null, classes: readonly string[], resets: string, now?: number, t?: Say): string;
/**
 * The ways past a spent allowance, in this order and two at most: keep going
 * on credits — or, with none the server would let pay, add some — then the
 * upgrade; and a switch to another model where the server offers one. Taken
 * from what the server sent, so nothing is offered that it would refuse.
 */
export declare function ways<A extends {
    kind: string;
    label: string;
}>(actions: readonly A[], t?: Say): A[];
