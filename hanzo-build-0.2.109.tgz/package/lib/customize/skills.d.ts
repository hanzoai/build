import { type Pane } from './ui.tsx';
export declare function Skills({ view, q, adding, onAdding, onView, onCount }: Pane): import("react").JSX.Element;
