/**
 * What a read or a write that failed tells a person: plain words, never the
 * platform's internals. A refusal is read by its status; only a 400, 409 or
 * 422 carries the platform's own sentence, because those name what was wrong
 * with what was sent (a name taken, a build that failed and why). A sentence
 * this client wrote itself (a name that does not fit) is said as written.
 *
 * Said in the reader's language: the screen hands its `t` (English without
 * one). A sentence a module wrote is English and marked, so it goes through
 * `t`; the platform's own words are no key and come back from it as given.
 */
import type { Say } from '@hanzo/i18n/react';
export declare function say(e: unknown, t?: Say): string;
