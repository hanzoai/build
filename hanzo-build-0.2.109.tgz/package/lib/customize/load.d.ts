/**
 * Customize's reads: data.ts `useRead`, given up on after `WAIT`. A read that
 * hangs says so and offers a retry instead of loading forever; the request
 * itself is left to finish or fail on its own.
 */
import { type Read } from '../data.ts';
/** `p`, or a `Slow` refusal once `ms` pass first. */
export declare function within<T>(p: Promise<T>, ms?: number): Promise<T>;
export declare function useLoad<T>(load: (() => Promise<T>) | null, initial: T, key: unknown[]): Read<T>;
