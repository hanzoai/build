import { type ReactNode } from 'react';
export declare const mono: {
    fontFamily: string;
};
/** Which half of a tab: what there is to browse and add (first), or what the org already has. */
export type View = 'discover' | 'yours';
/** What the shell hands a tab: which half, the search, the Add dialog's state, and where to say how many are yours. */
export interface Pane {
    view: View;
    q: string;
    adding: boolean;
    onAdding: (open: boolean) => void;
    onView: (v: View) => void;
    onCount: (n: number) => void;
}
/** Tells the shell how many are yours, whenever that changes. */
export declare function useCount(n: number, onCount: (n: number) => void): void;
/** Whether a row answers a search: every word of it somewhere in the row's text. */
export { matches } from '../merge.ts';
/** Cards in as many columns as fit, one column on a phone. */
export declare function Grid({ children, label }: {
    children: ReactNode;
    label: string;
}): import("react").JSX.Element;
/** A square with the thing's picture, or its initial. */
export declare function Mark({ name, logo, icon, size }: {
    name: string;
    logo?: string;
    icon?: ReactNode;
    size?: number;
}): import("react").JSX.Element;
/**
 * One card: what it is, a few lines about it, a quiet fact under them, and its
 * action at the top right. Pressing the card opens it; the action is its own
 * control beside that, never inside it.
 */
export declare function Tile({ title, detail, meta, mark, action, onOpen, }: {
    title: string;
    detail?: string;
    meta?: string;
    mark?: ReactNode;
    action?: ReactNode;
    onOpen?: () => void;
}): import("react").JSX.Element;
/** The one card the shelf puts first, drawn larger. */
export declare function Featured({ title, detail, meta, mark, action, onOpen }: {
    title: string;
    detail: string;
    meta: string;
    mark: ReactNode;
    action?: ReactNode;
    onOpen: () => void;
}): import("react").JSX.Element;
/** A card's add control: Add (Use, for a template one is made from) while it is not yours, Added once it is. */
export declare function Add({ name, added, busy, onPress, use }: {
    name: string;
    added: boolean;
    busy?: boolean;
    onPress: () => void;
    use?: boolean;
}): import("react").JSX.Element;
/** A dialog with a title, a close control and a body that scrolls inside the window. */
export declare function Sheet({ title, open, onOpenChange, width, children }: {
    title: string;
    open: boolean;
    onOpenChange: (o: boolean) => void;
    width?: number;
    children: ReactNode;
}): import("react").JSX.Element;
/** Asks before a delete; says what goes with it. `what` is the thing's name, `says` comes already said. */
export declare function Confirm({ what, says, open, onOpenChange, onYes }: {
    what: string;
    says: string;
    open: boolean;
    onOpenChange: (o: boolean) => void;
    onYes: () => Promise<void>;
}): import("react").JSX.Element;
/** The quiet line for loading, a search that matched nothing, and signed-out. */
export declare function Soft({ children, action }: {
    children: string;
    action?: ReactNode;
}): import("react").JSX.Element;
/** A read that failed: what went wrong in plain words, and the one control that asks again. */
export declare function Failed({ error, onRetry }: {
    error: unknown;
    onRetry: () => void;
}): import("react").JSX.Element;
/** Nothing here yet: what this place holds, and the next step, as buttons. */
export declare function Empty({ title, detail, children }: {
    title: string;
    detail: string;
    children?: ReactNode;
}): import("react").JSX.Element;
/** What a signed-out visitor is told, with the one control that signs them in. */
export declare function Visitor({ children }: {
    children: string;
}): import("react").JSX.Element;
/** What the last action did, said once, where it was done. */
export declare function Line({ children }: {
    children: string;
}): import("react").JSX.Element | null;
/** A small heading over a run of cards. */
export declare function Part({ title, detail, action, children }: {
    title: string;
    detail: string;
    action?: ReactNode;
    children?: ReactNode;
}): import("react").JSX.Element;
/** A labelled control, with a line under it when there is more to say. */
export declare function Field({ label, hint, children }: {
    label: string;
    hint?: string;
    children: ReactNode;
}): import("react").JSX.Element;
/** Two or three choices side by side; the chosen one is filled. A count, when one is given, follows its label. Labels come already said. */
export declare function Choice<T extends string>({ value, options, onChange, label, }: {
    value: T;
    options: readonly {
        id: T;
        label: string;
        count?: number;
    }[];
    onChange: (v: T) => void;
    label: string;
}): import("react").JSX.Element;
/** A date from Unix seconds, or ''. */
export declare const day: (s: number) => string;
