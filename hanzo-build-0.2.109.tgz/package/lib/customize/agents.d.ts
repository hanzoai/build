import { type Cast } from '../api/agents.ts';
import { type Pane } from './ui.tsx';
/** Categories as Browse offers them: the default agents' and presets' first, as listed, then the rest by how many each holds. */
export declare function kinds(first: readonly Cast[], rest: readonly Cast[]): string[];
export declare function Agents({ view, q, adding, onAdding, onView, onCount }: Pane): import("react").JSX.Element;
/** One agent's page: who it is, what it runs on and reads, what it may call and spend, and what it has done. */
export declare function Profile({ name }: {
    name: string;
}): import("react").JSX.Element;
