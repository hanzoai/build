import { type Tab } from '../route.ts';
import { type View } from './ui.tsx';
/** What every run in the org loads: an org admin's to add to, a member's to read. */
export declare const ORG_KIT: Tab[];
export declare function Customize({ tab, view: first }: {
    tab: Tab;
    view?: View;
}): import("react").JSX.Element;
