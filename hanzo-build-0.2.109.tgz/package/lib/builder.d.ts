import { type Host } from './host.tsx';
/**
 * The builder. Mount it under a gui root (`<Hanzo>`), in a box with a height.
 *
 * `rail={false}` leaves the left column to the host, which lists the builder's
 * places and runs in its own rail with `DevSection`, and the ground to it too:
 * the builder is then a pane of the host's, and paints no background of its own.
 */
export declare function Builder({ host, rail }: {
    host: Host;
    rail?: boolean;
}): import("react").JSX.Element;
