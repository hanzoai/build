/** A markdown text, drawn. */
export declare function Prose({ text }: {
    text: string;
}): import("react").JSX.Element;
