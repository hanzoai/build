/** A repository on GitHub, by its account and its name. */
export interface At {
    owner: string;
    name: string;
}
/** What a pasted address may be, said when it is something else. */
export declare const ADDRESS: string;
/** The GitHub repository a pasted address names, or null when it names none. */
export declare function onGitHub(text: string): At | null;
/** The https address a project's repository is cloned from: what the sync app writes for a GitHub repository too. */
export declare const clone: (at: At) => string;
