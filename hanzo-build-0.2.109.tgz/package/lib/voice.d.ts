import { type Speech } from '@hanzo/voice';
import type { Target } from './api/call.ts';
/** The platform's ear and voice for a target: dictation, talk and Listen all hear through it. */
export declare function useEar(t: Target): Speech;
/** The language this browser is set to, when it is one dictation offers; English otherwise. */
export declare function spoken(): string;
/** The person's saved language (Settings → General), else this browser's, else English. */
export declare function useSpoken(): string;
