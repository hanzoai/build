/**
 * Files with an ask, for every composer the builder draws: they ride the
 * prompt as text — nothing is uploaded anywhere else. The paperclip is the
 * composer's (@hanzo/ui/chat); this reads what it picks and says what is held.
 */
import type { Say } from '@hanzo/i18n/react';
import type { Carried } from '@hanzo/ui/chat';
export interface Attached {
    name: string;
    text: string;
}
/** The ask with its attachments appended as fenced text. */
export declare function compose(prompt: string, files: Attached[]): string;
/** Read `list` into `have`, within the caps; answers the new list and what was refused, in the language of `t`. */
export declare function read(have: Attached[], list: FileList, t?: Say): Promise<{
    files: Attached[];
    note: string;
}>;
/** Ask the browser for files and read them in, within the caps; the picker is minted per press. */
export declare function pick(have: Attached[], onFiles: (f: Attached[]) => void, onNote: (n: string) => void, t?: Say): void;
/** The attached files as what the composer carries: a removable chip each. */
export declare function carrying(files: Attached[], onFiles: (f: Attached[]) => void): Carried[];
