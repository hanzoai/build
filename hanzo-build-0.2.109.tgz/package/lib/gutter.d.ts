/**
 * The grip between two panes, one for every edge: the sidebar's, the side
 * panel's, a run's chat against its work. The kit's Grip with its `inline` bar
 * (drawn only while it is reached for), its band centred across the gutter and
 * the bar halfway down it, so each edge looks and moves the same.
 *
 *   side    the edge the box it sits in is pinned to (Grip's): `left` for a
 *           sidebar, whose free edge is its right, `right` for an aside
 *   gap     the gutter's width; the frame's `--pane-gap` by default
 *   inset   the box's own border, px: an absolute place is measured inside it
 */
import { type GripProps } from '@hanzo/ui';
export type GutterProps = Omit<GripProps, 'bar'> & {
    gap?: string | number;
    inset?: number;
};
export declare function Gutter({ side, gap, inset, ...rest }: GutterProps): import("react").JSX.Element;
