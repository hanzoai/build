/**
 * The choice New starts from, kept in this browser so a codebase or an issue
 * opened from its own screen is what the composer is holding when it mounts.
 *
 * The key is the one `useKept` in New writes. A merge keeps the mode, the
 * model and the machine; it only replaces the fields the caller names.
 */
import { type Codebase, type ForgeRepo } from './api/codebases.ts';
import type { Project } from './merge.ts';
export interface Choice {
    repo: ForgeRepo | null;
    branch: string;
    place: string;
    mode: string;
    model: string;
    effort: string;
    /** A draft handed over by another screen. New copies it once and clears it. */
    ask: string;
    /** The issue that draft is, by the number the run's pull request closes; 0 for none. Handed over with it. */
    issue: number;
}
export declare const boardKey: (org: string | null) => string;
/**
 * The choice New opens on, field by field: the last layer that says something
 * wins. What was kept here, over the person's coding defaults, over the first
 * run's. A field kept as '' stays '' (the default branch, the sandbox): only a
 * field that is absent falls through, so a codebase or an issue handed over from
 * its own screen — which keeps the codebase and the words alone — still opens on
 * a model, a mode and an effort.
 */
export declare function settle<T extends object>(first: T, ...layers: (Partial<T> | null | undefined)[]): T;
/** Point New at a forge codebase, and optionally a first draft. */
export declare function pinCodebase(org: string | null, c: Codebase, ask?: string): void;
/** Which board Issues is showing. '' is every board. */
export declare function pinBoard(org: string | null, key: string): void;
/**
 * Point New at a project, and optionally a first draft (an issue's ask) and the
 * issue it closes. `where` is where the run works (merge.ts `home`): on the forge
 * it is chosen by its forge name, which is what a run and its environment
 * address; on GitHub by GitHub's address, so the run clones and proposes there.
 * Left out, the forge when the project is there. A project that is neither
 * cannot be worked on, and is refused here rather than handed to the platform.
 */
export declare function pinRepo(org: string | null, p: Project, ask?: string, issue?: number, where?: 'github' | 'forge' | null): void;
/**
 * Point New at a repository on GitHub, by GitHub's address: the one Sync just
 * brought in (sync.tsx), so the next run works on it and not on whatever was
 * chosen before. It is GitHub's address and not its forge copy's, because the
 * copy is still on its way there. A draft or an issue handed over with the
 * last choice was that repository's, and goes with it.
 */
export declare function pinHub(org: string | null, r: {
    owner: string;
    name: string;
    private: boolean;
    branch: string;
}): void;
/**
 * A repository on GitHub, chosen from the org's installation: the run works there.
 * Its `full_name` is GitHub's address, `github.com/owner/name` — what the list
 * shows, so a forge codebase of the same name is never mistaken for it, and what
 * a coding run takes to clone, push and propose on GitHub.
 */
export interface HubRepo {
    owner: string;
    name: string;
    full_name: string;
    private: boolean;
    default_branch: string;
    pushed_at: string;
    installation_id: number;
    github: true;
    /**
     * Given by its address (address.ts), not chosen from a list. It is the
     * person's word for where the run works, so no list is asked whether it is
     * still there: a public repository is on no list, and GitHub admits a run on
     * it all the same.
     */
    given?: boolean;
}
export declare const isHub: (repo: {
    github?: boolean;
    full_name?: string;
} | null) => repo is HubRepo;
/** A GitHub listing row as the composer offers it. */
export declare const asHub: (r: Omit<HubRepo, 'github'>) => HubRepo;
export declare const isForge: (repo: {
    forge?: boolean;
    name?: string;
} | null) => repo is ForgeRepo;
/**
 * What New can offer now, read to judge the repository it kept. Each is null
 * when it was not read — refused, let go, or still being read — and null
 * judges nothing.
 */
export interface Offered {
    /** Every name a run can address on the forge: the forge's own repositories (GET /v1/git/repos) and every linked copy (GET /v1/sync). */
    forge: readonly string[] | null;
    /** A page of GitHub's listing (GET /v1/provider/github/repos), with what it says stands behind it. */
    github: {
        repos: readonly {
            owner: string;
            name: string;
        }[];
        next: string;
        unread: readonly string[];
    } | null;
}
/**
 * Whether the repository New kept is gone from what it can offer: a GitHub
 * repository GitHub no longer lists — let go there, or GitHub disconnected,
 * which lists nothing — or a codebase the forge no longer holds. Left kept, it
 * is where every next run would go, whatever was linked or synced since.
 *
 * Only a WHOLE answer says a repository is missing. A GitHub page with another
 * after it, or with an installation it could not read, is not the whole list,
 * and a list that was not read is no list, so a refused or slow read never
 * loses a good choice. An address the person gave is theirs, and no list is
 * asked about it.
 */
export declare function gone(repo: {
    forge?: boolean;
    github?: boolean;
    name?: string;
    full_name?: string;
    given?: boolean;
} | null, now: Offered): boolean;
/** A repository queued onto the forge and not reported landed yet. */
export interface Pending {
    fullName: string;
    name: string;
}
export declare function readPending(org: string | null): Pending[];
export declare function writePending(org: string | null, rows: Pending[]): void;
