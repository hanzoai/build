/**
 * The markdown an agent writes, read into blocks and inline pieces: paragraphs,
 * headings, lists, quotes, rules, tables and fenced code; inline code, bold,
 * italics and links. What prose.tsx draws, as plain values.
 *
 * A link keeps an address only when it is http(s); anything else, and every
 * image, is its words.
 */
export type Block = {
    kind: 'paragraph';
    text: string;
} | {
    kind: 'heading';
    level: number;
    text: string;
} | {
    kind: 'code';
    lang: string;
    text: string;
} | {
    kind: 'list';
    ordered: boolean;
    start: number;
    items: {
        text: string;
        depth: number;
    }[];
} | {
    kind: 'quote';
    text: string;
} | {
    kind: 'rule';
} | {
    kind: 'table';
    head: string[];
    rows: string[][];
};
/** The blocks of a markdown text, in order. */
export declare function blocks(md: string): Block[];
export type Span = {
    kind: 'text' | 'code' | 'strong' | 'em';
    text: string;
} | {
    kind: 'link';
    text: string;
    href: string;
};
/** A line's inline pieces. A link to anything but http(s) is its words. */
export declare function spans(text: string): Span[];
