/**
 * A design system as the composer handles it: drafted by a model, kept as a
 * Studio brand (CSS custom properties, the form Studio's renderer reads), said to the
 * model on every message of a conversation it is attached to, and drawn as a
 * page to look at. Pure, so it is tested without a browser.
 */
import type { Brand } from './api/studio.ts';
/** What a model is asked to answer: the system in plain fields. */
export interface Draft {
    name: string;
    colors: Record<string, string>;
    fonts: {
        heading: string;
        body: string;
        mono: string;
    };
    /** Type sizes, px, smallest first. */
    scale: number[];
    /** Spacing steps, px. */
    spacing: number[];
    radius: Record<string, number>;
    /** One line each: how a button, card, input, nav… looks and behaves. */
    components: Record<string, string>;
    voice: {
        tone: string;
        do: string[];
        dont: string[];
    };
}
/** The schema the drafting call decodes under. */
export declare const SCHEMA: {
    readonly type: 'object';
    readonly additionalProperties: false;
    readonly required: readonly ['name', 'colors', 'fonts', 'scale', 'spacing', 'radius', 'components', 'voice'];
    readonly properties: {
        readonly name: {
            readonly type: 'string';
        };
        readonly colors: {
            readonly type: 'object';
            readonly additionalProperties: false;
            readonly required: readonly ['primary', 'secondary', 'accent', 'background', 'surface', 'text', 'muted', 'border'];
            readonly properties: {
                [k: string]: {
                    type: string;
                };
            };
        };
        readonly fonts: {
            readonly type: 'object';
            readonly additionalProperties: false;
            readonly required: readonly ['heading', 'body', 'mono'];
            readonly properties: {
                readonly heading: {
                    readonly type: 'string';
                };
                readonly body: {
                    readonly type: 'string';
                };
                readonly mono: {
                    readonly type: 'string';
                };
            };
        };
        readonly scale: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'number';
            };
        };
        readonly spacing: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'number';
            };
        };
        readonly radius: {
            readonly type: 'object';
            readonly additionalProperties: false;
            readonly required: readonly ['sm', 'md', 'lg'];
            readonly properties: {
                readonly sm: {
                    readonly type: 'number';
                };
                readonly md: {
                    readonly type: 'number';
                };
                readonly lg: {
                    readonly type: 'number';
                };
            };
        };
        readonly components: {
            readonly type: 'object';
            readonly additionalProperties: false;
            readonly required: readonly ['button', 'card', 'input', 'nav', 'hero'];
            readonly properties: {
                [k: string]: {
                    type: string;
                };
            };
        };
        readonly voice: {
            readonly type: 'object';
            readonly additionalProperties: false;
            readonly required: readonly ['tone', 'do', 'dont'];
            readonly properties: {
                readonly tone: {
                    readonly type: 'string';
                };
                readonly do: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
                readonly dont: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
            };
        };
    };
};
/** A model's answer as a Draft, or why it is not one. */
export declare function drafted(raw: unknown): Draft | string;
/**
 * A Draft as design tokens: CSS custom properties, the names @hanzo/design uses
 * (--background, --foreground, --primary, --font-sans, …). That is the one form
 * Studio's renderer takes (hanzo/render `tokens`: every key `--name`, every value
 * one declaration), so a deck, a document and a page draw from the same map.
 * The components and the voice ride along as quoted strings under their own names.
 */
export declare function tokensOf(d: Draft): Record<string, string>;
/** What a model is told on every message of a conversation the system is attached to. */
export declare function said(b: Brand): string;
/** The system drawn as a page: its palette, type, a button, a card, an input, its voice. */
export declare function preview(b: Brand): string;
