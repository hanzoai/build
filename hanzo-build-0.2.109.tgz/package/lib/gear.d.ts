import { type Target } from './api/call.ts';
/** What a run or a turn may do on its own: the permission mode. */
export type Mode = 'auto' | 'manual' | 'plan';
/**
 * The modes, one line each. Chat offers Auto and Manual; Dev adds Plan. Manual
 * is a real pause: before a plugin runs for a message (a search, a site read, a
 * deck), the person allows it once, always in this conversation, or not, and a
 * Dev run is asked for before it starts. Written in English and marked
 * (`phrase`): the composer draws each word through `t`.
 */
export declare const MODES: readonly {
    id: Mode;
    label: string;
    note: string;
}[];
/** The modes each surface offers. */
export declare const CHAT_MODES: readonly Mode[];
export declare const DEV_MODES: readonly Mode[];
export interface Gear {
    /** Skill names (`/v1/tool/skills`). */
    skills: string[];
    /** Connector ids (`/v1/tool/mcp/servers`). */
    connectors: string[];
    /** Plugin ids. */
    plugins: string[];
    /** A design system's id, or ''. */
    design: string;
    /** A machine's id, or '' for none (Chat) or the sandbox (Dev). */
    device: string;
    research: boolean;
    memory: boolean;
    mode: Mode;
    /** In Manual, the plugins allowed for the rest of this conversation. */
    allowed: string[];
}
export declare const BARE: Gear;
/** How many conversations keep a choice of their own: the document holds 16 KiB in all. */
export declare const KEEP = 30;
/** A stored value as a Gear, a field the reader does not know read as unset. */
export declare function gearOf(raw: unknown, base?: Gear): Gear;
/** `gears` with `key`'s entry first, cut to `KEEP`. */
export declare function shelve(gears: Record<string, Gear>, key: string, g: Gear): Record<string, Gear>;
export interface GearState {
    gear: Gear;
    /** Change this conversation's choice. */
    set: (patch: Partial<Gear>) => void;
    /** Add or take out one id of a list. */
    toggle: (field: 'skills' | 'connectors' | 'plugins', id: string) => void;
    /** Make this conversation's choice the person's default. */
    keep: () => void;
    /** Whether a save was refused, in the platform's words. */
    error: string | null;
}
/**
 * The gear of the conversation `key` names (`''` for one not begun: it reads and
 * writes the default until it has an id). Signed out, it lives for the page.
 */
export declare function useGear(t: Target, key?: string): GearState;
/** The dictation language the person keeps, null for Auto, and how to change it. */
export declare function useLanguage(t: Target): readonly [string | null, (id: string | null) => void];
