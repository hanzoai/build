import { type ReactNode } from 'react';
import { type Patch, type Prefs } from './api/pref.ts';
export interface PrefState {
    prefs: Prefs;
    /** The first read is still in flight. */
    loading: boolean;
    error: Error | null;
    /** Merge a change in and keep it. Throws the platform's refusal. */
    save: (patch: Patch) => Promise<void>;
}
export declare function PrefsProvider({ children }: {
    children: ReactNode;
}): string | number | bigint | boolean | import("react").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | Iterable<ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | null | undefined;
/** The settings; with `false`, null where nothing holds them (the side panel drawn without a host: hanzo.team's rooms). */
export declare function usePrefs(): PrefState;
export declare function usePrefs(need: false): PrefState | null;
/** The type scale each text size is drawn at. Medium is the design system's own. */
export declare const SCALE: {
    readonly small: 0.9;
    readonly medium: 1;
    readonly large: 1.15;
};
/**
 * The saved theme handed to the host, and the text size and motion put on the
 * page. A stylesheet rather than a property on <html>: the design system's own
 * root re-applies its appearance on mount, and a rule marked important outlasts
 * that, while the builder is on the page and no longer.
 */
export declare function Look(): import("react").JSX.Element | null;
