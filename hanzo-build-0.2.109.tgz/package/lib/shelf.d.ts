/**
 * What this org has deployed: a few starters to make something new from, then
 * every site under the month it was last edited, whether it is public or
 * private, and its rename, repository, visibility and delete. A site belongs to
 * the org and names no author, so the list does not split yours from a
 * colleague's — which is why it is a section of its own under the Library's
 * items, which are yours.
 *
 * Its repository is the one its builds are cut from, by a GitHub address in any
 * form GitHub hands out (address.ts), with the branch whose pushes rebuild it.
 */
export declare function Sites(): import("react").JSX.Element;
export declare function Templates(): import("react").JSX.Element;
