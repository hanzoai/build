import { type At } from './address.ts';
export declare function Confirm({ open, onOpenChange, title, says, act, run, }: {
    open: boolean;
    onOpenChange: (o: boolean) => void;
    title: string;
    /** The whole consequence, stated plainly. */
    says: string;
    /** The button's word: Delete, Remove, Forget. */
    act: string;
    run: () => Promise<void>;
}): import("react").JSX.Element;
export declare function Rename({ open, onOpenChange, title, name, run, }: {
    open: boolean;
    onOpenChange: (o: boolean) => void;
    title: string;
    /** The name it has now. */
    name: string;
    run: (next: string) => Promise<void>;
}): import("react").JSX.Element;
/**
 * The repository something works on, by the address a person has for it:
 * GitHub's page, its clone address, or either without the scheme (address.ts).
 * Anything else is refused here, in the dialog, with the forms it takes, before
 * anything is sent. With a `branch`, the branch is asked beside it.
 */
export declare function Address({ open, onOpenChange, title, says, act, address, branch, run, }: {
    open: boolean;
    onOpenChange: (o: boolean) => void;
    title: string;
    /** What the address decides, stated plainly. */
    says: string;
    /** The button's word: Use, Save. */
    act: string;
    /** The address it has now, or ''. */
    address: string;
    /** The branch it has now. Left out, no branch is asked. */
    branch?: string;
    run: (at: At, branch: string) => Promise<void>;
}): import("react").JSX.Element;
