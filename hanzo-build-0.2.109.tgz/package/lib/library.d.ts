import { type DropdownMenuProps } from '@hanzo/ui';
import { type Item } from './api/library.ts';
type MenuItems = NonNullable<DropdownMenuProps['items']>;
/** One square: the still, or the kind's mark on a quiet ground. */
export declare function Thumb({ x, size: n }: {
    x: Item;
    size?: number;
}): import("react").JSX.Element;
/** Open the Library at one item: the move leaves its id for the screen to take. */
export declare function want(id: string): void;
/** One item, read fresh so its signed URLs are live: the thing itself, then what it is. */
export declare function Preview({ id, rows }: {
    id: string;
    rows?: (x: Item) => MenuItems;
}): import("react").JSX.Element;
/** A run's outputs as small tiles: each opens in the Library. */
export declare function Outputs({ ids }: {
    ids: string[];
}): import("react").JSX.Element | null;
export declare function Library(): import("react").JSX.Element;
export {};
