/** Open Scheduled with a new task started from `prompt`: Dev's "Schedule this". */
export declare function schedule(prompt: string, go: (path: string) => void): void;
export declare function Scheduled(): import("react").JSX.Element;
