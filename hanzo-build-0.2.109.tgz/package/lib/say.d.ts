import type { Say } from '@hanzo/i18n/react';
export declare const english: Say;
