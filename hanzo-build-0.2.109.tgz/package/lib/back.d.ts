import type { Target } from './api/call.ts';
/** The query keys a return carries its answer in. */
export declare const ANSWER: readonly ['complete', 'grant', 'connected', 'account', 'error', 'reason'];
export type Landing = {
    kind: 'grant';
    provider: string;
    grant: string;
} | {
    kind: 'connected';
    provider: string;
    account: string;
} | {
    kind: 'error';
    provider: string;
    reason: string;
};
/** The answer a return carried in `search`, or null when it carried none. */
export declare function landed(search: string): Landing | null;
/** `href` without the answer keys, every other pair exactly as written; `href` itself when it carries none. */
export declare function clean(href: string): string;
/** This page's address, as a connect's return. */
export declare function here(): string;
/** A provider id as people write it. */
export declare const named: (id: string) => string;
/**
 * Finish what a return carried, once a person is signed in: `say` gets the
 * sentence, and `after` runs once something was connected. GitHub's own
 * readers hear `changed` instead (api/github.ts `heard`).
 */
export declare function useBack(t: Target, signed: boolean, say: (note: string) => void, after?: () => void): void;
