import { type DropdownMenuProps } from '@hanzo/ui';
import type { Event } from './api/sessions.ts';
import type { Deck, Tabs } from './tabs.ts';
/** A run's panel before anyone has arranged it: what a run is read by, the terminal chosen. */
export declare const SEED: Tabs;
export declare function Desk({ id, repo, branch, base, environment, mode, pr, title, project, sandbox, site, published, events, live, menu, refused, retry, onRetry, side, sheet, onHide, envColumn, splitPanes, onCloseSplitPane, onExpandSplitPane, }: {
    id: string;
    repo: string;
    branch: string;
    base: string;
    environment: string;
    mode: string;
    pr: {
        href: string;
        label: string;
    };
    title: string;
    project: string;
    /** The sandbox the run leased, or '' before it leases one and on a machine. */
    sandbox: string;
    /** Where the run's work is published, or '' before it is. */
    site: string;
    /** The run's latest publish, which loads the page again. */
    published: number;
    events: Event[];
    live: boolean;
    /** What can be done to the run — rename, share, copy its id — as its header offers it. */
    menu: NonNullable<DropdownMenuProps['items']>;
    refused: string;
    /** The refusal's one action: Retry, or Sign in when nobody is. */
    retry: string;
    onRetry: () => void;
    side: Deck;
    sheet: boolean;
    onHide: () => void;
    /** Show the Environment inspection column beside the dock panes. */
    envColumn?: boolean;
    /** Active split panes in the 2x2 multi-pane dock grid ('terminal' | 'preview' | 'diff' | 'files'). */
    splitPanes?: string[];
    onCloseSplitPane?: (paneId: string) => void;
    onExpandSplitPane?: (paneId: string) => void;
}): import("react").JSX.Element;
