import type { Say } from '@hanzo/i18n/react';
import { type Allowance } from './api/billing.ts';
import type { Target } from './api/call.ts';
import { type Limits } from './api/limits.ts';
import { type Read } from './data.ts';
import { type Kind, type Label, type State } from './plan.ts';
export interface Standing {
    kind: Kind;
    /** What the account is on, as a title: the plan's name, Free, or Pay as you go. */
    label: Label | null;
    limits: Limits | null;
    /** The free allowance, where the platform answered it. */
    allowance: Allowance | null;
    /** The prepaid balance in cents, or null where it could not be read. */
    balance: number | null;
}
/** Every read at once. Rejects only when all of them were refused, with the first refusal. */
export declare function stand(t: Target): Promise<Standing>;
/** The standing for `t`, read when `enabled` (a menu that is open) and again when the org changes. */
export declare function useStanding(t: Target, enabled?: boolean): Read<Standing | null>;
/** One window of a plan as a menu lists it. */
export interface Row {
    name: 'Session' | 'Today' | 'Month';
    percent: number;
    state: State;
    /** `Resets 5:00 PM`, or '' where nothing is running yet. */
    resets: string;
}
/**
 * A plan's windows, shortest first: the session, the UTC day, and the month —
 * the billing period of whichever class of model has used the most of it,
 * because that is the one that stops a request first.
 */
export declare function rows(l: Limits | null, now?: number, t?: Say): Row[];
/** The share of the free allowance left in its window, 0 to 100, or null where none bounds the account. */
export declare function left(a: Allowance | null): number | null;
