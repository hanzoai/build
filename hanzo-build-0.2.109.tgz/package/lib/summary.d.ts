/**
 * A surface's summary: what it made and what went into it, as sections of
 * rows, each one press from a tab beside it. Chat draws its Outputs and Sources
 * here; Studio its artifacts. The rows are the caller's: this draws them and
 * knows nothing of a conversation.
 *
 * `Summary` is the popover off the header's outline mark: each section's
 * heading with what it adds at its end, its leading action (Chat's Create file
 * or site), its rows, and one quiet line when it has none. `useKinds` makes
 * each section a kind of tab for `Panel`, the same rows in the panel.
 */
import { type ReactNode } from 'react';
import type { Kind } from './panel.tsx';
/** One row: what it is called, its mark, and what pressing it opens. */
export interface Entry {
    id: string;
    title: string;
    icon?: ReactNode;
    /** A quieter second line: what a lookup asked, what came back. */
    detail?: string;
    open?: () => void;
}
/** A section: its heading, its rows, and what it says with none. */
export interface Section {
    id: string;
    title: string;
    entries: readonly Entry[];
    /** The line drawn when it has no rows; none, and it draws only its heading. */
    empty?: string;
    /** At the heading's end: what adds to it (Chat's `+` on Sources). */
    action?: ReactNode;
    /** A row before the others that does something rather than opens something. */
    lead?: {
        title: string;
        run: () => void;
    };
}
/**
 * The summary, from the outline mark in a header. `onOpen` runs after a row is
 * pressed, for the host to show the panel the row opened a tab in.
 *
 * When `docked` is true (wide viewports where space allows), the header mark
 * toggles `open` via `onOpenChange` without opening a floating popover, and a
 * second `<Summary sections={sections} onOpen={...} pane />` docks the summary
 * inline on the right edge of the inner pane, shifting the main content left so
 * it stays open while toggled.
 */
export declare function Summary({ sections, onOpen, label: named, open: controlledOpen, onOpenChange, docked, pane, }: {
    sections: readonly Section[];
    onOpen?: () => void;
    label?: string;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    docked?: boolean;
    pane?: boolean;
}): import("react").JSX.Element;
/** Each section as a kind of tab for `Panel`: the same rows, with their second lines. */
export declare function kinds(sections: readonly Section[], icons?: Record<string, ReactNode>): Kind[];
/** `kinds`, kept while the sections are the same. */
export declare function useKinds(sections: readonly Section[], icons?: Record<string, ReactNode>): Kind[];
