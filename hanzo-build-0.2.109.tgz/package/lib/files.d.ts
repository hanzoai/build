export declare function Files({ session, repo, branch, sandbox, live, }: {
    session: string;
    repo: string;
    branch: string;
    sandbox: string;
    live: boolean;
}): import("react").JSX.Element;
export declare function Artifacts({ session, sandbox, repo, branch, mode, project, site, pr, onEnvironment, }: {
    session: string;
    /** The run's sandbox, which serves its previews while it is kept. */
    sandbox: string;
    repo: string;
    branch: string;
    mode: string;
    project: string;
    /** Where the run's work is published, or ''. */
    site: string;
    pr: {
        href: string;
        label: string;
    };
    onEnvironment: () => void;
}): import("react").JSX.Element;
