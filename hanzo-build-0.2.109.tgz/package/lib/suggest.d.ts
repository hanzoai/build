import type { Automation, Schedule } from './api/auto.ts';
import type { Conversation } from './api/conversations.ts';
import type { Item } from './api/library.ts';
import type { Session } from './api/sessions.ts';
import type { Issue } from './merge.ts';
export type Icon = 'github' | 'agent' | 'chat' | 'file' | 'task';
export declare const ICONS: readonly Icon[];
/**
 * What pressing a row does, at once:
 *
 *   open      the thing it names: `to` is an app address (`/chat/<id>`,
 *             `/studio/c/<id>`), a builder path (`sess_…`, `-/automations/<id>`,
 *             `-/artifacts` with `item`), or another site's (a new tab)
 *   send      a new chat, asked `prompt`
 *   task      a new Dev run on `prompt`
 *   schedule  a scheduled task, made and shown
 */
export type Act = {
    kind: 'open';
    to: string;
    item?: string;
} | {
    kind: 'send';
    prompt: string;
} | {
    kind: 'task';
    prompt: string;
} | {
    kind: 'schedule';
    name: string;
    prompt: string;
    schedule: Schedule;
};
/** One row: one short action in plain words, and what pressing it does. */
export interface Suggestion {
    /** Stable across generations: what it opens, or its words. */
    id: string;
    icon: Icon;
    /** The action, a few plain words: "Review poster.png in Studio". */
    title: string;
    /** What the source says, a sentence or three: the hover card. */
    summary: string;
    act: Act;
}
/** One piece of the person's activity, as the model is shown it. */
export interface Input {
    kind: 'conversation' | 'issue' | 'pull' | 'run' | 'automation' | 'file';
    /** Its identity: an id, or its address. */
    key: string;
    title: string;
    /** open or closed, a run's status, an automation's last result. */
    state: string;
    /** One line of detail: an issue's opening line, a run's repository, a schedule. */
    text: string;
    /** Its own https address, or ''. */
    href: string;
    /** Where opening it goes (`Act` open's `to`), or '' when nothing opens it. */
    to: string;
    /** A Library item's id, for an item the Library opens at. */
    item?: string;
    /** RFC 3339, or ''. */
    updated: string;
}
/** What signup and Settings learned about the person: the seed when there is no activity. */
export interface Seed {
    /** What Hanzo calls them. */
    name?: string;
    /** What best describes their work (Settings). */
    work?: string;
    /** The role chosen at signup (IAM `onboarding.role`). */
    role?: string;
    /** personal, team or enterprise (IAM `onboarding.use`). */
    use?: string;
    /** What every run is told about how they like to work. */
    instructions?: string;
}
/** What the account keeps under `suggest`. */
export interface Kept {
    /** RFC 3339: when the rows were made. */
    at: string;
    /** The fingerprint of the inputs they were made from. */
    sig: string;
    rows: Suggestion[];
    /** Ids of the rows the person dismissed, newest first. */
    dismissed: string[];
}
/** Hanzo's model the rows are asked of: it decodes under a strict JSON schema at api.hanzo.ai. */
export declare const MODEL = "zen5-flash";
/** At most this many rows. */
export declare const MOST = 3;
/** Rows this old are made again whatever happened. */
export declare const DAY: number;
/** Rows younger than this are kept even when the activity has moved. */
export declare const QUIET = 3600000;
/** How many dismissals are remembered. */
export declare const REMEMBER = 100;
/** How many of each source the model reads. */
export declare const TAKE: Record<Input['kind'], number>;
/** One line, at most `n` characters. */
export declare function line(v: unknown, n: number): string;
/** An https address, or ''. A row links to nothing else. */
export declare function https(v: unknown): string;
/** cyrb53: a 53-bit string hash, as 14 hex digits. A fingerprint, never a secret. */
export declare function hash(s: string): string;
/** What the sources answered, read by suggestions.tsx. */
export interface Activity {
    conversations: Conversation[];
    /** The org's issues and pull requests (GET /v1/task/board). */
    issues: Issue[];
    /** The org's Dev runs; only the person's own are read. */
    runs: Session[];
    automations: Automation[];
    /** The person's own Library items. */
    files: Item[];
    /** The person as a run's `actor` names them: `<owner>/<sub>`. */
    me: string;
}
/** The person's activity as inputs: their own runs only, each kind's newest `TAKE`. */
export declare function inputs(a: Activity): Input[];
/**
 * The seed: what the account's preferences say (`callName`, `work`,
 * `instructions` in /v1/pref) and what signup kept on the IAM user (`onboarding`
 * in /v1/iam/preferences: the role picked, and personal, team or enterprise).
 */
export declare function seed(p: {
    callName?: string;
    work?: string;
    instructions?: string;
}, iam: unknown): Seed;
/** Each kind's newest `TAKE`, newest first overall. */
export declare function pick(all: Input[]): Input[];
/**
 * The fingerprint of what the rows are made from: each input's identity and
 * state, and the seed. A new conversation, a closed issue or a finished run
 * moves it; another turn in a conversation already read does not.
 */
export declare function sig(inputs: Input[], seed: Seed): string;
/** Whether rows kept at `kept` are to be made again, now that the inputs read as `now`. */
export declare function due(kept: Kept | null, fingerprint: string, now: number): boolean;
/** Whether anything newer could change kept rows yet: false while they are younger than `QUIET`. */
export declare function stale(kept: Kept | null, now: number): boolean;
/** The icon a row about `i` carries: GitHub's mark only for GitHub's own address. */
export declare function iconOf(i: Input): Icon;
/** What a row does, as the model names it. */
export declare const ACTIONS: readonly ['open', 'send', 'task', 'schedule'];
/** The answer's shape, decoded strictly by the model. */
export declare const SCHEMA: {
    readonly type: 'object';
    readonly additionalProperties: false;
    readonly required: readonly ['rows'];
    readonly properties: {
        readonly rows: {
            readonly type: 'array';
            readonly maxItems: 3;
            readonly items: {
                readonly type: 'object';
                readonly additionalProperties: false;
                readonly required: readonly ['icon', 'title', 'summary', 'action', 'source', 'prompt', 'every'];
                readonly properties: {
                    readonly icon: {
                        readonly type: 'string';
                        readonly enum: readonly Icon[];
                    };
                    readonly title: {
                        readonly type: 'string';
                    };
                    readonly summary: {
                        readonly type: 'string';
                    };
                    readonly action: {
                        readonly type: 'string';
                        readonly enum: readonly ["open", "send", "task", "schedule"];
                    };
                    readonly source: {
                        readonly type: 'string';
                    };
                    readonly prompt: {
                        readonly type: 'string';
                    };
                    readonly every: {
                        readonly type: 'string';
                    };
                };
            };
        };
    };
};
/** The chat completion that asks for rows, or null when there is nothing to make them from. */
export declare function request(inputs: Input[], seed: Seed, skip: string[], now: Date): Record<string, unknown> | null;
/** `every` as a schedule, or null for words that are not one. */
export declare function every(v: string): Schedule | null;
/** The text of a chat completion's first choice, or ''. */
export declare function content(raw: unknown): string;
/** A row's id: what it opens, or its words. */
export declare const idOf: (to: string, title: string) => string;
/**
 * The rows of a chat completion, validated: each with words and an action that
 * binds (an open names an input's key; a send, a task or a schedule carries its
 * prompt, and a schedule a time it reads), one row per thing, at most `MOST`.
 * Anything else is dropped, never repaired.
 */
export declare function answer(raw: unknown, inputs: Input[]): Suggestion[];
/** The `suggest` key of the preference document, or undefined when it holds none. */
export declare function kept(raw: unknown): Kept | undefined;
/** The rows to draw: those not dismissed. */
export declare const shown: (k: Kept | null | undefined) => Suggestion[];
/**
 * What Hanzo does, three ways in, each done at once: what fills the rows a
 * person's activity and signup do not. The one copy here that is authored, so
 * its words are marked (`phrase`) and drawn in the reader's language, the
 * prompt too: it is sent as their message and shown as theirs.
 */
export declare const STARTERS: readonly Suggestion[];
/** Whether a row is a starter: authored, so drawn through `t`; every other row is the person's own words. */
export declare const starter: (r: Suggestion) => boolean;
/** The kept rows, filled to `MOST` with the starters not dismissed: never one lonely row. */
export declare const fill: (k: Kept | null | undefined) => Suggestion[];
/** `k` with `id` dismissed: remembered first, the oldest forgotten past `REMEMBER`. */
export declare function dismissed(k: Kept, id: string): Kept;
/** The addresses and titles of dismissed rows the model is told to skip. */
export declare function skip(k: Kept | null | undefined, inputs: Input[]): string[];
