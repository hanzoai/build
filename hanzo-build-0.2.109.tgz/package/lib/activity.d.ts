import type { Say } from '@hanzo/i18n/react';
import type { SessionStatus } from '@hanzo/ui/chat';
import type { Job, State } from './api/auto.ts';
/** A job's state as the rail's dot draws it, and in words. */
export declare const DOTS: Record<State, SessionStatus>;
export declare const SAID: Record<State, string>;
/** How long a run took, or has taken so far. */
export declare function lasted(started: string, finished: string | null, now?: number): string;
/** Cents as dollars. */
export declare const dollars: (cents: number) => string;
/** One line about a job: when it started, how long, what it cost, what it made. Its words in the language of `t`. */
export declare function about(j: Job, now?: number, t?: Say): string;
/** The jobs, newest first, with `j` in its place. */
export declare function merged(list: Job[], j: Job): Job[];
/** A task's name from what it does: its first line, short. */
export declare function titled(prompt: string): string;
