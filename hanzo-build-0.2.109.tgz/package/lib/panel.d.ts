import { type ReactNode } from 'react';
import { type Deck, type Tab } from './tabs.ts';
/** A kind of tab the surface offers. */
export interface Kind {
    id: string;
    label: string;
    render: () => ReactNode;
    /** Drawn edge to edge, scrolling itself: a terminal, a frame. */
    bleed?: boolean;
    /** Its mark in the strip. */
    icon?: ReactNode;
}
/** A place an empty tab offers. */
export interface Suggestion {
    title: string;
    url: string;
    /** An image of the place's own mark; its initial without one. */
    icon?: string;
}
/**
 * The header's control for the tabs, while they are hidden: an icon among the
 * header's icons. Open, the strip's own toggle stands at the panel's end and
 * this one is not drawn, so the page carries one toggle at a time. Its words
 * are the reader's language; the key chord is an argument, as this platform writes it.
 */
export declare function PanelToggle({ open, onToggle }: {
    open: boolean;
    onToggle: () => void;
}): import("react").JSX.Element | null;
/** Whether a browser page may frame an address: this page's bytes, this origin, and our own hosts. */
export declare function frames(url: string): boolean;
/** A site or a preview we host: a page under one of our hosts, not this page's own origin or our apexes. */
export declare function hosted(url: string): boolean;
/** A page the menu acts on. */
export interface Here {
    url: string;
    title: string;
}
/** A page asked about, with what the reader had selected in it where a page can read that. */
export interface Asked extends Here {
    selection?: string;
}
/** Something the surface can do with a page: a row of the menu's Skills. */
export interface Skill {
    id: string;
    name: string;
    run: (page: Here) => void;
}
/** What the surface does with a page from its menu: each one draws its row. */
export interface Acts {
    /** Ask about this page: the conversation takes it, with what was selected. */
    onAsk?: (page: Asked) => void;
    /** Open in Dev: a preview or a site we host (`hosted`), opened where it is built. */
    onDev?: (page: Here) => void;
    /** Take a screenshot: the picture, handed to the surface (Chat attaches it). */
    onCapture?: (file: File, page: Here) => void;
    skills?: readonly Skill[];
}
export interface PageProps extends Acts {
    tab: Tab;
    /** Point the page at an address. */
    onGo: (url: string) => void;
    onBack?: () => void;
    onForward?: () => void;
    /** The title the page gave itself. */
    onTitle?: (title: string) => void;
    /** Pin the tab, or let it go. */
    onPin?: (on: boolean) => void;
    suggested?: readonly Suggestion[];
}
/**
 * A page tab: its bar, then an address, bytes rendered as their type, or the
 * suggestions of an empty tab.
 *
 * Two sandboxes. Bytes and an object URL take THIS page's origin, so a script
 * an answer wrote runs without `allow-same-origin`, never with our storage. A
 * remote page takes its own origin, and withholding same-origin breaks it.
 */
export declare function Page({ tab, onGo, onBack, onForward, onTitle, onPin, suggested, ...acts }: PageProps): import("react").JSX.Element;
export interface PanelProps extends Acts {
    side: Deck;
    kinds: readonly Kind[];
    onHide: () => void;
    /** A sheet over the page (a phone) rather than the host's column. */
    sheet?: boolean;
    /** Under the strip, over every tab: a line about what they all read (Dev's sandbox). */
    bar?: ReactNode;
    /** At the strip's end, before pop-out and hide: the surface's own menu. */
    menu?: ReactNode;
    label?: string;
    /** What an empty tab offers. */
    suggested?: readonly Suggestion[];
}
/** The panel: the strip, and the chosen tab. */
export declare function Panel({ side, kinds, onHide, sheet, bar, menu, label, suggested, ...acts }: PanelProps): import("react").JSX.Element;
