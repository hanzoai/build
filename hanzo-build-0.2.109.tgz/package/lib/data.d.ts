import type { Target } from './api/call.ts';
import { type Place } from './api/places.ts';
import { type Project } from './api/projects.ts';
import { type Detail, type Event, type Session } from './api/sessions.ts';
export interface Read<T> {
    value: T;
    error: Error | null;
    loading: boolean;
    reload: () => void;
}
/** Run `load` whenever `key` changes (and on `reload`), keeping the last good value. */
export declare function useRead<T>(load: (() => Promise<T>) | null, initial: T, key: unknown[]): Read<T>;
/** How long a read is waited on before the screen says it is taking too long. */
export declare const WAIT = 15000;
/** A read that did not answer in time. Its message is ours, marked, so a screen drawing it through `t` says it in the reader's language. */
export declare class Slow extends Error {
    constructor();
}
/**
 * A read drawn at once from what this page last read under the same `key`, then
 * read again behind it: stale while it revalidates, so moving between tabs is
 * instant and a list never blanks to "reading" on the way back. A read that has
 * not answered after `wait` ms is let go, as `Slow`. A null key reads nothing.
 */
export declare function useCached<T>(key: string | null, load: (signal: AbortSignal) => Promise<T>, initial: T, wait?: number): Read<T>;
/**
 * The org's coding runs, newest first, kept current by the org's own session
 * stream: a status that moves moves its dot, and a run started anywhere appears.
 */
export declare function useRecents(t: Target, signed: boolean): Read<Session[]>;
export declare function usePlaces(t: Target, signed: boolean): Read<Place[]>;
export declare function useProjects(t: Target, signed: boolean): Read<Project[]>;
/** A value kept in this browser, per key; storage that throws keeps it in memory. */
export declare function useKept<T>(key: string, initial: T): [T, (v: T) => void];
export interface RunState {
    detail: Read<Detail | null>;
    /**
     * The run's record, as last read or pushed: status, branch, pull request.
     * The coding service writes it; events are the narration, and any member of
     * the org can append one, so a link or a branch is never taken from them.
     */
    record: Session | null;
    /** Every turn, recorded and live, in order. */
    events: Event[];
    /** The run's status as last reported by the record or the feed. */
    status: string;
    /** Why the feed stopped, when it was refused. */
    refused: string;
}
/**
 * One run: the recorded detail, then the live feed added to it. A reconnect
 * after a drop re-reads the detail — frames missed while dropped are only in
 * the record. `id` null reads nothing.
 */
export declare function useRun(t: Target, id: string | null): RunState;
