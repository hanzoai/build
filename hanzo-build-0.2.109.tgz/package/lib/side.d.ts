/** What the panel's strip reads of the column it stands in. */
export interface Side {
    /** What the middle column is called, in the button that brings it back: "chat", "run". */
    main: string;
    /** The middle column is hidden and the panel has the room. */
    hidden: boolean;
    show: () => void;
    /** The panel is over the whole window. */
    full: boolean;
    fill: (on: boolean) => void;
}
/** Around the middle column's room and the panel: the panel's strip reads it. */
export declare const SideProvider: import("react").Provider<Side | null>;
/** The column the panel stands in, or null where it stands in none (a phone's sheet, a host's own column). */
export declare const useSide: () => Side | null;
export interface Split {
    /** For `SideProvider`, around the middle column and the panel. */
    side: Side;
    /** The middle column's element: its display is written on it. */
    main: (el: unknown) => void;
    /** The panel's column's element: its width, and full screen, are written on it. */
    aside: (el: unknown) => void;
    /** The kit `Grip`'s props, but its label and its place; none while the panel is full screen. */
    grip: {
        side: 'left' | 'right';
        span: number;
        floor: number;
        ceil: number;
        reset: number;
        onSpan: (n: number) => void;
        onKeep: (n: number) => void;
        onShut: () => void;
    } | null;
}
/**
 * The column, for a host that draws it: `open` is whether the panel is drawn
 * beside the middle column, `main` what that column is called, `onShut` puts
 * the panel away (its edge pulled past its floor).
 */
export declare function useSplit(open: boolean, main: string, onShut: () => void): Split;
