export declare const DOCS = "https://docs.hanzo.ai/docs/dev";
/** Hanzo in Slack is set up under Settings; the card goes there, and once dismissed stays gone. */
export declare function Slack({ onOpen, onDismiss }: {
    onOpen: () => void;
    onDismiss: () => void;
}): import("react").JSX.Element;
/**
 * The account menu's open state, for whatever row opens it.
 *
 * The row that opens the menu lies outside it, so a press on the row while the
 * menu is open reaches the popover first as a press outside, which closes it —
 * and a row that then simply opened it put it straight back, a flicker instead
 * of a close. So the open state is noted as each press BEGINS, before the popover
 * acts on it, and `toggle` (the row's press) closes a menu that was open then.
 */
export declare function useWho(): {
    open: boolean;
    onOpenChange: (o: boolean) => void;
    toggle: () => void;
};
/**
 * The account menu. The rail draws the account row and says when it was pressed,
 * so the menu hangs off an anchor laid over the rail's foot: above it on the
 * open rail, beside it on the collapsed one.
 */
export declare function Who({ open, onOpenChange, narrow }: {
    open: boolean;
    onOpenChange: (o: boolean) => void;
    narrow: boolean;
}): import("react").JSX.Element;
