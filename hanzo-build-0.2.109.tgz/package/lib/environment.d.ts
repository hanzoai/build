import type { Home, Homes } from './api/work.ts';
import { type Read } from './data.ts';
export declare function Environment({ repo, busy }: {
    repo: string;
    busy: boolean;
}): import("react").JSX.Element;
/**
 * New's offer to set a codebase up. An agent onboards it, or an org admin saves
 * it empty and writes the scripts by hand beside the next run.
 *
 * The repository is chosen from the org's own (the forge's, and every linked
 * repository's copy there), never typed: a name that is not one of them — a
 * board's key handed over as a codebase — is said so and cannot be set up.
 */
export declare function SetupDialog({ repo, homes, open, onOpenChange, onStart, onSaved, onRepo, }: {
    repo: string;
    homes: Read<Homes>;
    open: boolean;
    onOpenChange: (o: boolean) => void;
    onStart: (repo: string) => Promise<void>;
    onSaved: (repo: string) => void;
    onRepo: (home: Home) => void;
}): import("react").JSX.Element;
