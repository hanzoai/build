import { type Project as Row } from './api/projects.ts';
/** What a workspace is opened on: a repository on the forge, or a deployed site by its slug. */
export type Where = {
    slug: string;
} | {
    org: string;
    name: string;
};
/** Whether the site `p` is the repository `r`'s: built from it, or named as it is. */
export declare function siteOf(p: Row, r: {
    org: string;
    name: string;
}): boolean;
/** A site's slug for a repository's name: lowercase letters, digits and hyphens, at most 40. */
export declare function slugOf(name: string): string;
export declare function Project({ at }: {
    at: Where;
}): import("react").JSX.Element;
