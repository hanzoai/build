import { type Automation, type Source } from './api/auto.ts';
import { type Target } from './api/call.ts';
import { type Act, type Suggestion } from './suggest.ts';
export interface Suggested {
    /** The rows to draw: three when any are, none dismissed. */
    rows: Suggestion[];
    /** Dismiss one, remembered by the account. */
    dismiss: (id: string) => void;
    /** Why the rows could not be read, made or kept, in the platform's words. */
    error: string | null;
}
/** The person's suggestions. Signed out, or with nothing worth saying, there are none. */
export declare function useSuggestions(t: Target): Suggested;
/**
 * Leave `prompt` for the product `kind` names, which does it on arrival, once:
 * Chat sends a `send` as a new chat, Dev starts a `task` as a run. Same-tab
 * session storage, written by the person's own press, so an address can never
 * carry one (a link is not consent to spend).
 */
export declare function hand(kind: 'send' | 'task', prompt: string): void;
/** The prompt left for `kind`, taken so it is done once, or ''. */
export declare function taken(kind: 'send' | 'task'): string;
/** Make a `schedule` row's task: on, asking before it acts, and notifying its person. */
export declare function book(t: Target, act: Extract<Act, {
    kind: 'schedule';
}>, source: Source): Promise<Automation>;
export interface SuggestionsProps {
    rows: readonly Suggestion[];
    /** A row was pressed: do what it says. */
    onAct: (act: Act, row: Suggestion) => void;
    onDismiss: (id: string) => void;
}
/** The rows, or nothing when there are none. */
export declare function Suggestions({ rows, onAct, onDismiss }: SuggestionsProps): import("react").JSX.Element | null;
