/** One tab. A kind's id is the kind; a page's is minted. */
export interface Tab {
    id: string;
    kind: string;
    title: string;
    /** A page's address. */
    url?: string;
    /** A page's own bytes, rendered as `type`. */
    body?: string;
    type?: string;
    /** The addresses a page came from, oldest first, and those Back stepped over, nearest first. */
    back?: string[];
    ahead?: string[];
    /** Leads the strip, and closes only on purpose. */
    pinned?: boolean;
}
/** The tabs in a scope, in order, and the chosen one. */
export interface Tabs {
    tabs: Tab[];
    at: string | null;
}
export declare const PAGE = "page";
/** A scope as kept, or null when nothing is: the surface's seed stands in. A bad entry is dropped. */
export declare function read(scope: string): Tabs | null;
/** A tab opened: a kind already open is chosen, a page already open on the same thing is chosen. */
export declare function opened(was: Tabs, tab: Omit<Tab, 'id'> & {
    id?: string;
}): Tabs;
/** A tab shut: the one to its right is chosen, else the one to its left, as a browser does. */
export declare function shut(was: Tabs, id: string): Tabs;
/** A tab moved to `to`, the others closing up around it, and kept in its group: pinned or not. */
export declare function moved(was: Tabs, id: string, to: number): Tabs;
/** A tab pinned, or let go: it joins the end of the pinned tabs, or leads the rest. */
export declare function pinned(was: Tabs, id: string, on: boolean): Tabs;
/** Every tab closed but the pinned ones and those `keep` names; the chosen one stays if it is left. */
export declare function cleared(was: Tabs, keep?: (t: Tab) => boolean): Tabs;
export interface Deck extends Tabs {
    open: (tab: Omit<Tab, 'id'> & {
        id?: string;
    }) => void;
    pick: (id: string) => void;
    shut: (id: string) => void;
    move: (id: string, to: number) => void;
    /** Pin a tab: it leads the strip and closes only on purpose. */
    pin: (id: string) => void;
    unpin: (id: string) => void;
    /** Close every tab but the pinned ones and those `keep` names. */
    clear: (keep?: (t: Tab) => boolean) => void;
    /** Point a page somewhere else: where it was goes on its Back, and Forward is forgotten. */
    go: (id: string, url: string) => void;
    /** A page's Back and Forward. */
    back: (id: string) => void;
    forward: (id: string) => void;
    /** A page's title, as what it shows calls itself. */
    rename: (id: string, title: string) => void;
}
/** A page pointed at `url`, where it was on its Back. */
export declare function went(t: Tab, url: string): Tab;
/** A page one step back, or forward: the address it leaves goes the other way. */
export declare function stepped(t: Tab, way: 'back' | 'forward'): Tab;
/** A scope's tabs: as kept, else `seed`, and every change kept. */
export declare function useDeck(scope: string, seed: Tabs): Deck;
/** Whether the panel is open in `mode`, kept; `first` before anyone has said. */
export declare function useShown(mode: string, first: boolean): readonly [boolean, (open: boolean) => void];
/**
 * Whether the panel is open: kept per mode where it is a column (`wide`), and
 * for this page only where it is a sheet over everything — a phone opens on
 * the conversation, never on a sheet it did not ask for.
 */
export declare function usePanel(mode: string, first: boolean, wide: boolean): readonly [boolean, (open: boolean) => void];
/**
 * The panel's keys, from anywhere on the page but a field: Ctrl+Shift+B (⌘⇧B on
 * a Mac), the tabs' own, and ⌘. / Ctrl+., which it had first.
 */
export declare function useKey(toggle: () => void): void;
/** The host and path of an address: as much as a title can honestly be. */
export declare function name(url: string): string;
/** Where words typed in a page's bar are looked up. */
export declare const SEARCH = "https://duckduckgo.com/?q=";
/** Whether what was typed in a page's bar is an address rather than words to look up. */
export declare function located(typed: string): boolean;
/** What a page's bar opens for what was typed: the address, or a search for the words. */
export declare function destination(typed: string): string;
/** An address as typed, made one that opens: https for a host, http for this machine. */
export declare function address(typed: string): string;
