import { type Say } from '@hanzo/i18n/react';
import type { RailLink } from '@hanzo/ui/chat';
import type { Host } from './host.tsx';
/** A run of places under one quiet label; '' draws none. */
export interface Group {
    id: string;
    label: string;
    links: RailLink[];
}
/** The id of the row that starts a new run: a rail with a New control of its own draws that instead. */
export declare const NEW = "new";
export declare function nav(host: Host, go: (path: string) => void, t?: Say): Group[];
/** Dev's own places: what a host whose rail holds the rest (Library, Scheduled tasks, Customize) lists in Dev's sidebar. */
export declare const own: (host: Host, go: (path: string) => void, t?: Say) => Group[];
/**
 * Settings' sections as a host's sidebar lists them: one group per part, a
 * part's label drawn only where it is not its first row's name (Code leads
 * Code's part, so the part is not labelled twice).
 */
export declare function sections(host: Host, go: (path: string) => void, t?: Say): Group[];
/** Customize's tabs as a host's sidebar lists them, Agents first; an agent's profile lights Agents. */
export declare function tabs(host: Host, go: (path: string) => void, t?: Say): Group[];
/** Fired on `window` once the sidebar's Upload has kept its files, for the Library to read again. */
export declare const KEPT = "hanzo:library:kept";
/** The Library's sidebar: Upload, then every kind it narrows to, the one in the address lit. */
export declare function library(host: Host, go: (path: string) => void, t?: Say): Group[];
/** Scheduled tasks' sidebar: New task, then each of the person's tasks, the one open lit. Read only while `on`. */
export declare function useScheduled(host: Host, go: (path: string) => void, on: boolean): Group[];
