/**
 * Which model answers, and how hard it thinks: one store for Chat and Dev, and
 * the catalog both offer. The composer (@hanzo/ui/chat) changes it.
 *
 *   GET /v1/models   the catalog, read once per platform and shared
 *   hanzo.mind       the person's choice, in this browser: {model, effort}
 *
 * The effort is always under the composer; the model chip only where the person
 * turned it on (Settings → Appearance › Model in composer). Enso
 * routes every ask — a message in Chat, a step in Dev — so naming a model is an
 * override, and the panel says so before it offers one. A premium model is
 * picked for the screen it was picked on (`usePick`) and never kept, so the next
 * conversation or run opens on what was kept, Enso until something else is.
 *
 * The efforts are Auto, High, XHigh and Max, Chat's words (Hanzo's
 * ThinkingEffort), Auto until another is chosen. A coding run takes low, medium
 * or high (apps/coding `efforts`), so `level` is what a run names: medium for
 * Auto, what a run took before anyone chose, and high for the rest, the most it
 * takes. Auto names one rather than none, because a run that names none takes
 * an effort the person saved to their account once (apps/coding start.go) and
 * no screen shows any more.
 */
import type { Modes } from '@hanzo/ui/chat';
import { type Target } from './api/call.ts';
import { type Model } from './api/models.ts';
export type Effort = 'auto' | 'high' | 'xhigh' | 'max';
/** The efforts a Dev run offers, in order: the composer's own list (Chat offers every one), less Low and Medium. Marked English, drawn through `t`. */
export declare const EFFORTS: (import("@hanzo/ui/chat").Way<import("@hanzo/ui/chat").Effort> & {
    id: Effort;
})[];
/** The effort a coding run names (apps/coding takes low, medium or high): medium for Auto, high for the rest. */
export declare const level: (effort: Effort) => 'medium' | 'high';
/** What a person chose: the model (Enso routes) and the effort. */
export interface Choice {
    model: string;
    effort: Effort;
}
export declare const FIRST: Choice;
/** What Free answers on: the catalog's free lane, Enso's first. `free` is an alias of it. */
export declare const FREE = "enso-free";
/** Whether a plan grants only the free lane. An unknown plan is not taken for Free. */
export declare const isFree: (plan: string | null | undefined) => boolean;
/** The kept choice, Enso and Auto where nothing is kept. Stable while the stored text is. Low and Medium, offered once, read as Auto. */
export declare function kept(): Choice;
/** Keep a change, in this browser, for every surface that reads it. */
export declare function keep(patch: Partial<Choice>): void;
/** The kept choice and the way to change it. The server and the first render read the default. */
export declare function useChoice(): readonly [Choice, (patch: Partial<Choice>) => void];
/** A model's name as the catalog spells it; Enso for the router. */
export declare function nameOf(model: string, catalog: readonly Model[]): string;
/** An id said as a name: its last path part, each word capitalised (`enso-flash` → Enso Flash). */
export declare function spelled(id: string): string;
/** The ids that are the router under another name: the picker's Enso row stands for all of them. */
export declare const ROUTER_IDS: ReadonlySet<string>;
/** `GET /v1/models` for a target, asked once and shared; a refusal is not kept, so the next ask goes again. */
export declare function catalog(t: Target): Promise<Model[]>;
/** The catalog as a chooser draws it, and the list a kept pick is judged against. */
export interface Catalog {
    /** What the chooser offers: the list read, else the last one this browser kept, else Enso alone. */
    models: Model[];
    /** What was read, for a pick to stand on: empty when nothing was, so a kept pick stands. */
    list: Model[];
    loading: boolean;
    /** Why there is no list to offer, in a reader's words; null when there is one. */
    error: string | null;
    /** A list shown from before, because this read failed. */
    note: string;
}
/**
 * The platform's catalog, as a hook: what was read already is there on the
 * first render. The gateway answers 429 once the org's quota is spent, and a
 * list that vanishes then leaves nothing to choose from, so a failed read shows
 * the last list this browser kept, with a note; with none kept, Enso alone, and
 * the reason in the chooser — never the platform's own words.
 */
export declare function useCatalog(t: Target): Catalog;
/** Whether `model` is one this plan may send: on Free, the catalog's free class alone. */
export declare function grants(free: boolean, model: string, catalog: readonly Model[]): boolean;
/** The effort as the composer reads it: the one in force, its list, and the way to change it. */
export declare const pacing: (m: Pick<Mind, 'effort' | 'pace'>) => Modes<Effort>;
/** The chip's whole state: the catalog, what answers next, and how to change either. */
export interface Mind {
    model: string;
    effort: Effort;
    models: Model[];
    loading: boolean;
    error: string | null;
    /** A list shown from before, because this read failed. */
    note: string;
    /** The plan grants only the free lane: anything else is an upgrade, never a pick. */
    free: boolean;
    /** A premium pick holds for this screen; any other is kept. */
    pick: (id: string) => void;
    pace: (effort: Effort) => void;
}
/**
 * The model and effort for the plan `plan` names (`GET /v1/ai/limits` `plan`).
 * On Free the default is `FREE` and a kept pick outside the free lane is set
 * aside rather than sent — it comes back once the plan grants it.
 */
export declare function useMind(t: Target, plan?: string | null): Mind;
